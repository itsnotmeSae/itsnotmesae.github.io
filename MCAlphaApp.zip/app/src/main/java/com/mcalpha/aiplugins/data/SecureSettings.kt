package com.mcalpha.aiplugins.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Stores the user's OpenAI API key in encrypted on-device storage.
 * The key never leaves the device except in direct HTTPS calls to
 * OpenAI's API, and is never hardcoded or bundled with the app.
 */
class SecureSettings(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "mcalpha_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun getApiKey(): String? = prefs.getString(KEY_OPENAI, null)

    fun setApiKey(key: String) {
        prefs.edit().putString(KEY_OPENAI, key.trim()).apply()
    }

    fun clearApiKey() {
        prefs.edit().remove(KEY_OPENAI).apply()
    }

    fun getModel(): String = prefs.getString(KEY_MODEL, DEFAULT_MODEL) ?: DEFAULT_MODEL

    fun setModel(model: String) {
        prefs.edit().putString(KEY_MODEL, model).apply()
    }

    companion object {
        private const val KEY_OPENAI = "openai_api_key"
        private const val KEY_MODEL = "openai_model"
        const val DEFAULT_MODEL = "gpt-4o"
    }
}
