package com.mcalpha.aiplugins

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.mcalpha.aiplugins.ui.GeneratorViewModel
import com.mcalpha.aiplugins.ui.screens.GeneratorScreen
import com.mcalpha.aiplugins.ui.screens.SettingsScreen
import com.mcalpha.aiplugins.ui.theme.MCAlphaTheme

class MainActivity : ComponentActivity() {

    private val viewModel: GeneratorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MCAlphaTheme {
                AppNav(viewModel)
            }
        }
    }
}

@Composable
fun AppNav(viewModel: GeneratorViewModel) {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "generator") {
        composable("generator") {
            GeneratorScreen(
                viewModel = viewModel,
                onOpenSettings = { navController.navigate("settings") }
            )
        }
        composable("settings") {
            SettingsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
