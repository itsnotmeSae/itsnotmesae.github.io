package com.mcalpha.aiplugins.ai

import android.content.Context

/**
 * Loads the bundled MCAlpha Free Plan workflow: the core rules (always sent
 * as part of the system prompt) plus the PocketMine API 2.0.0 reference
 * index (loaded on demand, mirroring the workflow's own rule: "Search the
 * API index only when needed").
 */
class WorkflowRepository(private val context: Context) {

    /** Core workflow rules — small, always included in the system prompt. */
    fun loadCoreWorkflow(): String {
        return readAsset("workflow/FREE_PLAN_WORKFLOW.md")
    }

    /** Names of all available API index topics, e.g. "pocketmine_event". */
    fun listIndexTopics(): List<String> {
        return context.assets.list("workflow/index")
            ?.filter { it.endsWith(".md") }
            ?.map { it.removeSuffix(".md") }
            ?.sorted()
            ?: emptyList()
    }

    /** Loads a single API index doc by topic name (e.g. "pocketmine_event"). */
    fun loadIndexTopic(topic: String): String? {
        val safe = topic.replace(Regex("[^a-zA-Z0-9_]"), "")
        return try {
            readAsset("workflow/index/$safe.md")
        } catch (e: Exception) {
            null
        }
    }

    /** A short directory of topics the model can ask to look up. */
    fun indexDirectory(): String {
        return listIndexTopics().joinToString("\n") { "- $it" }
    }

    private fun readAsset(path: String): String {
        return context.assets.open(path).bufferedReader().use { it.readText() }
    }
}
