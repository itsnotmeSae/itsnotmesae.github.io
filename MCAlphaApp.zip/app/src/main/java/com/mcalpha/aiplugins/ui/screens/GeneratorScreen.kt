package com.mcalpha.aiplugins.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.mcalpha.aiplugins.ai.AiResult
import com.mcalpha.aiplugins.ui.GeneratorViewModel
import com.mcalpha.aiplugins.util.PluginExporter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GeneratorScreen(
    viewModel: GeneratorViewModel,
    onOpenSettings: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    LaunchedEffect(Unit) { viewModel.refreshKeyState() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("MCAlpha AI Plugins") },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (!state.hasApiKey) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text(
                            "No OpenAI API key saved.",
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.titleSmall
                        )
                        Spacer(Modifier.height(8.dp))
                        TextButton(onClick = onOpenSettings) { Text("Add key in Settings") }
                    }
                }
            }

            Text("Describe the plugin", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = state.prompt,
                onValueChange = viewModel::onPromptChange,
                placeholder = { Text("e.g. A plugin that gives players a diamond sword when they join for the first time") },
                minLines = 3,
                maxLines = 8,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = { viewModel.generate() },
                enabled = !state.isLoading && state.prompt.isNotBlank(),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (state.isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Generating…")
                } else {
                    Text("Generate plugin")
                }
            }

            when (val result = state.result) {
                is AiResult.Error -> {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                        Text(
                            result.message,
                            modifier = Modifier.padding(16.dp),
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
                is AiResult.Success -> {
                    ResultCard(
                        result = result,
                        onCopy = { clipboard.setText(AnnotatedString(result.phpCode)) },
                        onShare = {
                            val file = PluginExporter.exportAsZip(context, result.pluginName, result.phpCode, result.pluginYml)
                            PluginExporter.shareFile(context, file)
                        }
                    )
                }
                null -> {}
            }
        }
    }
}

@Composable
private fun ResultCard(
    result: AiResult.Success,
    onCopy: () -> Unit,
    onShare: () -> Unit
) {
    Card {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(result.pluginName, style = MaterialTheme.typography.titleLarge)

            if (result.explanation.isNotBlank()) {
                Text(result.explanation, style = MaterialTheme.typography.bodyMedium)
            }

            Text("plugin.yml", style = MaterialTheme.typography.labelLarge)
            CodeBlock(result.pluginYml)

            Text("main.php", style = MaterialTheme.typography.labelLarge)
            CodeBlock(result.phpCode)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onCopy) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Copy PHP")
                }
                Button(onClick = onShare) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Export .zip")
                }
            }
        }
    }
}

@Composable
private fun CodeBlock(code: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
            .horizontalScroll(rememberScrollState())
            .padding(12.dp)
    ) {
        Text(
            text = code.ifBlank { "(empty)" },
            fontFamily = FontFamily.Monospace,
            style = MaterialTheme.typography.bodySmall
        )
    }
}
