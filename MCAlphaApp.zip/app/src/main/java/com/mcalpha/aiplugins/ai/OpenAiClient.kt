package com.mcalpha.aiplugins.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

sealed class AiResult {
    data class Success(val pluginName: String, val phpCode: String, val pluginYml: String, val explanation: String) : AiResult()
    data class Error(val message: String) : AiResult()
}

/**
 * Talks directly to OpenAI's Chat Completions API from the device, using the
 * MCAlpha Free Plan workflow as the system prompt. The API index is exposed
 * as a callable tool so the model only pulls in the PocketMine class docs it
 * actually needs, per the workflow's own rules.
 */
class OpenAiClient(
    private val apiKey: String,
    private val model: String,
    private val workflow: WorkflowRepository
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    suspend fun generatePlugin(userRequest: String): AiResult = withContext(Dispatchers.IO) {
        try {
            val systemPrompt = buildSystemPrompt()
            val messages = JSONArray().apply {
                put(JSONObject().put("role", "system").put("content", systemPrompt))
                put(JSONObject().put("role", "user").put("content", userRequest))
            }

            // Allow up to a few lookup round-trips before forcing a final answer.
            repeat(4) { attempt ->
                val body = buildRequestBody(messages, forceFinal = attempt == 3)
                val response = callChatCompletions(body)

                if (response == null) {
                    return@withContext AiResult.Error("No response from OpenAI. Check your connection and API key.")
                }

                val choice = response.optJSONArray("choices")?.optJSONObject(0)
                    ?: return@withContext AiResult.Error("Unexpected response format from OpenAI.")

                val message = choice.getJSONObject("message")
                val toolCalls = message.optJSONArray("tool_calls")

                if (toolCalls != null && toolCalls.length() > 0) {
                    // Model wants to look up API docs — append its request, then the tool results.
                    messages.put(message)
                    for (i in 0 until toolCalls.length()) {
                        val call = toolCalls.getJSONObject(i)
                        val callId = call.getString("id")
                        val fn = call.getJSONObject("function")
                        val topic = try {
                            JSONObject(fn.optString("arguments", "{}")).optString("topic", "")
                        } catch (e: Exception) { "" }

                        val docContent = workflow.loadIndexTopic(topic)
                            ?: "No index found for topic '$topic'. Available topics:\n${workflow.indexDirectory()}"

                        messages.put(
                            JSONObject()
                                .put("role", "tool")
                                .put("tool_call_id", callId)
                                .put("content", docContent.take(12000))
                        )
                    }
                    // loop again so the model can use the looked-up docs
                } else {
                    val content = message.optString("content", "")
                    return@withContext parsePluginResponse(content)
                }
            }

            AiResult.Error("The model didn't produce a final plugin after several lookups. Try a more specific request.")
        } catch (e: Exception) {
            AiResult.Error("Error generating plugin: ${e.message}")
        }
    }

    private fun buildSystemPrompt(): String {
        val core = workflow.loadCoreWorkflow()
        val topics = workflow.indexDirectory()
        return """
You are an expert PocketMine-MP (PMMP) API 2.0.0 plugin generator for MCPE, running inside an Android app called MCAlpha AI Plugins.

$core

You have a tool `lookup_api_doc` to fetch reference docs for a PocketMine namespace/topic when you're unsure of a class or method signature. Available topics:
$topics

Never invent PocketMine API methods or classes. If unsure, call lookup_api_doc first.

When you have finished planning and are ready to deliver the plugin, respond with ONLY a JSON object (no markdown fences, no extra text) in exactly this shape:
{
  "plugin_name": "ShortPluginName",
  "php_code": "<the full contents of the main plugin PHP file>",
  "plugin_yml": "<the full contents of plugin.yml>",
  "explanation": "<a brief explanation of what the plugin does and how to install it>"
}
        """.trimIndent()
    }

    private fun buildRequestBody(messages: JSONArray, forceFinal: Boolean): String {
        val root = JSONObject()
        root.put("model", model)
        root.put("messages", messages)
        root.put("temperature", 0.2)

        if (!forceFinal) {
            val tools = JSONArray().put(
                JSONObject()
                    .put("type", "function")
                    .put(
                        "function", JSONObject()
                            .put("name", "lookup_api_doc")
                            .put("description", "Fetch PocketMine API 2.0.0 reference documentation for a topic (e.g. pocketmine_event, pocketmine_block, pocketmine_item).")
                            .put(
                                "parameters", JSONObject()
                                    .put("type", "object")
                                    .put(
                                        "properties", JSONObject()
                                            .put("topic", JSONObject().put("type", "string").put("description", "The topic name, e.g. pocketmine_event"))
                                    )
                                    .put("required", JSONArray().put("topic"))
                            )
                    )
            )
            root.put("tools", tools)
        }

        return root.toString()
    }

    private fun callChatCompletions(bodyJson: String): JSONObject? {
        val request = Request.Builder()
            .url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer $apiKey")
            .addHeader("Content-Type", "application/json")
            .post(bodyJson.toRequestBody(jsonMedia))
            .build()

        client.newCall(request).execute().use { resp ->
            val bodyStr = resp.body?.string() ?: return null
            if (!resp.isSuccessful) {
                val err = try { JSONObject(bodyStr).optJSONObject("error")?.optString("message") } catch (e: Exception) { null }
                throw RuntimeException(err ?: "HTTP ${resp.code}")
            }
            return JSONObject(bodyStr)
        }
    }

    private fun parsePluginResponse(raw: String): AiResult {
        val cleaned = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return try {
            val obj = JSONObject(cleaned)
            AiResult.Success(
                pluginName = obj.optString("plugin_name", "GeneratedPlugin"),
                phpCode = obj.optString("php_code", ""),
                pluginYml = obj.optString("plugin_yml", ""),
                explanation = obj.optString("explanation", "")
            )
        } catch (e: Exception) {
            // Model didn't return clean JSON — surface the raw text so nothing is lost.
            AiResult.Success(
                pluginName = "GeneratedPlugin",
                phpCode = raw,
                pluginYml = "",
                explanation = "Note: response wasn't in the expected JSON format, showing raw output."
            )
        }
    }
}
