package com.mcalpha.aiplugins.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val PmSeedGreen = Color(0xFF3F8B3F)

private val LightColors = lightColorScheme(
    primary = Color(0xFF3F8B3F),
    secondary = Color(0xFF5B6147),
    tertiary = Color(0xFF39656B)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9FD895),
    secondary = Color(0xFFC2C9AA),
    tertiary = Color(0xFFA1CED4)
)

@Composable
fun MCAlphaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColors
        else -> LightColors
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = MaterialTheme.typography,
        content = content
    )
}
