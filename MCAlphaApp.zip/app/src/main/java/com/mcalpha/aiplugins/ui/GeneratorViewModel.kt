package com.mcalpha.aiplugins.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mcalpha.aiplugins.ai.AiResult
import com.mcalpha.aiplugins.ai.OpenAiClient
import com.mcalpha.aiplugins.ai.WorkflowRepository
import com.mcalpha.aiplugins.data.SecureSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class GeneratorUiState(
    val prompt: String = "",
    val isLoading: Boolean = false,
    val result: AiResult? = null,
    val hasApiKey: Boolean = false
)

class GeneratorViewModel(app: Application) : AndroidViewModel(app) {

    private val settings = SecureSettings(app)
    private val workflow = WorkflowRepository(app)

    private val _uiState = MutableStateFlow(GeneratorUiState(hasApiKey = !settings.getApiKey().isNullOrBlank()))
    val uiState: StateFlow<GeneratorUiState> = _uiState

    fun onPromptChange(text: String) {
        _uiState.value = _uiState.value.copy(prompt = text)
    }

    fun refreshKeyState() {
        _uiState.value = _uiState.value.copy(hasApiKey = !settings.getApiKey().isNullOrBlank())
    }

    fun saveApiKey(key: String) {
        settings.setApiKey(key)
        refreshKeyState()
    }

    fun clearApiKey() {
        settings.clearApiKey()
        refreshKeyState()
    }

    fun currentModel(): String = settings.getModel()

    fun setModel(model: String) {
        settings.setModel(model)
    }

    fun generate() {
        val key = settings.getApiKey()
        if (key.isNullOrBlank()) {
            _uiState.value = _uiState.value.copy(result = AiResult.Error("Add your OpenAI API key in Settings first."))
            return
        }
        val prompt = _uiState.value.prompt
        if (prompt.isBlank()) return

        _uiState.value = _uiState.value.copy(isLoading = true, result = null)
        viewModelScope.launch {
            val client = OpenAiClient(key, settings.getModel(), workflow)
            val result = client.generatePlugin(prompt)
            _uiState.value = _uiState.value.copy(isLoading = false, result = result)
        }
    }
}
