package com.mcalpha.aiplugins.util

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object PluginExporter {

    /**
     * Packs the generated plugin into a folder structure PocketMine expects
     * (PluginName/plugin.yml, PluginName/src/main.php) and zips it for sharing.
     */
    fun exportAsZip(context: Context, pluginName: String, phpCode: String, pluginYml: String): File {
        val safeName = pluginName.replace(Regex("[^a-zA-Z0-9_-]"), "")
        val outDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val zipFile = File(outDir, "$safeName.zip")

        ZipOutputStream(zipFile.outputStream()).use { zip ->
            zip.putNextEntry(ZipEntry("$safeName/plugin.yml"))
            zip.write(pluginYml.toByteArray())
            zip.closeEntry()

            zip.putNextEntry(ZipEntry("$safeName/src/main.php"))
            zip.write(phpCode.toByteArray())
            zip.closeEntry()
        }
        return zipFile
    }

    fun shareFile(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share plugin"))
    }
}
