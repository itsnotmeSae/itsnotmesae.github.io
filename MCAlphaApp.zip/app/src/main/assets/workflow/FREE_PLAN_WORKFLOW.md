# MCAlpha Free Plan Workflow

## Core Rules
- PocketMine API 2.0.0 only
- PHP 7 only
- Never invent APIs.
- Search the API index only when needed.
- Verify only unfamiliar classes/methods.
- Keep answers concise unless asked otherwise.

## Workflow
1. Understand request.
2. Plan briefly.
3. Lookup only required API docs.
4. Generate code.
5. Verify suspicious API usage.
6. Done.

Avoid full-project verification and optimization until final release.
