# MCAlpha Legacy Plugin Development Workflow

## Mission
Generate PocketMine-MP plugins for MCPE 0.14.x–0.15.10, PMMP API 2.0.0 only. Never invent an API — verify every class, method, and constant against `index/` (or `reference_source/` if not in the index) before it appears in generated code.

## Hard Constraints
- API 2.0.0 only. Never PMMP 3.x/4.x/5.x syntax or classes.
- PHP 7 syntax only (no PHP 8 features: no union types, no `match`, no named args, no nullsafe `?->`).
- Forbidden: Forms/FormAPI, `InventoryTransactionEvent`-based item handling, modern `TaskScheduler`/`AsyncPool` calls not present in 2.0.0, PHP 8 syntax.
- Optimize for low RAM/CPU — this targets old low-spec Android/phones running MCPE servers.

## API Lookup — always in this order
1. **`index/_INDEX.md`** — table of contents, points to the right category file.
2. **`index/<category>.md`** — one entry per class: namespace, extends/implements, constants, and every public/protected method signature. This answers ~95% of lookups without opening a full source file.
3. **`reference_source/PMMP API 2.0.0 CODE/<path shown in the index entry>`** — only when you need a full method body, a private method, or something the index doesn't show.
4. If it's in none of these, it does not exist in this API. Report it as unsupported — do not guess or port a newer API's method.

Category files (`index/pocketmine_<name>.md`): root, block, command, entity, event, inventory, item, lang, level, math, metadata, nbt, network, permission, plugin, scheduler, tile, utils, wizard. Plus `index/raklib.md` and `index/spl.md` for the networking/logging base classes.

## Phases
1. **Requirements** — plugin name, commands, permissions, events needed, config shape, storage, any economy/other plugin soft-dependency.
2. **API Discovery** — walk the Search Priority list below in `index/`, note the exact classes/methods/constants the plugin will call.
3. **Design** — file layout (below), event flow, data flow.
4. **Code Generation** — write it, citing nothing beyond what Discovery confirmed exists.
5. **Self-Verification** — for every `use`, method call, and constant in the generated code, re-check it against the index entry (or source file) it came from. Delete/fix anything unverified.
6. **Optimization pass** — cache repeated lookups (e.g. plugin instances, config values) in fields set in `onEnable`, avoid allocations in hot paths (onUpdate/tick handlers, chat/move events).
7. **Delivery** — full source, `plugin.yml`, `resources/config.yml`, and one-paragraph install instructions.

## Search Priority
`pocketmine_root` → `pocketmine_event` → `pocketmine_entity` → `pocketmine_level` → `pocketmine_network` → `pocketmine_inventory` → `pocketmine_item` → `pocketmine_block` → `pocketmine_command` → `pocketmine_scheduler` → others as needed.

## Error Recovery
Index miss → check the class's `extends`/`implements` line in the index (method may be inherited) → check the parent/interface's own index entry → check `reference_source` file directly → report as unsupported. Never fabricate a signature.

## Standard Plugin Layout
```
PluginName/
  plugin.yml
  resources/config.yml
  src/PluginName/
    Main.php
    commands/
    listeners/
    tasks/
    utils/
```

## Delivery Checklist
- Every `use` statement resolves to a class that exists in `index/` or `reference_source/`.
- Every method call matches an index signature (name + arg count/order).
- Every constant matches an index `consts:` line.
- No PHP 8 syntax, no forbidden APIs.
- `plugin.yml` api version is `2.0.0`.
