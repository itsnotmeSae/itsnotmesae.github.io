# pocketmine_wizard (2 classes)

### Installer (class) — pocketmine/wizard/Installer.php
consts: DEFAULT_NAME, DEFAULT_PORT, DEFAULT_MEMORY, DEFAULT_PLAYERS, DEFAULT_GAMEMODE, DEFAULT_LEVEL_NAME, DEFAULT_LEVEL_TYPE
public: __construct(); getDefaultLang()
### InstallerLang (class) — pocketmine/wizard/InstallerLang.php
public: __construct($lang = ""); getLang(); loadLang($langfile, $lang = "en"); get($name, $search = [], $replace = []); __get($name)
