# spl (20 classes)

### ArrayOutOfBoundsException (class) — extends OutOfBoundsException | spl/ArrayOutOfBoundsException.php
### AttachableLogger (interface) — extends \Logger | spl/AttachableLogger.php
public: addAttachment(\LoggerAttachment $attachment); removeAttachment(\LoggerAttachment $attachment); removeAttachments(); getAttachments()
### AttachableThreadedLogger (class) — extends \ThreadedLogger | spl/AttachableThreadedLogger.php
public: addAttachment(\ThreadedLoggerAttachment $attachment); removeAttachment(\ThreadedLoggerAttachment $attachment); removeAttachments(); getAttachments()
### BaseClassLoader (class) — extends \Threaded | implements ClassLoader | spl/BaseClassLoader.php
public: __construct(ClassLoader $parent = null); addPath($path, $prepend = false); removePath($path); getClasses(); getParent(); register($prepend = false); loadClass($name); findClass($name)
protected: getAndRemoveLookupEntries()
### ClassCastException (class) — extends InvalidArgumentException | spl/ClassCastException.php
### ClassLoader (interface) — spl/ClassLoader.php
public: __construct(ClassLoader $parent = null); addPath($path, $prepend = false); removePath($path); getClasses(); getParent(); register($prepend = false); loadClass($name); findClass($name)
### ClassNotFoundException (class) — extends LogicException | spl/ClassNotFoundException.php
### InvalidArgumentCountException (class) — extends InvalidArgumentException | spl/InvalidArgumentCountException.php
### InvalidKeyException (class) — extends InvalidArgumentException | spl/InvalidKeyException.php
### InvalidStateException (class) — extends InvalidArgumentException | spl/InvalidStateException.php
### LogLevel (interface) — spl/LogLevel.php
consts: EMERGENCY, ALERT, CRITICAL, ERROR, WARNING, NOTICE, INFO, DEBUG
### Logger (interface) — spl/Logger.php
public: emergency($message); alert($message); critical($message); error($message); warning($message); notice($message); info($message); debug($message); log($level, $message); logException(\Throwable $e, $trace = null)
### LoggerAttachment (interface) — spl/LoggerAttachment.php
public: log($level, $message)
### SplFixedByteArray (class) — extends SplFixedArray | spl/SplFixedByteArray.php
public: __construct($size, $convert = false); chunk($start, $size, $normalize = true); static fromString($str, $convert = false); static fromStringChunk($str, $size, $start = 0, $convert = false); toString(); __toString()
### StringOutOfBoundsException (class) — extends OutOfBoundsException | spl/StringOutOfBoundsException.php
### ThreadedLogger (class) — extends \Thread | implements Logger | spl/ThreadedLogger.php
### ThreadedLoggerAttachment (class) — extends \Threaded | implements \LoggerAttachment | spl/ThreadedLoggerAttachment.php
public: addAttachment(\ThreadedLoggerAttachment $attachment); removeAttachment(\ThreadedLoggerAttachment $attachment); removeAttachments(); getAttachments()
### UndefinedConstantException (class) — extends InvalidStateException | spl/UndefinedConstantException.php
### UndefinedPropertyException (class) — extends LogicException | spl/UndefinedPropertyException.php
### UndefinedVariableException (class) — extends InvalidStateException | spl/UndefinedVariableException.php
