# pocketmine_entity (70 classes)

### Ageable (interface) — pocketmine/entity/Ageable.php
consts: DATA_AGEABLE_FLAGS, DATA_FLAG_BABY
public: isBaby()
### Animal (class) — extends Creature | implements Ageable | pocketmine/entity/Animal.php
public: initEntity(); isBaby()
### Arrow (class) — extends Projectile | pocketmine/entity/Arrow.php
consts: NETWORK_ID
public: __construct(FullChunk $chunk, CompoundTag $nbt, Entity $shootingEntity = null, $critical = false); getPotionId(); onUpdate($currentTick); spawnTo(Player $player)
### Attachable (interface) — pocketmine/entity/Attachable.php
### Attribute (class) — pocketmine/entity/Attribute.php
consts: ABSORPTION, SATURATION, EXHAUSTION, KNOCKBACK_RESISTANCE, HEALTH, MOVEMENT_SPEED, FOLLOW_RANGE, HUNGER, FOOD, ATTACK_DAMAGE, EXPERIENCE_LEVEL, EXPERIENCE
public: static init(); static addAttribute($id, $name, $minValue, $maxValue, $defaultValue, $shouldSend = true); static getAttribute($id); static getAttributeByName($name); getMinValue(); setMinValue($minValue); getMaxValue(); setMaxValue($maxValue); getDefaultValue(); setDefaultValue($defaultValue); getValue(); setValue($value, bool $fit = true, bool $shouldSend = false); getName(); getId(); isSyncable(); isDesynchronized(); markSynchronized(bool $synced = true)
### AttributeMap (class) — implements \ArrayAccess | pocketmine/entity/AttributeMap.php
public: addAttribute(Attribute $attribute); getAttribute(int $id); needSend(); offsetExists($offset); offsetGet($offset); offsetSet($offset, $value); offsetUnset($offset)
### Bat (class) — extends FlyingAnimal | pocketmine/entity/Bat.php
consts: NETWORK_ID, DATA_IS_RESTING
public: getName(); initEntity(); __construct(FullChunk $chunk, CompoundTag $nbt); isResting(); setResting(bool $resting); onUpdate($currentTick); spawnTo(Player $player)
### Blaze (class) — extends Monster | pocketmine/entity/Blaze.php
consts: NETWORK_ID
public: getName(); spawnTo(Player $player); getDrops()
### Boat (class) — extends Vehicle | pocketmine/entity/Boat.php
consts: NETWORK_ID, DATA_WOOD_ID
public: __construct(FullChunk $chunk, CompoundTag $nbt); getWoodID(); spawnTo(Player $player); attack($damage, EntityDamageEvent $source); onUpdate($currentTick); getDrops(); getSaveId()
### CaveSpider (class) — extends Monster | pocketmine/entity/CaveSpider.php
consts: NETWORK_ID
public: getName(); spawnTo(Player $player)
### Chicken (class) — extends Animal | pocketmine/entity/Chicken.php
consts: NETWORK_ID
public: getName(); spawnTo(Player $player); getDrops()
### Colorable (interface) — pocketmine/entity/Colorable.php
### Cow (class) — extends Animal | pocketmine/entity/Cow.php
consts: NETWORK_ID
public: getName(); spawnTo(Player $player); getDrops()
### Creature (class) — extends Living | pocketmine/entity/Creature.php
public: onUpdate($tick); willMove($distance = 36); attack($damage, EntityDamageEvent $source); ifjump(Level $level, Vector3 $v3, $hate = false, $reason = false); whatBlock(Level $level, $v3); getMyYaw($mx, $mz); getMyPitch(Vector3 $from, Vector3 $to)
### Creeper (class) — extends Monster | pocketmine/entity/Creeper.php
consts: NETWORK_ID, DATA_SWELL_DIRECTION, DATA_SWELL, DATA_SWELL_OLD, DATA_POWERED
public: getName(); initEntity(); setPowered(bool $powered, Lightning $lightning = null); isPowered(); spawnTo(Player $player)
### Damageable (interface) — pocketmine/entity/Damageable.php
### Effect (class) — pocketmine/entity/Effect.php
consts: SPEED, SLOWNESS, HASTE, SWIFTNESS, FATIGUE, MINING_FATIGUE, STRENGTH, HEALING, HARMING, JUMP, NAUSEA, CONFUSION, REGENERATION, DAMAGE_RESISTANCE, FIRE_RESISTANCE, WATER_BREATHING, INVISIBILITY, BLINDNESS, NIGHT_VISION, HUNGER, WEAKNESS, POISON, WITHER, HEALTH_BOOST, ABSORPTION, SATURATION, MAX_DURATION
public: static init(); static getEffect($id); static getEffectByName($name); __construct($id, $name, $r, $g, $b, $isBad = false); getName(); getId(); setDuration($ticks); getDuration(); isVisible(); setVisible($bool); getAmplifier(); setAmplifier($amplifier); isAmbient(); setAmbient($ambient = true); isBad(); canTick(); applyEffect(Entity $entity); getColor(); setColor($r, $g, $b); add(Entity $entity, $modify = false, Effect $oldEffect = null); remove(Entity $entity)
### Egg (class) — extends Projectile | pocketmine/entity/Egg.php
consts: NETWORK_ID
public: __construct(FullChunk $chunk, CompoundTag $nbt, Entity $shootingEntity = null); onUpdate($currentTick); spawnTo(Player $player)
### Enderman (class) — extends Monster | pocketmine/entity/Enderman.php
consts: NETWORK_ID
public: getName(); spawnTo(Player $player)
### Entity (class) — extends Location | implements Metadatable | pocketmine/entity/Entity.php
consts: NETWORK_ID, DATA_TYPE_BYTE, DATA_TYPE_SHORT, DATA_TYPE_INT, DATA_TYPE_FLOAT, DATA_TYPE_STRING, DATA_TYPE_SLOT, DATA_TYPE_POS, DATA_TYPE_LONG, DATA_FLAGS, DATA_AIR, DATA_NAMETAG, DATA_SHOW_NAMETAG, DATA_SILENT, DATA_POTION_COLOR, DATA_POTION_AMBIENT, DATA_NO_AI, DATA_LEAD_HOLDER, DATA_LEAD, DATA_FLAG_ONFIRE, DATA_FLAG_SNEAKING, DATA_FLAG_RIDING, DATA_FLAG_SPRINTING, DATA_FLAG_ACTION, DATA_FLAG_INVISIBLE, SOUTH, WEST, NORTH, EAST
public: __construct(FullChunk $chunk, CompoundTag $nbt); getDropExpMin(); getDropExpMax(); getNameTag(); isNameTagVisible(); setNameTag($name); setNameTagVisible($value = true); isSneaking(); setSneaking($value = true); isSprinting(); setSprinting($value = true); getEffects(); removeAllEffects(); removeEffect($effectId); getEffect($effectId); hasEffect($effectId); addEffect(Effect $effect); static createEntity($type, FullChunk $chunk, CompoundTag $nbt, ...$args); static registerEntity($className, $force = false); getSaveId(); saveNBT(); getViewers(); spawnTo(Player $player); sendPotionEffects(Player $player); sendData($player, array $data = null); despawnFrom(Player $player); attack($damage, EntityDamageEvent $source); heal($amount, EntityRegainHealthEvent $source); getHealth(); isAlive(); setHealth($amount); setLastDamageCause(EntityDamageEvent $type); getLastDamageCause(); getAttributeMap(); getMaxHealth(); setMaxHealth($amount); canCollideWith(Entity $entity); entityBaseTick($tickDiff = 1); addMovement($x, $y, $z, $yaw, $pitch, $headYaw = null); getDirectionVector(); getDirectionPlane(); onUpdate($currentTick); isOnFire(); setOnFire($seconds); getDirection(); extinguish(); canTriggerWalking(); resetFallDistance(); getBoundingBox(); fall($fallDistance); handleLavaMovement(); getEyeHeight(); moveFlying(); onCollideWithPlayer(Human $entityPlayer); getPosition(); getLocation(); isInsideOfPortal(); isInsideOfWater(); isInsideOfSolid(); isInsideOfFire(); fastMove($dx, $dy, $dz); move($dx, $dy, $dz); getBlocksAround(); setPositionAndRotation(Vector3 $pos, $yaw, $pitch); setRotation($yaw, $pitch); setLocation(Location $pos); setPosition(Vector3 $pos); getMotion(); setMotion(Vector3 $motion); isOnGround(); kill(); teleport(Vector3 $pos, $yaw = null, $pitch = null); getId(); respawnToAll(); spawnToAll(); despawnFromAll(); close(); setDataProperty($id, $type, $value); linkEntity(Entity $entity); sendLinkedData(); setLinked($type = 0, Entity $entity); getLinkedEntity(); getLinkedType(); getDataProperty($id); getDataPropertyType($id); setDataFlag($propertyId, $id, $value = true, $type = self::DATA_TYPE_BYTE); getDataFlag($propertyId, $id); __destruct(); setMetadata($metadataKey, MetadataValue $metadataValue); getMetadata($metadataKey); hasMetadata($metadataKey); removeMetadata($metadataKey, Plugin $plugin); __toString()
protected: recalculateEffectColor(); initEntity(); addAttributes(); checkObstruction($x, $y, $z); updateMovement(); updateFallState($distanceThisTick, $onGround); switchLevel(Level $targetLevel); checkGroundState($movX, $movY, $movZ, $dx, $dy, $dz); checkBlockCollision(); checkChunks()
### Explosive (interface) — pocketmine/entity/Explosive.php
public: explode()
### FallingSand (class) — extends Entity | pocketmine/entity/FallingSand.php
consts: NETWORK_ID, DATA_BLOCK_INFO
public: canCollideWith(Entity $entity); attack($damage, EntityDamageEvent $source); onUpdate($currentTick); getBlock(); getDamage(); saveNBT(); spawnTo(Player $player)
protected: initEntity()
### FishingHook (class) — extends Projectile | pocketmine/entity/FishingHook.php
consts: NETWORK_ID
public: initEntity(); __construct(FullChunk $chunk, CompoundTag $nbt, Entity $shootingEntity = null, int $lead = -1); setData($id); getData(); onUpdate($currentTick); fishBites(); attractFish(); reelLine(); spawnTo(Player $player)
### FlyingAnimal (class) — extends Creature | implements Ageable | pocketmine/entity/FlyingAnimal.php
public: onUpdate($currentTick); initEntity(); isBaby(); attack($damage, EntityDamageEvent $source)
### Ghast (class) — extends FlyingAnimal | pocketmine/entity/Ghast.php
consts: NETWORK_ID
public: getName(); initEntity(); spawnTo(Player $player)
### Hanging (class) — extends Entity | implements Attachable | pocketmine/entity/Hanging.php
### Human (class) — extends Creature | implements ProjectileSource, InventoryHolder | pocketmine/entity/Human.php
consts: DATA_PLAYER_FLAG_SLEEP, DATA_PLAYER_FLAG_DEAD, DATA_PLAYER_FLAGS, DATA_PLAYER_BED_POSITION
public: getSkinData(); getSkinId(); getUniqueId(); getRawUniqueId(); setSkin($str, $skinId); getFood(); setFood(float $new); getMaxFood(); addFood(float $amount); getSaturation(); setSaturation(float $saturation); addSaturation(float $amount); getExhaustion(); setExhaustion(float $exhaustion); exhaust(float $amount, int $cause = PlayerExhaustEvent::CAUSE_CUSTOM); getXpLevel(); setXpLevel(int $level); addXpLevel(int $level); takeXpLevel(int $level); getXpProgress(); setXpProgress(float $progress); getTotalXp(); setTotalXp(int $xp, bool $syncLevel = false); addXp(int $xp, bool $syncLevel = false); takeXp(int $xp, bool $syncLevel = false); getRemainderXp(); getFilledXp(); recalculateXpProgress(); getXpSeed(); resetXpCooldown(); canPickupXp(); static getTotalXpRequirement(int $level); static getLevelXpRequirement(int $level); static getLevelFromXp(int $xp); getInventory(); getFloatingInventory(); getTransactionQueue(); getAbsorption(); setAbsorption(int $absorption); entityBaseTick($tickDiff = 1, $EnchantL = 0); getName(); getDrops(); saveNBT(); spawnTo(Player $player); despawnFrom(Player $player); close()
protected: initEntity(); addAttributes()
### Husk (class) — extends Zombie | pocketmine/entity/Husk.php
consts: NETWORK_ID
public: getName(); spawnTo(Player $player)
### InstantEffect (class) — extends Effect | pocketmine/entity/InstantEffect.php
### IronGolem (class) — extends Animal | pocketmine/entity/IronGolem.php
consts: NETWORK_ID
public: initEntity(); getName(); spawnTo(Player $player); getDrops()
### Item (class) — extends Entity | pocketmine/entity/Item.php
consts: NETWORK_ID
public: attack($damage, EntityDamageEvent $source); onUpdate($currentTick); saveNBT(); getItem(); canCollideWith(Entity $entity); getPickupDelay(); setPickupDelay($delay); getOwner(); setOwner($owner); getThrower(); setThrower($thrower); spawnTo(Player $player)
protected: initEntity()
### LavaSlime (class) — extends Living | pocketmine/entity/LavaSlime.php
consts: NETWORK_ID, DATA_SLIME_SIZE
public: getName(); spawnTo(Player $player)
### Lightning (class) — extends Animal | pocketmine/entity/Lightning.php
consts: NETWORK_ID
public: getName(); initEntity(); onUpdate($tick); spawnTo(Player $player); spawnToAll()
### Living (class) — extends Entity | implements Damageable | pocketmine/entity/Living.php
public: setHealth($amount); saveNBT(); hasLineOfSight(Entity $entity); heal($amount, EntityRegainHealthEvent $source); attack($damage, EntityDamageEvent $source); knockBack(Entity $attacker, $damage, $x, $z, $base = 0.4); kill(); entityBaseTick($tickDiff = 1, $EnchantL = 0); getDrops(); getLineOfSight($maxDistance, $maxLength = 0, array $transparent = []); getTargetBlock($maxDistance, array $transparent = [])
protected: initEntity()
### Minecart (class) — extends Vehicle | pocketmine/entity/Minecart.php
consts: NETWORK_ID, TYPE_NORMAL, TYPE_CHEST, TYPE_HOPPER, TYPE_TNT, STATE_INITIAL, STATE_ON_RAIL, STATE_OFF_RAIL
public: initEntity(); getName(); getType(); onUpdate($currentTick); getNearestRail(); spawnTo(Player $player); attack($damage, EntityDamageEvent $source); getSaveId()
### MinecartChest (class) — extends Minecart | pocketmine/entity/MinecartChest.php
consts: NETWORK_ID
public: getName(); getType(); spawnTo(Player $player)
### MinecartHopper (class) — extends Minecart | pocketmine/entity/MinecartHopper.php
consts: NETWORK_ID
public: getName(); getType(); spawnTo(Player $player)
### MinecartTNT (class) — extends Minecart | pocketmine/entity/MinecartTNT.php
consts: NETWORK_ID
public: getName(); getType(); spawnTo(Player $player)
### Monster (class) — extends Creature | pocketmine/entity/Monster.php
### Mooshroom (class) — extends Animal | pocketmine/entity/Mooshroom.php
consts: NETWORK_ID
public: getName(); spawnTo(Player $player); getDrops()
### NPC (interface) — pocketmine/entity/NPC.php
### Ocelot (class) — extends Animal | pocketmine/entity/Ocelot.php
consts: NETWORK_ID, DATA_CAT_TYPE, TYPE_WILD, TYPE_TUXEDO, TYPE_TABBY, TYPE_SIAMESE
public: getName(); __construct(FullChunk $chunk, CompoundTag $nbt); setCatType(int $type); getCatType(); spawnTo(Player $player)
### Painting (class) — extends Hanging | pocketmine/entity/Painting.php
consts: NETWORK_ID
public: initEntity(); attack($damage, EntityDamageEvent $source); spawnTo(Player $player); getDrops()
protected: updateMovement()
### Pig (class) — extends Animal | pocketmine/entity/Pig.php
consts: NETWORK_ID
public: getName(); spawnTo(Player $player); getDrops()
### PigZombie (class) — extends Monster | pocketmine/entity/PigZombie.php
consts: NETWORK_ID
public: getName(); spawnTo(Player $player); getDrops()
### PrimedTNT (class) — extends Entity | implements Explosive | pocketmine/entity/PrimedTNT.php
consts: NETWORK_ID
public: __construct(FullChunk $chunk, CompoundTag $nbt, bool $dropItem = true); attack($damage, EntityDamageEvent $source); canCollideWith(Entity $entity); saveNBT(); onUpdate($currentTick); explode(); spawnTo(Player $player)
protected: initEntity()
### Projectile (class) — extends Entity | pocketmine/entity/Projectile.php
consts: DATA_SHOOTER_ID
public: __construct(FullChunk $chunk, CompoundTag $nbt, Entity $shootingEntity = null); attack($damage, EntityDamageEvent $source); canCollideWith(Entity $entity); saveNBT(); onUpdate($currentTick)
protected: initEntity()
### ProjectileSource (interface) — pocketmine/entity/ProjectileSource.php
### Rabbit (class) — extends Animal | pocketmine/entity/Rabbit.php
consts: NETWORK_ID, DATA_RABBIT_TYPE, DATA_JUMP_TYPE, TYPE_BROWN, TYPE_WHITE, TYPE_BLACK, TYPE_BLACK_WHITE, TYPE_GOLD, TYPE_SALT_PEPPER, TYPE_KILLER_BUNNY
public: initEntity(); __construct(FullChunk $chunk, CompoundTag $nbt); getRandomRabbitType(); setRabbitType(int $type); getRabbitType(); getName(); spawnTo(Player $player); getDrops()
### Rideable (interface) — pocketmine/entity/Rideable.php
### Sheep (class) — extends Animal | implements Colorable | pocketmine/entity/Sheep.php
consts: NETWORK_ID, DATA_COLOR_INFO
public: getName(); __construct(FullChunk $chunk, CompoundTag $nbt); static getRandomColor(); getColor(); setColor(int $color); spawnTo(Player $player); getDrops()
### Silverfish (class) — extends Monster | pocketmine/entity/Silverfish.php
consts: NETWORK_ID
public: getName(); spawnTo(Player $player)
### Skeleton (class) — extends Monster | implements ProjectileSource | pocketmine/entity/Skeleton.php
consts: NETWORK_ID
public: getName(); spawnTo(Player $player)
### Slime (class) — extends Living | pocketmine/entity/Slime.php
consts: NETWORK_ID, DATA_SLIME_SIZE
public: getName(); spawnTo(Player $player); getDrops()
### SnowGolem (class) — extends Animal | pocketmine/entity/SnowGolem.php
consts: NETWORK_ID
public: initEntity(); getName(); spawnTo(Player $player)
### Snowball (class) — extends Projectile | pocketmine/entity/Snowball.php
consts: NETWORK_ID
public: __construct(FullChunk $chunk, CompoundTag $nbt, Entity $shootingEntity = null); onUpdate($currentTick); spawnTo(Player $player)
### Spider (class) — extends Monster | pocketmine/entity/Spider.php
consts: NETWORK_ID
public: getName(); spawnTo(Player $player); getDrops()
### Squid (class) — extends WaterAnimal | implements Ageable | pocketmine/entity/Squid.php
consts: NETWORK_ID
public: initEntity(); getName(); attack($damage, EntityDamageEvent $source); onUpdate($currentTick); spawnTo(Player $player); getDrops()
### Stray (class) — extends Skeleton | pocketmine/entity/Stray.php
consts: NETWORK_ID
public: getName(); spawnTo(Player $player)
### Tameable (interface) — pocketmine/entity/Tameable.php
### ThrownExpBottle (class) — extends Projectile | pocketmine/entity/ThrownExpBottle.php
consts: NETWORK_ID
public: __construct(FullChunk $chunk, CompoundTag $nbt, Entity $shootingEntity = null); onUpdate($currentTick); spawnTo(Player $player)
### ThrownPotion (class) — extends Projectile | pocketmine/entity/ThrownPotion.php
consts: NETWORK_ID, DATA_POTION_ID
public: __construct(FullChunk $chunk, CompoundTag $nbt, Entity $shootingEntity = null); getPotionId(); kill(); onUpdate($currentTick); spawnTo(Player $player)
### Vehicle (class) — extends Entity | implements Rideable | pocketmine/entity/Vehicle.php
### Villager (class) — extends Creature | implements NPC, Ageable | pocketmine/entity/Villager.php
consts: PROFESSION_FARMER, PROFESSION_LIBRARIAN, PROFESSION_PRIEST, PROFESSION_BLACKSMITH, PROFESSION_BUTCHER, NETWORK_ID, DATA_PROFESSION_ID
public: getName(); __construct(FullChunk $chunk, CompoundTag $nbt); spawnTo(Player $player); setProfession(int $profession); getProfession(); isBaby()
protected: initEntity()
### WaterAnimal (class) — extends Creature | implements Ageable | pocketmine/entity/WaterAnimal.php
public: initEntity(); isBaby()
### Witch (class) — extends Monster | pocketmine/entity/Witch.php
consts: NETWORK_ID
public: getName(); initEntity(); spawnTo(Player $player); getDrops()
### Wolf (class) — extends Animal | pocketmine/entity/Wolf.php
consts: NETWORK_ID
public: getName(); spawnTo(Player $player)
### XPOrb (class) — extends Entity | pocketmine/entity/XPOrb.php
consts: NETWORK_ID
public: initEntity(); onUpdate($currentTick); canCollideWith(Entity $entity); setExperience($exp); getExperience(); spawnTo(Player $player)
### Zombie (class) — extends Monster | pocketmine/entity/Zombie.php
consts: NETWORK_ID
public: getName(); initEntity(); attack($damage, EntityDamageEvent $source); onUpdate($currentTick); spawnTo(Player $player); getDrops()
### ZombieVillager (class) — extends Zombie | pocketmine/entity/ZombieVillager.php
consts: NETWORK_ID
public: initEntity(); getName(); spawnTo(Player $player)
