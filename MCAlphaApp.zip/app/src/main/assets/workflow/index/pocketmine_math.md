# pocketmine_math (6 classes)

### AxisAlignedBB (class) — pocketmine/math/AxisAlignedBB.php
public: __construct($minX, $minY, $minZ, $maxX, $maxY, $maxZ); setBounds($minX, $minY, $minZ, $maxX, $maxY, $maxZ); addCoord($x, $y, $z); grow($x, $y, $z); expand($x, $y, $z); offset($x, $y, $z); shrink($x, $y, $z); contract($x, $y, $z); setBB(AxisAlignedBB $bb); getOffsetBoundingBox($x, $y, $z); calculateXOffset(AxisAlignedBB $bb, $x); calculateYOffset(AxisAlignedBB $bb, $y); calculateZOffset(AxisAlignedBB $bb, $z); intersectsWith(AxisAlignedBB $bb); isVectorInside(Vector3 $vector); getAverageEdgeLength(); isVectorInYZ(Vector3 $vector); isVectorInXZ(Vector3 $vector); isVectorInXY(Vector3 $vector); calculateIntercept(Vector3 $pos1, Vector3 $pos2); __toString()
### Math (class) — pocketmine/math/Math.php
public: static floorFloat($n); static ceilFloat($n); static clamp($value, $low, $high); static solveQuadratic($a, $b, $c)
### Matrix (class) — implements \ArrayAccess | pocketmine/math/Matrix.php
public: offsetExists($offset); offsetGet($offset); offsetSet($offset, $value); offsetUnset($offset); __construct($rows, $columns, array $set = []); set(array $m); getRows(); getColumns(); setElement($row, $column, $value); getElement($row, $column); isSquare(); add(Matrix $matrix); substract(Matrix $matrix); multiplyScalar($number); divideScalar($number); transpose(); product(Matrix $matrix); determinant(); __toString()
### Vector2 (class) — pocketmine/math/Vector2.php
public: __construct($x = 0, $y = 0); getX(); getY(); getFloorX(); getFloorY(); add($x, $y = 0); subtract($x, $y = 0); ceil(); floor(); round(); abs(); multiply($number); divide($number); distance($x, $y = 0); distanceSquared($x, $y = 0); length(); lengthSquared(); normalize(); dot(Vector2 $v); __toString(); static createRandomDirection(Random $random)
### Vector3 (class) — pocketmine/math/Vector3.php
consts: SIDE_DOWN, SIDE_UP, SIDE_NORTH, SIDE_SOUTH, SIDE_WEST, SIDE_EAST
public: __construct($x = 0, $y = 0, $z = 0); getX(); getY(); getZ(); getFloorX(); getFloorY(); getFloorZ(); getRight(); getUp(); getForward(); getSouth(); getWest(); add($x, $y = 0, $z = 0); subtract($x = 0, $y = 0, $z = 0); multiply($number); divide($number); ceil(); floor(); round(); abs(); getSide($side, $step = 1); static getOppositeSide($side); distance(Vector3 $pos); distanceSquared(Vector3 $pos); maxPlainDistance($x = 0, $z = 0); length(); lengthSquared(); normalize(); dot(Vector3 $v); cross(Vector3 $v); equals(Vector3 $v); getIntermediateWithXValue(Vector3 $v, $x); getIntermediateWithYValue(Vector3 $v, $y); getIntermediateWithZValue(Vector3 $v, $z); setComponents($x, $y, $z); fromObjectAdd(Vector3 $pos, $x, $y, $z); __toString(); static createRandomDirection(Random $random)
### VectorMath (class) — pocketmine/math/VectorMath.php
public: static getDirection2D($azimuth); static getDirection3D($azimuth, $inclination)
