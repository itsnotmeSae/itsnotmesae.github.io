# pocketmine_command (66 classes)

### BanCidByNameCommand (class) — extends VanillaCommand | pocketmine/command/defaults/BanCidByNameCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### BanCidCommand (class) — extends VanillaCommand | pocketmine/command/defaults/BanCidCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### BanCommand (class) — extends VanillaCommand | pocketmine/command/defaults/BanCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### BanIpByNameCommand (class) — extends VanillaCommand | pocketmine/command/defaults/BanIpByNameCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### BanIpCommand (class) — extends VanillaCommand | pocketmine/command/defaults/BanIpCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### BanListCommand (class) — extends VanillaCommand | pocketmine/command/defaults/BanListCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### BiomeCommand (class) — extends VanillaCommand | pocketmine/command/defaults/BiomeCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### CaveCommand (class) — extends VanillaCommand | pocketmine/command/defaults/CaveCommand.php
public: __construct($name); execute(CommandSender $sender, $commandLabel, array $args); chu($v1, $v2); getDirectionVector($yaw, $pitch); caves(Position $pos, $cave, $tt = false); lavaSpawn(Level $level, $x, $y, $z); explodeBlocks(Position $source, $rays = 16, $size = 4); fdx($x, $y, $z, Level $level, $liu = false); ranz($a); tiankengy(Level $level, $x, $y, $z, $l, $id, $bd)
### ChunkInfoCommand (class) — extends VanillaCommand | pocketmine/command/defaults/ChunkInfoCommand.php
public: __construct($name); execute(CommandSender $sender, $commandLabel, array $args)
### Command (class) — pocketmine/command/Command.php
public: __construct($name, $description = "", $usageMessage = null, array $aliases = []); getName(); getPermission(); setPermission($permission); testPermission(CommandSender $target); testPermissionSilent(CommandSender $target); getLabel(); setLabel($name); register(CommandMap $commandMap); unregister(CommandMap $commandMap); isRegistered(); getAliases(); getPermissionMessage(); getDescription(); getUsage(); setAliases(array $aliases); setDescription($description); setPermissionMessage($permissionMessage); setUsage($usage); static broadcastCommandMessage(CommandSender $source, $message, $sendToSource = true); __toString()
### CommandExecutor (interface) — pocketmine/command/CommandExecutor.php
public: onCommand(CommandSender $sender, Command $command, $label, array $args)
### CommandMap (interface) — pocketmine/command/CommandMap.php
public: registerAll($fallbackPrefix, array $commands); register($fallbackPrefix, Command $command, $label = null); dispatch(CommandSender $sender, $cmdLine); clearCommands(); getCommand($name)
### CommandReader (class) — extends Thread | pocketmine/command/CommandReader.php
public: __construct($logger); shutdown(); getLine(); quit(); run(); getThreadName()
### CommandSender (interface) — extends Permissible | pocketmine/command/CommandSender.php
public: sendMessage($message); getServer(); getName()
### ConsoleCommandSender (class) — implements CommandSender | pocketmine/command/ConsoleCommandSender.php
public: __construct(); isPermissionSet($name); hasPermission($name); addAttachment(Plugin $plugin, $name = null, $value = null); removeAttachment(PermissionAttachment $attachment); recalculatePermissions(); getEffectivePermissions(); isPlayer(); getServer(); sendMessage($message); getName(); isOp(); setOp($value)
### CountryCommand (class) — extends VanillaCommand | pocketmine/command/defaults/CountryCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### DefaultGamemodeCommand (class) — extends VanillaCommand | pocketmine/command/defaults/DefaultGamemodeCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### DeopCommand (class) — extends VanillaCommand | pocketmine/command/defaults/DeopCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### DifficultyCommand (class) — extends VanillaCommand | pocketmine/command/defaults/DifficultyCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### DumpMemoryCommand (class) — extends VanillaCommand | pocketmine/command/defaults/DumpMemoryCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### EffectCommand (class) — extends VanillaCommand | pocketmine/command/defaults/EffectCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### EnchantCommand (class) — extends VanillaCommand | pocketmine/command/defaults/EnchantCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### FillCommand (class) — extends VanillaCommand | pocketmine/command/defaults/FillCommand.php
public: __construct($name); execute(CommandSender $sender, $label, array $args)
### FormattedCommandAlias (class) — extends Command | pocketmine/command/FormattedCommandAlias.php
public: __construct($alias, array $formatStrings); execute(CommandSender $sender, $commandLabel, array $args)
### GamemodeCommand (class) — extends VanillaCommand | pocketmine/command/defaults/GamemodeCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### GarbageCollectorCommand (class) — extends VanillaCommand | pocketmine/command/defaults/GarbageCollectorCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### GiveCommand (class) — extends VanillaCommand | pocketmine/command/defaults/GiveCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### HelpCommand (class) — extends VanillaCommand | pocketmine/command/defaults/HelpCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### KickCommand (class) — extends VanillaCommand | pocketmine/command/defaults/KickCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### KillCommand (class) — extends VanillaCommand | pocketmine/command/defaults/KillCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### ListCommand (class) — extends VanillaCommand | pocketmine/command/defaults/ListCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### LvdatCommand (class) — extends VanillaCommand | pocketmine/command/defaults/LvdatCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args); autoLoad(CommandSender $c, $world)
### MeCommand (class) — extends VanillaCommand | pocketmine/command/defaults/MeCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### OpCommand (class) — extends VanillaCommand | pocketmine/command/defaults/OpCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### PardonCidCommand (class) — extends VanillaCommand | pocketmine/command/defaults/PardonCidCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### PardonCommand (class) — extends VanillaCommand | pocketmine/command/defaults/PardonCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### PardonIpCommand (class) — extends VanillaCommand | pocketmine/command/defaults/PardonIpCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### ParticleCommand (class) — extends VanillaCommand | pocketmine/command/defaults/ParticleCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### PingCommand (class) — extends VanillaCommand | pocketmine/command/defaults/PingCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### PluginCommand (class) — extends Command | implements PluginIdentifiableCommand | pocketmine/command/PluginCommand.php
public: __construct($name, Plugin $owner); execute(CommandSender $sender, $commandLabel, array $args); getExecutor(); setExecutor(CommandExecutor $executor); getPlugin()
### PluginIdentifiableCommand (interface) — pocketmine/command/PluginIdentifiableCommand.php
public: getPlugin()
### PluginsCommand (class) — extends VanillaCommand | pocketmine/command/defaults/PluginsCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### ProtocolVersionCommand (class) — extends VanillaCommand | pocketmine/command/defaults/ProtocolVersionCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### ReloadCommand (class) — extends VanillaCommand | pocketmine/command/defaults/ReloadCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### RemoteConsoleCommandSender (class) — extends ConsoleCommandSender | pocketmine/command/RemoteConsoleCommandSender.php
public: sendMessage($message); getMessage(); getName()
### SaveCommand (class) — extends VanillaCommand | pocketmine/command/defaults/SaveCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### SaveOffCommand (class) — extends VanillaCommand | pocketmine/command/defaults/SaveOffCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### SaveOnCommand (class) — extends VanillaCommand | pocketmine/command/defaults/SaveOnCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### SayCommand (class) — extends VanillaCommand | pocketmine/command/defaults/SayCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### SeedCommand (class) — extends VanillaCommand | pocketmine/command/defaults/SeedCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### SetBlockCommand (class) — extends VanillaCommand | pocketmine/command/defaults/SetBlockCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### SetWorldSpawnCommand (class) — extends VanillaCommand | pocketmine/command/defaults/SetWorldSpawnCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### SimpleCommandMap (class) — implements CommandMap | pocketmine/command/SimpleCommandMap.php
public: __construct(Server $server); registerAll($fallbackPrefix, array $commands); register($fallbackPrefix, Command $command, $label = null, $overrideConfig = false); dispatch(CommandSender $sender, $commandLine); clearCommands(); getCommand($name); getCommands(); registerServerAliases()
### SpawnpointCommand (class) — extends VanillaCommand | pocketmine/command/defaults/SpawnpointCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### StatusCommand (class) — extends VanillaCommand | pocketmine/command/defaults/StatusCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### StopCommand (class) — extends VanillaCommand | pocketmine/command/defaults/StopCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### SummonCommand (class) — extends VanillaCommand | pocketmine/command/defaults/SummonCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### TeleportCommand (class) — extends VanillaCommand | pocketmine/command/defaults/TeleportCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### TellCommand (class) — extends VanillaCommand | pocketmine/command/defaults/TellCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### TimeCommand (class) — extends VanillaCommand | pocketmine/command/defaults/TimeCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### TimingsCommand (class) — extends VanillaCommand | pocketmine/command/defaults/TimingsCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### VanillaCommand (class) — extends Command | pocketmine/command/defaults/VanillaCommand.php
consts: MAX_COORD, MIN_COORD
public: __construct($name, $description = "", $usageMessage = null, array $aliases = [])
protected: getInteger(CommandSender $sender, $value, $min = self::MIN_COORD, $max = self::MAX_COORD); getRelativeDouble($original, CommandSender $sender, $input, $min = self::MIN_COORD, $max = self::MAX_COORD); getDouble(CommandSender $sender, $value, $min = self::MIN_COORD, $max = self::MAX_COORD)
### VersionCommand (class) — extends VanillaCommand | pocketmine/command/defaults/VersionCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### WeatherCommand (class) — extends VanillaCommand | pocketmine/command/defaults/WeatherCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### WhitelistCommand (class) — extends VanillaCommand | pocketmine/command/defaults/WhitelistCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
### XpCommand (class) — extends VanillaCommand | pocketmine/command/defaults/XpCommand.php
public: __construct($name); execute(CommandSender $sender, $currentAlias, array $args)
