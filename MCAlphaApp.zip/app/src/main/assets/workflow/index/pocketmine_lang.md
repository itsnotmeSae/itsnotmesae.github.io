# pocketmine_lang (1 classes)

### BaseLang (class) — pocketmine/lang/BaseLang.php
consts: FALLBACK_LANGUAGE
public: __construct($lang, $path = null, $fallback = self::FALLBACK_LANGUAGE); getName(); getLang(); translateString($str, array $params = [], $onlyPrefix = null); translate(TextContainer $c); internalGet($id); get($id)
protected: loadLang($path, array &$d); parseTranslation($text, $onlyPrefix = null)
