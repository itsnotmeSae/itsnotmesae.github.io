# PMMP API 2.0.0 — Condensed Class Index

Generated from reference_source. One entry per class = namespace/extends/implements/consts/public+protected method signatures.
Open the real file (path shown after the class name) ONLY if you need a full method body or something not listed here.

- `index/pocketmine_block.md` — 196 classes, 46 KB
- `index/pocketmine_command.md` — 66 classes, 14 KB
- `index/pocketmine_entity.md` — 70 classes, 18 KB
- `index/pocketmine_event.md` — 118 classes, 26 KB
- `index/pocketmine_inventory.md` — 37 classes, 11 KB
- `index/pocketmine_item.md` — 160 classes, 28 KB
- `index/pocketmine_lang.md` — 1 classes, 0 KB
- `index/pocketmine_level.md` — 159 classes, 44 KB
- `index/pocketmine_math.md` — 6 classes, 3 KB
- `index/pocketmine_metadata.md` — 7 classes, 2 KB
- `index/pocketmine_nbt.md` — 15 classes, 3 KB
- `index/pocketmine_network.md` — 132 classes, 29 KB
- `index/pocketmine_permission.md` — 10 classes, 3 KB
- `index/pocketmine_plugin.md` — 13 classes, 4 KB
- `index/pocketmine_root.md` — 11 classes, 10 KB
- `index/pocketmine_scheduler.md` — 12 classes, 3 KB
- `index/pocketmine_tile.md` — 18 classes, 6 KB
- `index/pocketmine_utils.md` — 26 classes, 10 KB
- `index/pocketmine_wizard.md` — 2 classes, 0 KB
- `index/raklib.md` — 50 classes, 9 KB
- `index/spl.md` — 20 classes, 3 KB
