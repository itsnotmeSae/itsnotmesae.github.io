# pocketmine_event (118 classes)

### BlockBreakEvent (class) — extends BlockEvent | implements Cancellable | pocketmine/event/block/BlockBreakEvent.php
public: __construct(Player $player, Block $block, Item $item, $instaBreak = false); getPlayer(); getItem(); getInstaBreak(); getDrops(); setDrops(array $drops); setInstaBreak($instaBreak)
### BlockBurnEvent (class) — extends BlockEvent | implements Cancellable | pocketmine/event/block/BlockBurnEvent.php
### BlockEvent (class) — extends Event | pocketmine/event/block/BlockEvent.php
public: __construct(Block $block); getBlock()
### BlockFormEvent (class) — extends BlockGrowEvent | implements Cancellable | pocketmine/event/block/BlockFormEvent.php
public: __construct(Block $block, Block $newState)
### BlockGrowEvent (class) — extends BlockEvent | implements Cancellable | pocketmine/event/block/BlockGrowEvent.php
public: __construct(Block $block, Block $newState); getNewState()
### BlockPlaceEvent (class) — extends BlockEvent | implements Cancellable | pocketmine/event/block/BlockPlaceEvent.php
public: __construct(Player $player, Block $blockPlace, Block $blockReplace, Block $blockAgainst, Item $item); getPlayer(); getItem(); getBlockReplaced(); getBlockAgainst()
### BlockSpreadEvent (class) — extends BlockFormEvent | implements Cancellable | pocketmine/event/block/BlockSpreadEvent.php
public: __construct(Block $block, Block $source, Block $newState); getSource()
### BlockUpdateEvent (class) — extends BlockEvent | implements Cancellable | pocketmine/event/block/BlockUpdateEvent.php
### Cancellable (interface) — pocketmine/event/Cancellable.php
public: isCancelled(); setCancelled($forceCancel = false)
### ChunkEvent (class) — extends LevelEvent | pocketmine/event/level/ChunkEvent.php
public: __construct(FullChunk $chunk); getChunk()
### ChunkLoadEvent (class) — extends ChunkEvent | pocketmine/event/level/ChunkLoadEvent.php
public: __construct(FullChunk $chunk, $newChunk); isNewChunk()
### ChunkPopulateEvent (class) — extends ChunkEvent | pocketmine/event/level/ChunkPopulateEvent.php
### ChunkUnloadEvent (class) — extends ChunkEvent | implements Cancellable | pocketmine/event/level/ChunkUnloadEvent.php
### CraftItemEvent (class) — extends Event | implements Cancellable | pocketmine/event/inventory/CraftItemEvent.php
public: __construct(Player $player, array $input, Recipe $recipe); getInput(); getRecipe(); getPlayer()
### CreeperPowerEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/CreeperPowerEvent.php
consts: CAUSE_SET_ON, CAUSE_SET_OFF, CAUSE_LIGHTNING
public: __construct(Creeper $creeper, Lightning $lightning = null, int $cause = self::CAUSE_LIGHTNING); getLightning(); getCause()
### DataPacketReceiveEvent (class) — extends ServerEvent | implements Cancellable | pocketmine/event/server/DataPacketReceiveEvent.php
public: __construct(Player $player, /*DataPacket*/ $packet); getPacket(); getPlayer()
### DataPacketSendEvent (class) — extends ServerEvent | implements Cancellable | pocketmine/event/server/DataPacketSendEvent.php
public: __construct(Player $player, /*DataPacket*/ $packet); getPacket(); getPlayer()
### EntityArmorChangeEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/EntityArmorChangeEvent.php
public: __construct(Entity $entity, Item $oldItem, Item $newItem, $slot); getSlot(); getNewItem(); setNewItem(Item $item); getOldItem()
### EntityBlockChangeEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/EntityBlockChangeEvent.php
public: __construct(Entity $entity, Block $from, Block $to); getBlock(); getTo()
### EntityCombustByBlockEvent (class) — extends EntityCombustEvent | pocketmine/event/entity/EntityCombustByBlockEvent.php
public: __construct(Block $combuster, Entity $combustee, $duration, $ProtectLevel = 0); getCombuster()
### EntityCombustByEntityEvent (class) — extends EntityCombustEvent | pocketmine/event/entity/EntityCombustByEntityEvent.php
public: __construct(Entity $combuster, Entity $combustee, $duration, $ProtectLevel = 0); getCombuster()
### EntityCombustEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/EntityCombustEvent.php
public: __construct(Entity $combustee, $duration, $ProtectLevel = 0); getDuration(); setDuration($duration); setProtectLevel($ProtectLevel)
### EntityDamageByBlockEvent (class) — extends EntityDamageEvent | pocketmine/event/entity/EntityDamageByBlockEvent.php
public: __construct(Block $damager, Entity $entity, $cause, $damage); getDamager()
### EntityDamageByChildEntityEvent (class) — extends EntityDamageByEntityEvent | pocketmine/event/entity/EntityDamageByChildEntityEvent.php
public: __construct(Entity $damager, Entity $childEntity, Entity $entity, $cause, $damage); getChild()
### EntityDamageByEntityEvent (class) — extends EntityDamageEvent | pocketmine/event/entity/EntityDamageByEntityEvent.php
public: __construct(Entity $damager, Entity $entity, $cause, $damage, $knockBack = 0.4); getDamager(); getKnockBack(); setKnockBack($knockBack)
protected: addAttackerModifiers(Entity $damager)
### EntityDamageEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/EntityDamageEvent.php
consts: MODIFIER_BASE, MODIFIER_RESISTANCE, MODIFIER_ARMOR, MODIFIER_PROTECTION, MODIFIER_STRENGTH, MODIFIER_WEAKNESS, CAUSE_CONTACT, CAUSE_ENTITY_ATTACK, CAUSE_PROJECTILE, CAUSE_SUFFOCATION, CAUSE_FALL, CAUSE_FIRE, CAUSE_FIRE_TICK, CAUSE_LAVA, CAUSE_DROWNING, CAUSE_BLOCK_EXPLOSION, CAUSE_ENTITY_EXPLOSION, CAUSE_VOID, CAUSE_SUICIDE, CAUSE_MAGIC, CAUSE_CUSTOM, CAUSE_STARVATION, CAUSE_LIGHTNING
public: __construct(Entity $entity, $cause, $damage); getCause(); getOriginalDamage($type = self::MODIFIER_BASE); getDamage($type = self::MODIFIER_BASE); setDamage($damage, $type = self::MODIFIER_BASE); getRateDamage($type = self::MODIFIER_BASE); setRateDamage($damage, $type = self::MODIFIER_BASE); isApplicable($type); getFinalDamage(); getUsedArmors(); getFireProtectL(); useArmors(); createThornsDamage(); getThornsDamage(); setThornsArmorUse()
### EntityDeathEvent (class) — extends EntityEvent | pocketmine/event/entity/EntityDeathEvent.php
public: __construct(Living $entity, array $drops = []); getEntity(); getDrops(); setDrops(array $drops)
### EntityDespawnEvent (class) — extends EntityEvent | pocketmine/event/entity/EntityDespawnEvent.php
public: __construct(Entity $entity); getType(); isCreature(); isHuman(); isProjectile(); isVehicle(); isItem()
### EntityDrinkPotionEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/EntityDrinkPotionEvent.php
public: __construct(Entity $entity, Potion $potion); getEffects(); getPotion()
### EntityEatBlockEvent (class) — extends EntityEatEvent | implements Cancellable | pocketmine/event/entity/EntityEatBlockEvent.php
public: __construct(Entity $entity, FoodSource $foodSource); getResidue(); setResidue($residue)
### EntityEatEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/EntityEatEvent.php
public: __construct(Entity $entity, FoodSource $foodSource); getFoodSource(); getFoodRestore(); setFoodRestore(int $foodRestore); getSaturationRestore(); setSaturationRestore(float $saturationRestore); getResidue(); setResidue($residue); getAdditionalEffects(); setAdditionalEffects(array $additionalEffects)
### EntityEatItemEvent (class) — extends EntityEatEvent | pocketmine/event/entity/EntityEatItemEvent.php
public: __construct(Entity $entity, Food $foodSource); getResidue(); setResidue($residue)
### EntityEffectAddEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/EntityEffectAddEvent.php
public: __construct(Entity $entity, Effect $effect); getEffect()
### EntityEffectRemoveEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/EntityEffectRemoveEvent.php
public: __construct(Entity $entity, int $effect); getEffect()
### EntityEvent (class) — extends Event | pocketmine/event/entity/EntityEvent.php
public: getEntity()
### EntityExplodeEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/EntityExplodeEvent.php
public: __construct(Entity $entity, Position $position, array $blocks, $yield); getPosition(); getBlockList(); setBlockList(array $blocks); getYield(); setYield($yield)
### EntityGenerateEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/EntityGenerateEvent.php
consts: CAUSE_AI_HOLDER, CAUSE_MOB_SPAWNER
public: __construct(Position $pos, int $entityType, int $cause = self::CAUSE_MOB_SPAWNER); getPosition(); setPosition(Position $pos); getType(); getCause()
### EntityInventoryChangeEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/EntityInventoryChangeEvent.php
public: __construct(Entity $entity, Item $oldItem, Item $newItem, $slot); getSlot(); getNewItem(); setNewItem(Item $item); getOldItem()
### EntityLevelChangeEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/EntityLevelChangeEvent.php
public: __construct(Entity $entity, Level $originLevel, Level $targetLevel); getOrigin(); getTarget()
### EntityMotionEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/EntityMotionEvent.php
public: __construct(Entity $entity, Vector3 $mot); getVector()
### EntityRegainHealthEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/EntityRegainHealthEvent.php
consts: CAUSE_REGEN, CAUSE_EATING, CAUSE_MAGIC, CAUSE_CUSTOM, CAUSE_SATURATION
public: __construct(Entity $entity, $amount, $regainReason); getAmount(); setAmount($amount); getRegainReason()
### EntityShootBowEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/EntityShootBowEvent.php
public: __construct(Living $shooter, Item $bow, Projectile $projectile, $force); getEntity(); getBow(); getProjectile(); setProjectile(Entity $projectile); getForce(); setForce($force)
### EntitySpawnEvent (class) — extends EntityEvent | pocketmine/event/entity/EntitySpawnEvent.php
public: __construct(Entity $entity); getPosition(); getType(); isCreature(); isHuman(); isProjectile(); isVehicle(); isItem()
### EntityTeleportEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/EntityTeleportEvent.php
public: __construct(Entity $entity, Position $from, Position $to); getFrom(); setFrom(Position $from); getTo(); setTo(Position $to)
### Event (class) — pocketmine/event/Event.php
public: isCancelled(); setCancelled($value = true); getHandlers()
### EventPriority (class) — pocketmine/event/EventPriority.php
consts: LOWEST, LOW, NORMAL, HIGH, HIGHEST, MONITOR
### ExplosionPrimeEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/ExplosionPrimeEvent.php
public: __construct(Entity $entity, $force, bool $dropItem); setDropItem(bool $dropItem); dropItem(); getForce(); setForce($force); isBlockBreaking(); setBlockBreaking($affectsBlocks)
### FurnaceBurnEvent (class) — extends BlockEvent | implements Cancellable | pocketmine/event/inventory/FurnaceBurnEvent.php
public: __construct(Furnace $furnace, Item $fuel, $burnTime); getFurnace(); getFuel(); getBurnTime(); setBurnTime($burnTime); isBurning(); setBurning($burning)
### FurnaceSmeltEvent (class) — extends BlockEvent | implements Cancellable | pocketmine/event/inventory/FurnaceSmeltEvent.php
public: __construct(Furnace $furnace, Item $source, Item $result); getFurnace(); getSource(); getResult(); setResult(Item $result)
### HandlerList (class) — pocketmine/event/HandlerList.php
public: static bakeAll(); static unregisterAll($object = null); __construct(); register(RegisteredListener $listener); registerAll(array $listeners); unregister($object); bake(); getRegisteredListeners($plugin = null); static getHandlerLists()
### InventoryCloseEvent (class) — extends InventoryEvent | pocketmine/event/inventory/InventoryCloseEvent.php
public: __construct(Inventory $inventory, Player $who); getPlayer()
### InventoryEvent (class) — extends Event | pocketmine/event/inventory/InventoryEvent.php
public: __construct(Inventory $inventory); getInventory(); getViewers()
### InventoryOpenEvent (class) — extends InventoryEvent | implements Cancellable | pocketmine/event/inventory/InventoryOpenEvent.php
public: __construct(Inventory $inventory, Player $who); getPlayer()
### InventoryPickupArrowEvent (class) — extends InventoryEvent | implements Cancellable | pocketmine/event/inventory/InventoryPickupArrowEvent.php
public: __construct(Inventory $inventory, Arrow $arrow); getArrow()
### InventoryPickupItemEvent (class) — extends InventoryEvent | implements Cancellable | pocketmine/event/inventory/InventoryPickupItemEvent.php
public: __construct(Inventory $inventory, Item $item); getItem()
### InventoryTransactionEvent (class) — extends Event | implements Cancellable | pocketmine/event/inventory/InventoryTransactionEvent.php
public: __construct(TransactionQueue $transactionQueue); getTransaction(); getQueue()
### ItemDespawnEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/ItemDespawnEvent.php
public: __construct(Item $item); getEntity()
### ItemFrameDropItemEvent (class) — extends BlockEvent | implements Cancellable | pocketmine/event/block/ItemFrameDropItemEvent.php
public: __construct(Player $player, Block $block, ItemFrame $itemFrame, Item $item); getPlayer(); getItemFrame(); getItem()
### ItemSpawnEvent (class) — extends EntityEvent | pocketmine/event/entity/ItemSpawnEvent.php
public: __construct(Item $item); getEntity()
### LeavesDecayEvent (class) — extends BlockEvent | implements Cancellable | pocketmine/event/block/LeavesDecayEvent.php
public: __construct(Block $block)
### LevelEvent (class) — extends Event | pocketmine/event/level/LevelEvent.php
public: __construct(Level $level); getLevel()
### LevelInitEvent (class) — extends LevelEvent | pocketmine/event/level/LevelInitEvent.php
### LevelLoadEvent (class) — extends LevelEvent | pocketmine/event/level/LevelLoadEvent.php
### LevelSaveEvent (class) — extends LevelEvent | pocketmine/event/level/LevelSaveEvent.php
### LevelTimings (class) — pocketmine/event/LevelTimings.php
public: __construct(Level $level)
### LevelUnloadEvent (class) — extends LevelEvent | implements Cancellable | pocketmine/event/level/LevelUnloadEvent.php
### Listener (interface) — pocketmine/event/Listener.php
### LowMemoryEvent (class) — extends ServerEvent | pocketmine/event/server/LowMemoryEvent.php
public: __construct($memory, $memoryLimit, $isGlobal = false, $triggerCount = 0); getMemory(); getMemoryLimit(); getTriggerCount(); isGlobal(); getMemoryFreed()
### PlayerAchievementAwardedEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerAchievementAwardedEvent.php
public: __construct(Player $player, $achievementId); getAchievement()
### PlayerAnimationEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerAnimationEvent.php
consts: ARM_SWING, WAKE_UP
public: __construct(Player $player, $animation = self::ARM_SWING); getAnimationType()
### PlayerBedEnterEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerBedEnterEvent.php
public: __construct(Player $player, Block $bed); getBed()
### PlayerBedLeaveEvent (class) — extends PlayerEvent | pocketmine/event/player/PlayerBedLeaveEvent.php
public: __construct(Player $player, Block $bed); getBed()
### PlayerBucketEmptyEvent (class) — extends PlayerBucketEvent | pocketmine/event/player/PlayerBucketEmptyEvent.php
public: __construct(Player $who, Block $blockClicked, $blockFace, Item $bucket, Item $itemInHand)
### PlayerBucketEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerBucketEvent.php
public: __construct(Player $who, Block $blockClicked, $blockFace, Item $bucket, Item $itemInHand); getBucket(); getItem(); setItem(Item $item); getBlockClicked(); getBlockFace()
### PlayerBucketFillEvent (class) — extends PlayerBucketEvent | pocketmine/event/player/PlayerBucketFillEvent.php
public: __construct(Player $who, Block $blockClicked, $blockFace, Item $bucket, Item $itemInHand)
### PlayerChatEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerChatEvent.php
public: __construct(Player $player, $message, $format = "chat.type.text", array $recipients = null); getMessage(); setMessage($message); setPlayer(Player $player); getFormat(); setFormat($format); getRecipients(); setRecipients(array $recipients)
### PlayerCommandPreprocessEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerCommandPreprocessEvent.php
public: __construct(Player $player, $message); getMessage(); setMessage($message); setPlayer(Player $player)
### PlayerCreationEvent (class) — extends Event | pocketmine/event/player/PlayerCreationEvent.php
public: __construct(SourceInterface $interface, $baseClass, $playerClass, $clientId, $address, $port); getInterface(); getAddress(); getPort(); getClientId(); getBaseClass(); setBaseClass($class); getPlayerClass(); setPlayerClass($class)
### PlayerDeathEvent (class) — extends EntityDeathEvent | pocketmine/event/player/PlayerDeathEvent.php
public: __construct(Player $entity, array $drops, $deathMessage); getEntity(); getPlayer(); getDeathMessage(); setDeathMessage($deathMessage); getKeepInventory(); setKeepInventory(bool $keepInventory); getKeepExperience(); setKeepExperience(bool $keepExperience)
### PlayerDropItemEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerDropItemEvent.php
public: __construct(Player $player, Item $drop); getItem()
### PlayerEvent (class) — extends Event | pocketmine/event/player/PlayerEvent.php
public: getPlayer()
### PlayerExhaustEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerExhaustEvent.php
consts: CAUSE_ATTACK, CAUSE_DAMAGE, CAUSE_MINING, CAUSE_HEALTH_REGEN, CAUSE_POTION, CAUSE_WALKING, CAUSE_SNEAKING, CAUSE_SWIMMING, CAUSE_JUMPING, CAUSE_CUSTOM, CAUSE_FLAG_SPRINT
public: __construct(Human $human, float $amount, int $cause); getPlayer(); getAmount(); setAmount(float $amount)
### PlayerExperienceChangeEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerExperienceChangeEvent.php
consts: ADD_EXPERIENCE, SET_EXPERIENCE
public: __construct(Human $player, int $expLevel, float $progress); getAction(); getExpLevel(); setExpLevel($level); getProgress(); setProgress(float $progress); getExp(); setExp($exp)
### PlayerFishEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerFishEvent.php
public: __construct(Player $player, Item $item, $fishingHook = null); getItem(); getHook()
### PlayerGameModeChangeEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerGameModeChangeEvent.php
public: __construct(Player $player, $newGamemode); getNewGamemode()
### PlayerGlassBottleEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerGlassBottleEvent.php
public: __construct(Player $Player, Block $target, Item $itemInHand); getItem(); setItem(Item $item); getBlock()
### PlayerHungerChangeEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerHungerChangeEvent.php
public: __construct(Player $player, $data); getData(); setData($data)
### PlayerInteractEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerInteractEvent.php
consts: LEFT_CLICK_BLOCK, RIGHT_CLICK_BLOCK, LEFT_CLICK_AIR, RIGHT_CLICK_AIR, PHYSICAL
public: __construct(Player $player, Item $item, Vector3 $block, $face, $action = PlayerInteractEvent::RIGHT_CLICK_BLOCK); getAction(); getItem(); getBlock(); getTouchVector(); getFace()
### PlayerItemConsumeEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerItemConsumeEvent.php
public: __construct(Player $player, Item $item); getItem()
### PlayerItemHeldEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerItemHeldEvent.php
public: __construct(Player $player, Item $item, $inventorySlot, $slot); getSlot(); getInventorySlot(); getItem()
### PlayerJoinEvent (class) — extends PlayerEvent | pocketmine/event/player/PlayerJoinEvent.php
public: __construct(Player $player, $joinMessage); setJoinMessage($joinMessage); getJoinMessage()
### PlayerKickEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerKickEvent.php
public: __construct(Player $player, $reason, $quitMessage); getReason(); setQuitMessage($quitMessage); getQuitMessage()
### PlayerLoginEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerLoginEvent.php
public: __construct(Player $player, $kickMessage); setKickMessage($kickMessage); getKickMessage()
### PlayerMoveEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerMoveEvent.php
public: __construct(Player $player, Location $from, Location $to); getFrom(); setFrom(Location $from); getTo(); setTo(Location $to)
### PlayerPickupExpOrbEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerPickupExpOrbEvent.php
public: __construct(Player $p, int $amount = 0); getAmount(); setAmount(int $amount)
### PlayerPreLoginEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerPreLoginEvent.php
public: __construct(Player $player, $kickMessage); setKickMessage($kickMessage); getKickMessage()
### PlayerQuitEvent (class) — extends PlayerEvent | pocketmine/event/player/PlayerQuitEvent.php
public: __construct(Player $player, $quitMessage, $autoSave = true); setQuitMessage($quitMessage); getQuitMessage(); getAutoSave(); setAutoSave($value = true)
### PlayerRespawnEvent (class) — extends PlayerEvent | pocketmine/event/player/PlayerRespawnEvent.php
public: __construct(Player $player, Position $position); getRespawnPosition(); setRespawnPosition(Position $position)
### PlayerTextPreSendEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerTextPreSendEvent.php
consts: MESSAGE, POPUP, TIP, TRANSLATED_MESSAGE
public: __construct(Player $player, $message, $type = self::MESSAGE); getMessage(); setMessage($message); getType()
### PlayerToggleSneakEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerToggleSneakEvent.php
public: __construct(Player $player, $isSneaking); isSneaking()
### PlayerToggleSprintEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerToggleSprintEvent.php
public: __construct(Player $player, $isSprinting); isSprinting()
### PlayerUseFishingRodEvent (class) — extends PlayerEvent | implements Cancellable | pocketmine/event/player/PlayerUseFishingRodEvent.php
consts: ACTION_START_FISHING, ACTION_STOP_FISHING
public: __construct(Player $player, int $action = PlayerUseFishingRodEvent::ACTION_START_FISHING); getAction()
### PluginDisableEvent (class) — extends PluginEvent | pocketmine/event/plugin/PluginDisableEvent.php
public: __construct(Plugin $plugin)
### PluginEnableEvent (class) — extends PluginEvent | pocketmine/event/plugin/PluginEnableEvent.php
public: __construct(Plugin $plugin)
### PluginEvent (class) — extends Event | pocketmine/event/plugin/PluginEvent.php
public: __construct(Plugin $plugin); getPlugin()
### ProjectileHitEvent (class) — extends EntityEvent | pocketmine/event/entity/ProjectileHitEvent.php
public: __construct(Projectile $entity); getEntity()
### ProjectileLaunchEvent (class) — extends EntityEvent | implements Cancellable | pocketmine/event/entity/ProjectileLaunchEvent.php
public: __construct(Projectile $entity); getEntity()
### QueryRegenerateEvent (class) — extends ServerEvent | pocketmine/event/server/QueryRegenerateEvent.php
consts: GAME_ID
public: __construct(Server $server, $timeout = 5); getTimeout(); setTimeout($timeout); getServerName(); setServerName($serverName); canListPlugins(); setListPlugins($value); getPlugins(); setPlugins(array $plugins); getPlayerList(); setPlayerList(array $players); getPlayerCount(); setPlayerCount($count); getMaxPlayerCount(); setMaxPlayerCount($count); getWorld(); setWorld($world); getExtraData(); setExtraData(array $extraData); getLongQuery(); getShortQuery()
### RemoteServerCommandEvent (class) — extends ServerCommandEvent | pocketmine/event/server/RemoteServerCommandEvent.php
public: __construct(CommandSender $sender, $command)
### ServerCommandEvent (class) — extends ServerEvent | implements Cancellable | pocketmine/event/server/ServerCommandEvent.php
public: __construct(CommandSender $sender, $command); getSender(); getCommand(); setCommand($command)
### ServerEvent (class) — extends Event | pocketmine/event/server/ServerEvent.php
### SignChangeEvent (class) — extends BlockEvent | implements Cancellable | pocketmine/event/block/SignChangeEvent.php
public: __construct(Block $theBlock, Player $thePlayer, array $theLines); getPlayer(); getLines(); getLine($index); setLine($index, $line)
### SpawnChangeEvent (class) — extends LevelEvent | pocketmine/event/level/SpawnChangeEvent.php
public: __construct(Level $level, Position $previousSpawn); getPreviousSpawn()
### TextContainer (class) — pocketmine/event/TextContainer.php
public: __construct($text); setText($text); getText(); __toString()
### Timings (class) — pocketmine/event/Timings.php
public: static init(); static getPluginTaskTimings(TaskHandler $task, $period); static getEntityTimings(Entity $entity); static getTileEntityTimings(Tile $tile); static getReceiveDataPacketTimings(/*DataPacket*/ $pk); static getSendDataPacketTimings(/*DataPacket*/ $pk)
### TimingsHandler (class) — pocketmine/event/TimingsHandler.php
public: __construct($name, TimingsHandler $parent = null); static printTimings($fp); static reload(); static tick($measure = true); startTiming(); stopTiming(); reset(); remove()
### TranslationContainer (class) — extends TextContainer | pocketmine/event/TranslationContainer.php
public: __construct($text, array $params = []); getParameters(); getParameter($i); setParameter($i, $str); setParameters(array $params)
### WeatherChangeEvent (class) — extends LevelEvent | implements Cancellable | pocketmine/event/level/WeatherChangeEvent.php
public: __construct(Level $level, int $weather, int $duration); getWeather(); setWeather(int $weather = Weather::SUNNY); getDuration(); setDuration(int $duration)
