# pocketmine_level (159 classes)

### AcaciaTree (class) — extends Tree | pocketmine/level/generator/object/AcaciaTree.php
public: __construct()
### AngryVillagerParticle (class) — extends GenericParticle | pocketmine/level/particle/AngryVillagerParticle.php
public: __construct(Vector3 $pos)
### Anvil (class) — extends McRegion | pocketmine/level/format/anvil/Anvil.php
public: static getProviderName(); static getProviderOrder(); static usesChunkSection(); static isValid($path); requestChunkTask($x, $z); getChunk($chunkX, $chunkZ, $create = false); setChunk($chunkX, $chunkZ, FullChunk $chunk); getEmptyChunk($chunkX, $chunkZ); static createChunkSection($Y); isChunkGenerated($chunkX, $chunkZ)
protected: getRegion($x, $z); loadRegion($x, $z)
### AnvilFallSound (class) — extends GenericSound | pocketmine/level/sound/AnvilFallSound.php
public: __construct(Vector3 $pos, $pitch = 0)
### AnvilUseSound (class) — extends GenericSound | pocketmine/level/sound/AnvilUseSound.php
public: __construct(Vector3 $pos, $pitch = 0)
### BaseChunk (class) — extends BaseFullChunk | implements Chunk | pocketmine/level/format/generic/BaseChunk.php
public: getFullBlock($x, $y, $z); setBlock($x, $y, $z, $blockId = null, $meta = null); getBlockId($x, $y, $z); setBlockId($x, $y, $z, $id); getBlockData($x, $y, $z); setBlockData($x, $y, $z, $data); getBlockSkyLight($x, $y, $z); setBlockSkyLight($x, $y, $z, $data); getBlockLight($x, $y, $z); setBlockLight($x, $y, $z, $data); getBlockIdColumn($x, $z); getBlockDataColumn($x, $z); getBlockSkyLightColumn($x, $z); getBlockLightColumn($x, $z); isSectionEmpty($fY); getSection($fY); setSection($fY, ChunkSection $section); load($generate = true); getBlockIdArray(); getBlockDataArray(); getBlockSkyLightArray(); getBlockLightArray(); getSections()
protected: __construct($provider, $x, $z, array $sections, array $biomeColors = [], array $heightMap = [], array $entities = [], array $tiles = [])
### BaseFullChunk (class) — implements FullChunk | pocketmine/level/format/generic/BaseFullChunk.php
public: initChunk(); getX(); getZ(); setX($x); setZ($z); getProvider(); setProvider(LevelProvider $provider); getBiomeId($x, $z); setBiomeId($x, $z, $biomeId); getBiomeColor($x, $z); setBiomeColor($x, $z, $R, $G, $B); getHeightMap($x, $z); setHeightMap($x, $z, $value); recalculateHeightMap(); getBlockExtraData($x, $y, $z); setBlockExtraData($x, $y, $z, $data); populateSkyLight(); getHighestBlockAt($x, $z, $cache = true); addEntity(Entity $entity); removeEntity(Entity $entity); addTile(Tile $tile); removeTile(Tile $tile); getEntities(); getTiles(); getBlockExtraDataArray(); getTile($x, $y, $z); isLoaded(); load($generate = true); unload($save = true, $safe = true); getBlockIdArray(); getBlockDataArray(); getBlockSkyLightArray(); getBlockLightArray(); getBiomeIdArray(); getBiomeColorArray(); getHeightMapArray(); hasChanged(); setChanged($changed = true); static fromFastBinary($data, LevelProvider $provider = null); toFastBinary(); isLightPopulated(); setLightPopulated($value = 1)
protected: __construct($provider, $x, $z, $blocks, $data, $skyLight, $blockLight, array $biomeColors = [], array $heightMap = [], array $entities = [], array $tiles = [], array $extraData = []); checkOldBiomes($data)
### BaseLevelProvider (class) — implements LevelProvider | pocketmine/level/format/generic/BaseLevelProvider.php
public: __construct(Level $level, $path); getPath(); getServer(); getLevel(); getName(); getTime(); setTime($value); getSeed(); setSeed($value); getSpawn(); setSpawn(Vector3 $pos); doGarbageCollection(); getLevelData(); saveLevelData()
### BatSound (class) — extends GenericSound | pocketmine/level/sound/BatSound.php
public: __construct(Vector3 $pos, $pitch = 0)
### BigTree (class) — extends Tree | pocketmine/level/generator/object/BigTree.php
public: canPlaceObject(ChunkManager $level, $x, $y, $z, Random $random); placeObject(ChunkManager $level, $x, $y, $z, Random $random)
### Biome (class) — pocketmine/level/generator/biome/Biome.php
consts: OCEAN, PLAINS, DESERT, MOUNTAINS, FOREST, TAIGA, SWAMP, RIVER, HELL, ICE_PLAINS, SMALL_MOUNTAINS, BIRCH_FOREST, MAX_BIOMES
public: static init(); static getBiome($id); clearPopulators(); addPopulator(Populator $populator); populateChunk(ChunkManager $level, $chunkX, $chunkZ, Random $random); getPopulators(); setId($id); getId(); getMinElevation(); getMaxElevation(); setElevation($min, $max); getGroundCover(); setGroundCover(array $covers); getTemperature(); getRainfall()
protected: static register($id, Biome $biome)
### BiomeSelector (class) — pocketmine/level/generator/biome/BiomeSelector.php
public: __construct(Random $random, callable $lookup, Biome $fallback); recalculate(); addBiome(Biome $biome); getTemperature($x, $z); getRainfall($x, $z); pickBiome($x, $z)
### BirchTree (class) — extends Tree | pocketmine/level/generator/object/BirchTree.php
public: __construct($superBirch = false); placeObject(ChunkManager $level, $x, $y, $z, Random $random)
### BlazeShootSound (class) — extends GenericSound | pocketmine/level/sound/BlazeShootSound.php
public: __construct(Vector3 $pos, $pitch = 0)
### BlockPlaceSound (class) — extends GenericSound | pocketmine/level/sound/BlockPlaceSound.php
public: __construct(Block $b); encode()
### BubbleParticle (class) — extends GenericParticle | pocketmine/level/particle/BubbleParticle.php
public: __construct(Vector3 $pos)
### ButtonClickSound (class) — extends GenericSound | pocketmine/level/sound/ButtonClickSound.php
public: __construct(Vector3 $pos)
### Cactus (class) — extends Populator | pocketmine/level/generator/populator/Cactus.php
public: setRandomAmount($amount); setBaseAmount($amount); populate(ChunkManager $level, $chunkX, $chunkZ, Random $random)
### Cave (class) — extends Populator | pocketmine/level/generator/populator/Cave.php
public: populate(ChunkManager $level, $chunkX, $chunkZ, Random $random); __construct(ChunkManager $level, Vector3 $chunk, Vector3 $start, Vector3 $end, Vector3 $target, $verticalSize, $horizontalSize); canPlace(); place()
### Chunk (interface) — extends FullChunk | pocketmine/level/format/Chunk.php
consts: SECTION_COUNT
public: isSectionEmpty($fY); getSection($fY); setSection($fY, ChunkSection $section); getSections()
### Chunk (class) — extends BaseChunk | pocketmine/level/format/anvil/Chunk.php
public: __construct($level, CompoundTag $nbt = null); isLightPopulated(); setLightPopulated($value = 1); isPopulated(); setPopulated($value = 1); isGenerated(); setGenerated($value = 1); getNBT(); static fromBinary($data, LevelProvider $provider = null); static fromFastBinary($data, LevelProvider $provider = null); toFastBinary(); toBinary(); static getEmptyChunk($chunkX, $chunkZ, LevelProvider $provider = null)
### Chunk (class) — extends BaseFullChunk | pocketmine/level/format/leveldb/Chunk.php
consts: DATA_LENGTH
public: __construct($level, $chunkX, $chunkZ, $terrain, array $entityData = null, array $tileData = null); getBlockId($x, $y, $z); setBlockId($x, $y, $z, $id); getBlockData($x, $y, $z); setBlockData($x, $y, $z, $data); getFullBlock($x, $y, $z); setBlock($x, $y, $z, $blockId = null, $meta = null); getBlockSkyLight($x, $y, $z); setBlockSkyLight($x, $y, $z, $level); getBlockLight($x, $y, $z); setBlockLight($x, $y, $z, $level); getBlockIdColumn($x, $z); getBlockDataColumn($x, $z); getBlockSkyLightColumn($x, $z); getBlockLightColumn($x, $z); isLightPopulated(); setLightPopulated($value = 1); isPopulated(); setPopulated($value = 1); isGenerated(); setGenerated($value = 1); static fromFastBinary($data, LevelProvider $provider = null); static fromBinary($data, LevelProvider $provider = null); toFastBinary(); toBinary($saveExtra = false); static getEmptyChunk($chunkX, $chunkZ, LevelProvider $provider = null)
### Chunk (class) — extends BaseFullChunk | pocketmine/level/format/mcregion/Chunk.php
public: __construct($level, CompoundTag $nbt = null); getBlockId($x, $y, $z); setBlockId($x, $y, $z, $id); getBlockData($x, $y, $z); setBlockData($x, $y, $z, $data); getFullBlock($x, $y, $z); setBlock($x, $y, $z, $blockId = null, $meta = null); getBlockSkyLight($x, $y, $z); setBlockSkyLight($x, $y, $z, $level); getBlockLight($x, $y, $z); setBlockLight($x, $y, $z, $level); getBlockIdColumn($x, $z); getBlockDataColumn($x, $z); getBlockSkyLightColumn($x, $z); getBlockLightColumn($x, $z); isLightPopulated(); setLightPopulated($value = 1); isPopulated(); setPopulated($value = 1); isGenerated(); setGenerated($value = 1); static fromBinary($data, LevelProvider $provider = null); static fromFastBinary($data, LevelProvider $provider = null); toFastBinary(); toBinary(); getNBT(); static getEmptyChunk($chunkX, $chunkZ, LevelProvider $provider = null)
### ChunkLoader (interface) — pocketmine/level/ChunkLoader.php
public: getLoaderId(); isLoaderActive(); getPosition(); getX(); getZ(); getLevel(); onChunkChanged(FullChunk $chunk); onChunkLoaded(FullChunk $chunk); onChunkUnloaded(FullChunk $chunk); onChunkPopulated(FullChunk $chunk); onBlockChanged(Vector3 $block)
### ChunkManager (interface) — pocketmine/level/ChunkManager.php
public: getBlockIdAt(int $x, int $y, int $z); setBlockIdAt(int $x, int $y, int $z, int $id); getBlockDataAt(int $x, int $y, int $z); setBlockDataAt(int $x, int $y, int $z, int $data); getBlockLightAt(int $x, int $y, int $z); updateBlockLight(int $x, int $y, int $z); setBlockLightAt(int $x, int $y, int $z, int $level); getChunk(int $chunkX, int $chunkZ); setChunk(int $chunkX, int $chunkZ, FullChunk $chunk = null); getSeed()
### ChunkRequestTask (class) — extends AsyncTask | pocketmine/level/format/anvil/ChunkRequestTask.php
public: __construct(Level $level, Chunk $chunk); onRun(); onCompletion(Server $server)
### ChunkRequestTask (class) — extends AsyncTask | pocketmine/level/format/mcregion/ChunkRequestTask.php
public: __construct(Level $level, Chunk $chunk); onRun(); onCompletion(Server $server)
### ChunkSection (interface) — pocketmine/level/format/ChunkSection.php
public: getY(); getBlockId($x, $y, $z); setBlockId($x, $y, $z, $id); getBlockData($x, $y, $z); setBlockData($x, $y, $z, $data); getFullBlock($x, $y, $z); setBlock($x, $y, $z, $blockId = null, $meta = null); getBlockSkyLight($x, $y, $z); setBlockSkyLight($x, $y, $z, $level); getBlockLight($x, $y, $z); setBlockLight($x, $y, $z, $level); getBlockIdColumn($x, $z); getBlockDataColumn($x, $z); getBlockSkyLightColumn($x, $z); getBlockLightColumn($x, $z); getIdArray(); getDataArray(); getSkyLightArray(); getLightArray()
### ChunkSection (class) — implements \pocketmine\level\format\ChunkSection | pocketmine/level/format/anvil/ChunkSection.php
public: __construct(CompoundTag $nbt); getY(); getBlockId($x, $y, $z); setBlockId($x, $y, $z, $id); getBlockData($x, $y, $z); setBlockData($x, $y, $z, $data); getBlock($x, $y, $z, &$blockId, &$meta = null); getFullBlock($x, $y, $z); setBlock($x, $y, $z, $blockId = null, $meta = null); getBlockSkyLight($x, $y, $z); setBlockSkyLight($x, $y, $z, $level); getBlockLight($x, $y, $z); setBlockLight($x, $y, $z, $level); getBlockIdColumn($x, $z); getBlockDataColumn($x, $z); getBlockSkyLightColumn($x, $z); getBlockLightColumn($x, $z); getIdArray(); getDataArray(); getSkyLightArray(); getLightArray()
### ClickSound (class) — extends GenericSound | pocketmine/level/sound/ClickSound.php
public: __construct(Vector3 $pos, $pitch = 0)
### CriticalParticle (class) — extends GenericParticle | pocketmine/level/particle/CriticalParticle.php
public: __construct(Vector3 $pos, $scale = 2)
### DarkOakTree (class) — extends Tree | pocketmine/level/generator/object/DarkOakTree.php
public: __construct()
### DeadBush (class) — extends Populator | pocketmine/level/generator/populator/DeadBush.php
public: setRandomAmount($amount); setBaseAmount($amount); populate(ChunkManager $level, $chunkX, $chunkZ, Random $random)
### DesertBiome (class) — extends SandyBiome | pocketmine/level/generator/normal/biome/DesertBiome.php
public: __construct(); getName()
### DestroyBlockParticle (class) — extends Particle | pocketmine/level/particle/DestroyBlockParticle.php
public: __construct(Vector3 $pos, Block $b); encode()
### DoorBumpSound (class) — extends GenericSound | pocketmine/level/sound/DoorBumpSound.php
public: __construct(Vector3 $pos, $pitch = 0)
### DoorCrashSound (class) — extends GenericSound | pocketmine/level/sound/DoorCrashSound.php
public: __construct(Vector3 $pos, $pitch = 0)
### DoorSound (class) — extends GenericSound | pocketmine/level/sound/DoorSound.php
public: __construct(Vector3 $pos, $pitch = 0)
### DustParticle (class) — extends GenericParticle | pocketmine/level/particle/DustParticle.php
public: __construct(Vector3 $pos, $r, $g, $b, $a = 255)
### EmptyChunkSection (class) — implements ChunkSection | pocketmine/level/format/generic/EmptyChunkSection.php
public: __construct($y); getIdArray(); getDataArray(); getSkyLightArray(); getLightArray()
### EnchantParticle (class) — extends GenericParticle | pocketmine/level/particle/EnchantParticle.php
public: __construct(Vector3 $pos)
### EnchantmentTableParticle (class) — extends GenericParticle | pocketmine/level/particle/EnchantmentTableParticle.php
public: __construct(Vector3 $pos)
### EndermanTeleportSound (class) — extends GenericSound | pocketmine/level/sound/EndermanTeleportSound.php
public: __construct(Vector3 $pos)
### EntityFlameParticle (class) — extends GenericParticle | pocketmine/level/particle/EntityFlameParticle.php
public: __construct(Vector3 $pos)
### ExpPickupSound (class) — extends GenericSound | pocketmine/level/sound/ExpPickupSound.php
public: __construct(Vector3 $pos, $pitch = 0)
### ExplodeParticle (class) — extends GenericParticle | pocketmine/level/particle/ExplodeParticle.php
public: __construct(Vector3 $pos)
### ExplodeSound (class) — extends GenericSound | pocketmine/level/sound/ExplodeSound.php
public: __construct(Vector3 $pos, $pitch = 0)
### Explosion (class) — pocketmine/level/Explosion.php
public: __construct(Position $center, $size, $what = null, bool $dropItem = true); explodeA(); explodeB()
### FizzSound (class) — extends GenericSound | pocketmine/level/sound/FizzSound.php
public: __construct(Vector3 $pos, $pitch = 0)
### FlameParticle (class) — extends GenericParticle | pocketmine/level/particle/FlameParticle.php
public: __construct(Vector3 $pos)
### Flat (class) — extends Generator | pocketmine/level/generator/Flat.php
public: getSettings(); getName(); __construct(array $options = []); init(ChunkManager $level, Random $random); generateChunk($chunkX, $chunkZ); populateChunk($chunkX, $chunkZ); getSpawn()
protected: parsePreset($preset, $chunkX, $chunkZ)
### FloatingTextParticle (class) — extends Particle | pocketmine/level/particle/FloatingTextParticle.php
public: __construct(Vector3 $pos, $text, $title = ""); setText($text); setTitle($title); isInvisible(); setInvisible($value = true); encode()
### Flower (class) — extends Populator | pocketmine/level/generator/populator/Flower.php
public: setRandomAmount($amount); setBaseAmount($amount); addType($type); getTypes(); populate(ChunkManager $level, $chunkX, $chunkZ, Random $random)
### ForestBiome (class) — extends GrassyBiome | pocketmine/level/generator/normal/biome/ForestBiome.php
consts: TYPE_NORMAL, TYPE_BIRCH
public: __construct($type = self::TYPE_NORMAL); getName()
### FullChunk (interface) — pocketmine/level/format/FullChunk.php
public: getX(); getZ(); setX($x); setZ($z); getProvider(); setProvider(LevelProvider $provider); getFullBlock($x, $y, $z); setBlock($x, $y, $z, $blockId = null, $meta = null); getBlockId($x, $y, $z); setBlockId($x, $y, $z, $id); getBlockData($x, $y, $z); setBlockData($x, $y, $z, $data); getBlockExtraData($x, $y, $z); setBlockExtraData($x, $y, $z, $data); getBlockSkyLight($x, $y, $z); setBlockSkyLight($x, $y, $z, $level); getBlockLight($x, $y, $z); setBlockLight($x, $y, $z, $level); getHighestBlockAt($x, $z); getHeightMap($x, $z); setHeightMap($x, $z, $value); recalculateHeightMap(); populateSkyLight(); getBiomeId($x, $z); setBiomeId($x, $z, $biomeId); getBiomeColor($x, $z); getBlockIdColumn($x, $z); getBlockDataColumn($x, $z); getBlockSkyLightColumn($x, $z); getBlockLightColumn($x, $z); setBiomeColor($x, $z, $R, $G, $B); isLightPopulated(); setLightPopulated($value = 1); isPopulated(); setPopulated($value = 1); isGenerated(); setGenerated($value = 1); addEntity(Entity $entity); removeEntity(Entity $entity); addTile(Tile $tile); removeTile(Tile $tile); getEntities(); getTiles(); getTile($x, $y, $z); isLoaded(); load($generate = true); unload($save = true, $safe = true); initChunk(); getBiomeIdArray(); getBiomeColorArray(); getHeightMapArray(); getBlockIdArray(); getBlockDataArray(); getBlockExtraDataArray(); getBlockSkyLightArray(); getBlockLightArray(); toBinary(); toFastBinary(); hasChanged(); setChanged($changed = true); static fromBinary($data, LevelProvider $provider = null); static fromFastBinary($data, LevelProvider $provider = null); static getEmptyChunk($chunkX, $chunkZ, LevelProvider $provider = null)
### GenerationTask (class) — extends AsyncTask | pocketmine/level/generator/GenerationTask.php
public: __construct(Level $level, FullChunk $chunk); onRun(); onCompletion(Server $server)
### Generator (class) — pocketmine/level/generator/Generator.php
public: static addGenerator($object, $name); static getGeneratorList(); static getGenerator($name); static getGeneratorName($class); static getFastNoise1D(Noise $noise, $xSize, $samplingRate, $x, $y, $z); static getFastNoise2D(Noise $noise, $xSize, $zSize, $samplingRate, $x, $y, $z); static getFastNoise3D(Noise $noise, $xSize, $ySize, $zSize, $xSamplingRate, $ySamplingRate, $zSamplingRate, $x, $y, $z); getWaterHeight()
### GeneratorRegisterTask (class) — extends AsyncTask | pocketmine/level/generator/GeneratorRegisterTask.php
public: __construct(Level $level, Generator $generator); onRun()
### GeneratorUnregisterTask (class) — extends AsyncTask | pocketmine/level/generator/GeneratorUnregisterTask.php
public: __construct(Level $level); onRun()
### GenericParticle (class) — extends Particle | pocketmine/level/particle/GenericParticle.php
public: __construct(Vector3 $pos, $id, $data = 0); encode()
### GenericSound (class) — extends Sound | pocketmine/level/sound/GenericSound.php
public: __construct(Vector3 $pos, $id, $pitch = 0); getPitch(); setPitch($pitch); encode()
### GhastShootSound (class) — extends GenericSound | pocketmine/level/sound/GhastShootSound.php
public: __construct(Vector3 $pos, $pitch = 0)
### GhastSound (class) — extends GenericSound | pocketmine/level/sound/GhastSound.php
public: __construct(Vector3 $pos, $pitch = 0)
### GrassyBiome (class) — extends NormalBiome | pocketmine/level/generator/normal/biome/GrassyBiome.php
public: __construct()
### GraySplashSound (class) — extends GenericSound | pocketmine/level/sound/GraySplashSound.php
public: __construct(Vector3 $pos, $pitch = 0)
### GroundCover (class) — extends Populator | pocketmine/level/generator/populator/GroundCover.php
public: populate(ChunkManager $level, $chunkX, $chunkZ, Random $random)
### GroundFire (class) — extends Populator | pocketmine/level/generator/populator/GroundFire.php
public: setRandomAmount($amount); setBaseAmount($amount); populate(ChunkManager $level, $chunkX, $chunkZ, Random $random)
### HappyVillagerParticle (class) — extends GenericParticle | pocketmine/level/particle/HappyVillagerParticle.php
public: __construct(Vector3 $pos)
### HeartParticle (class) — extends GenericParticle | pocketmine/level/particle/HeartParticle.php
public: __construct(Vector3 $pos, $scale = 0)
### HellBiome (class) — extends Biome | pocketmine/level/generator/hell/HellBiome.php
public: getName(); getColor()
### HugeExplodeParticle (class) — extends GenericParticle | pocketmine/level/particle/HugeExplodeParticle.php
public: __construct(Vector3 $pos)
### IcePlainsBiome (class) — extends SnowyBiome | pocketmine/level/generator/normal/biome/IcePlainsBiome.php
public: __construct(); getName()
### InkParticle (class) — extends GenericParticle | pocketmine/level/particle/InkParticle.php
public: __construct(Vector3 $pos, $scale = 0)
### InstantEnchantParticle (class) — extends GenericParticle | pocketmine/level/particle/InstantEnchantParticle.php
public: __construct(Vector3 $pos)
### ItemBreakParticle (class) — extends GenericParticle | pocketmine/level/particle/ItemBreakParticle.php
public: __construct(Vector3 $pos, Item $item)
### JungleTree (class) — extends Tree | pocketmine/level/generator/object/JungleTree.php
public: __construct()
### LargeExplodeParticle (class) — extends GenericParticle | pocketmine/level/particle/LargeExplodeParticle.php
public: __construct(Vector3 $pos)
### LaunchSound (class) — extends GenericSound | pocketmine/level/sound/LaunchSound.php
public: __construct(Vector3 $pos, $pitch = 0)
### LavaDripParticle (class) — extends GenericParticle | pocketmine/level/particle/LavaDripParticle.php
public: __construct(Vector3 $pos)
### LavaParticle (class) — extends GenericParticle | pocketmine/level/particle/LavaParticle.php
public: __construct(Vector3 $pos)
### Level (class) — implements ChunkManager, Metadatable | pocketmine/level/Level.php
consts: BLOCK_UPDATE_NORMAL, BLOCK_UPDATE_RANDOM, BLOCK_UPDATE_SCHEDULED, BLOCK_UPDATE_WEAK, BLOCK_UPDATE_TOUCH, TIME_DAY, TIME_SUNSET, TIME_NIGHT, TIME_SUNRISE, TIME_FULL, DIMENSION_NORMAL, DIMENSION_NETHER
public: setBlockTempData(Vector3 $pos, $data = null); getBlockTempData(Vector3 $pos); static chunkHash(int $x, int $z); static blockHash(int $x, int $y, int $z); static chunkBlockHash(int $x, int $y, int $z); static getBlockXYZ($hash, &$x, &$y, &$z); static getXZ($hash, &$x, &$z); static generateChunkLoaderId(ChunkLoader $loader); __construct(Server $server, string $name, string $path, string $provider); setDimension(int $dimension); getDimension(); getWeather(); getTickRate(); getTickRateTime(); setTickRate(int $tickRate); initLevel(); getWaterHeight(); registerGenerator(); unregisterGenerator(); getBlockMetadata(); getServer(); close(); addSound(Sound $sound, array $players = null); addParticle(Particle $particle, array $players = null); getAutoSave(); setAutoSave(bool $value); unload(bool $force = false); getChunkPlayers(int $chunkX, int $chunkZ); getChunkLoaders(int $chunkX, int $chunkZ); addChunkPacket(int $chunkX, int $chunkZ, DataPacket $packet); registerChunkLoader(ChunkLoader $loader, int $chunkX, int $chunkZ, bool $autoLoad = true); unregisterChunkLoader(ChunkLoader $loader, int $chunkX, int $chunkZ); checkTime(); sendTime(); doTick(int $currentTick); checkSleep(); sendBlockExtraData(int $x, int $y, int $z, int $id, int $data, array $targets = null); sendBlocks(array $target, array $blocks, $flags = UpdateBlockPacket::FLAG_NONE, bool $optimizeRebuilds = false); clearCache(bool $full = false); clearChunkCache(int $chunkX, int $chunkZ); __debugInfo(); save(bool $force = false); saveChunks(); updateAround(Vector3 $pos); scheduleUpdate(Vector3 $pos, int $delay); getCollisionBlocks(AxisAlignedBB $bb, bool $targetFirst = false); isFullBlock(Vector3 $pos); getCollisionCubes(Entity $entity, AxisAlignedBB $bb, bool $entities = true); rayTraceBlocks(Vector3 $pos1, Vector3 $pos2, $flag = false, $flag1 = false, $flag2 = false); getFullLight(Vector3 $pos); getFullBlock(int $x, int $y, int $z); getBlock(Vector3 $pos, $cached = true); updateAllLight(Vector3 $pos); updateBlockSkyLight(int $x, int $y, int $z); updateBlockLight(int $x, int $y, int $z); setBlock(Vector3 $pos, Block $block, bool $direct = false, bool $update = true); dropItem(Vector3 $source, Item $item, Vector3 $motion = null, int $delay = 10); useBreakOn(Vector3 $vector, Item &$item = null, Player $player = null, bool $createParticles = false); useItemOn(Vector3 $vector, Item &$item, int $face, float $fx = 0.0, float $fy = 0.0, float $fz = 0.0, Player $player = null); getEntity(int $entityId); getEntities(); getCollidingEntities(AxisAlignedBB $bb, Entity $entity = null); getNearbyEntities(AxisAlignedBB $bb, Entity $entity = null); getNearbyExperienceOrb(AxisAlignedBB $bb); getTiles(); getTileById(int $tileId); getPlayers(); getLoaders(); getTile(Vector3 $pos); getChunkEntities($X, $Z); getChunkTiles($X, $Z); getBlockIdAt(int $x, int $y, int $z); setBlockIdAt(int $x, int $y, int $z, int $id); getBlockExtraDataAt(int $x, int $y, int $z); setBlockExtraDataAt(int $x, int $y, int $z, int $id, int $data); getBlockDataAt(int $x, int $y, int $z); setBlockDataAt(int $x, int $y, int $z, int $data); getBlockSkyLightAt(int $x, int $y, int $z); setBlockSkyLightAt(int $x, int $y, int $z, int $level); getBlockLightAt(int $x, int $y, int $z); setBlockLightAt(int $x, int $y, int $z, int $level); getBiomeId(int $x, int $z); getBiomeColor(int $x, int $z); getHeightMap(int $x, int $z); setBiomeId(int $x, int $z, int $biomeId); setBiomeColor(int $x, int $z, int $R, int $G, int $B); setHeightMap(int $x, int $z, int $value); getChunks(); getChunk(int $x, int $z, bool $create = false); generateChunkCallback(int $x, int $z, FullChunk $chunk); setChunk(int $chunkX, int $chunkZ, FullChunk $chunk = null, bool $unload = true); sendLighting(int $x, int $y, int $z, Player $p); spawnLightning(Vector3 $pos); spawnXPOrb(Vector3 $pos, int $exp = 1); getHighestBlockAt(int $x, int $z); canBlockSeeSky(Vector3 $pos); isChunkLoaded(int $x, int $z); isChunkGenerated(int $x, int $z); isChunkPopulated(int $x, int $z); getSpawnLocation(); setSpawnLocation(Vector3 $pos); requestChunk(int $x, int $z, Player $player); chunkRequestCallback($x, $z, $payload, $ordering = FullChunkDataPacket::ORDER_COLUMNS); removeEntity(Entity $entity); addEntity(Entity $entity); addTile(Tile $tile); removeTile(Tile $tile); isChunkInUse(int $x, int $z); loadChunk(int $x, int $z, bool $generate = true); unloadChunkRequest(int $x, int $z, bool $safe = true); cancelUnloadChunkRequest(int $x, int $z); unloadChunk(int $x, int $z, bool $safe = true, bool $trySave = true); isSpawnChunk(int $X, int $Z); getSafeSpawn($spawn = null); getTime(); getName(); getFolderName(); setTime(int $time); stopTime(); startTime(); getSeed(); setSeed(int $seed); populateChunk(int $x, int $z, bool $force = false); generateChunk(int $x, int $z, bool $force = false); regenerateChunk(int $x, int $z); doChunkGarbageCollection(); unloadChunks(bool $force = false); setMetadata($metadataKey, MetadataValue $metadataValue); getMetadata($metadataKey); hasMetadata($metadataKey); removeMetadata($metadataKey, Plugin $plugin); addEntityMotion(int $chunkX, int $chunkZ, int $entityId, float $x, float $y, float $z); addEntityMovement(int $chunkX, int $chunkZ, int $entityId, float $x, float $y, float $z, float $yaw, float $pitch, $headYaw = null); addPlayerMovement($chunkX, $chunkZ, $entityId, $x, $y, $z, $yaw, $pitch, $onGround, $headYaw = null)
### LevelDB (class) — extends BaseLevelProvider | pocketmine/level/format/leveldb/LevelDB.php
consts: ENTRY_VERSION, ENTRY_FLAGS, ENTRY_EXTRA_DATA, ENTRY_TICKS, ENTRY_ENTITIES, ENTRY_TILES, ENTRY_TERRAIN
public: __construct(Level $level, $path); static getProviderName(); static getProviderOrder(); static usesChunkSection(); static isValid($path); static generate($path, $name, $seed, $generator, array $options = []); saveLevelData(); requestChunkTask($x, $z); unloadChunks(); getGenerator(); getGeneratorOptions(); getLoadedChunks(); isChunkLoaded($x, $z); saveChunks(); loadChunk($chunkX, $chunkZ, $create = false); unloadChunk($x, $z, $safe = true); saveChunk($x, $z); getChunk($chunkX, $chunkZ, $create = false); getDatabase(); setChunk($chunkX, $chunkZ, FullChunk $chunk); static createChunkSection($Y); static chunkIndex($chunkX, $chunkZ); isChunkGenerated($chunkX, $chunkZ); isChunkPopulated($chunkX, $chunkZ); close()
### LevelProvider (interface) — pocketmine/level/format/LevelProvider.php
consts: ORDER_YZX, ORDER_ZXY
public: __construct(Level $level, $path); static getProviderName(); static getProviderOrder(); static usesChunkSection(); requestChunkTask($x, $z); getPath(); static isValid($path); static generate($path, $name, $seed, $generator, array $options = []); getGenerator(); getGeneratorOptions(); getChunk($X, $Z, $create = false); static createChunkSection($Y); saveChunks(); saveChunk($X, $Z); unloadChunks(); loadChunk($X, $Z, $create = false); unloadChunk($X, $Z, $safe = true); isChunkGenerated($X, $Z); isChunkPopulated($X, $Z); isChunkLoaded($X, $Z); setChunk($chunkX, $chunkZ, FullChunk $chunk); getName(); getTime(); setTime($value); getSeed(); setSeed($value); getSpawn(); setSpawn(Vector3 $pos); getLoadedChunks(); doGarbageCollection(); getLevel(); close()
### LevelProviderManager (class) — pocketmine/level/format/LevelProviderManager.php
public: static addProvider(Server $server, $class); static getProvider($path); static getProviderByName($name)
### LightPopulationTask (class) — extends AsyncTask | pocketmine/level/generator/LightPopulationTask.php
public: __construct(Level $level, FullChunk $chunk); onRun(); onCompletion(Server $server)
### LilyPad (class) — extends Populator | pocketmine/level/generator/populator/LilyPad.php
public: setRandomAmount($amount); setBaseAmount($amount); populate(ChunkManager $level, $chunkX, $chunkZ, Random $random)
### Location (class) — extends Position | pocketmine/level/Location.php
public: __construct($x = 0, $y = 0, $z = 0, $yaw = 0.0, $pitch = 0.0, Level $level = null); static fromObject(Vector3 $pos, Level $level = null, $yaw = 0.0, $pitch = 0.0); add($x, $y = 0, $z = 0, $yaw = 0, $pitch = 0); getYaw(); getPitch(); fromObjectAdd(Vector3 $pos, $x, $y, $z); __toString()
### McRegion (class) — extends BaseLevelProvider | pocketmine/level/format/mcregion/McRegion.php
public: static getProviderName(); static getProviderOrder(); static usesChunkSection(); static isValid($path); static generate($path, $name, $seed, $generator, array $options = []); static getRegionIndex($chunkX, $chunkZ, &$x, &$z); requestChunkTask($x, $z); unloadChunks(); getGenerator(); getGeneratorOptions(); getLoadedChunks(); isChunkLoaded($x, $z); saveChunks(); doGarbageCollection(); loadChunk($chunkX, $chunkZ, $create = false); getEmptyChunk($chunkX, $chunkZ); unloadChunk($x, $z, $safe = true); saveChunk($x, $z); getChunk($chunkX, $chunkZ, $create = false); setChunk($chunkX, $chunkZ, FullChunk $chunk); static createChunkSection($Y); isChunkGenerated($chunkX, $chunkZ); isChunkPopulated($chunkX, $chunkZ); close()
protected: getRegion($x, $z); loadRegion($x, $z)
### Mineshaft (class) — extends Populator | pocketmine/level/generator/populator/Mineshaft.php
public: populate(ChunkManager $level, $chunkX, $chunkZ, Random $random)
### MobSpawnParticle (class) — extends Particle | pocketmine/level/particle/MobSpawnParticle.php
public: __construct(Vector3 $pos, $width = 0, $height = 0); encode()
### MobSpellParticle (class) — extends GenericParticle | pocketmine/level/particle/MobSpellParticle.php
public: __construct(Vector3 $pos, $r = 0, $g = 0, $b = 0, $a = 255)
### MossStone (class) — extends Populator | pocketmine/level/generator/populator/MossStone.php
public: setRandomAmount($amount); setBaseAmount($amount); populate(ChunkManager $level, $chunkX, $chunkZ, Random $random)
### MountainsBiome (class) — extends GrassyBiome | pocketmine/level/generator/normal/biome/MountainsBiome.php
public: __construct(); getName()
### MovingObjectPosition (class) — pocketmine/level/MovingObjectPosition.php
public: static fromBlock($x, $y, $z, $side, Vector3 $hitVector); static fromEntity(Entity $entity)
protected: __construct()
### Nether (class) — extends Generator | pocketmine/level/generator/hell/Nether.php
public: __construct(array $options = []); getName(); getWaterHeight(); getSettings(); init(ChunkManager $level, Random $random); generateChunk($chunkX, $chunkZ); populateChunk($chunkX, $chunkZ); getSpawn()
### NetherGlowStone (class) — extends Populator | pocketmine/level/generator/populator/NetherGlowStone.php
public: populate(ChunkManager $level, $chunkX, $chunkZ, Random $random)
### NetherLava (class) — extends Populator | pocketmine/level/generator/populator/NetherLava.php
public: setRandomAmount($amount); setBaseAmount($amount); populate(ChunkManager $level, $chunkX, $chunkZ, Random $random)
### NetherOre (class) — pocketmine/level/generator/object/NetherOre.php
public: __construct(Random $random, OreType $type); getType(); canPlaceObject(ChunkManager $level, $x, $y, $z); placeObject(ChunkManager $level, $x, $y, $z)
### NetherOre (class) — extends Populator | pocketmine/level/generator/populator/NetherOre.php
public: populate(ChunkManager $level, $chunkX, $chunkZ, Random $random); setOreTypes(array $types)
### NetherOreTop (class) — pocketmine/level/generator/object/NetherOreTop.php
public: __construct(Random $random, OreType $type); getType(); canPlaceObject(ChunkManager $level, $x, $y, $z); placeObject(ChunkManager $level, $x, $y, $z)
### Noise (class) — pocketmine/level/generator/noise/Noise.php
public: static floor($x); static fade($x); static lerp($x, $y, $z); static linearLerp($x, $x1, $x2, $q0, $q1); static bilinearLerp($x, $y, $q00, $q01, $q10, $q11, $x1, $x2, $y1, $y2); static trilinearLerp($x, $y, $z, $q000, $q001, $q010, $q011, $q100, $q101, $q110, $q111, $x1, $x2, $y1, $y2, $z1, $z2); static grad($hash, $x, $y, $z); noise2D($x, $z, $normalized = false); noise3D($x, $y, $z, $normalized = false); setOffset($x, $y, $z)
### Normal (class) — extends Generator | pocketmine/level/generator/normal/Normal.php
consts: NAME
public: __construct(array $options = []); getName(); getWaterHeight(); getSettings(); pickBiome($x, $z); init(ChunkManager $level, Random $random); generateChunk($chunkX, $chunkZ); populateChunk($chunkX, $chunkZ); getSpawn()
### Normal2 (class) — extends Normal | pocketmine/level/generator/normal/Normal2.php
consts: NAME
public: pickBiome($x, $z); init(ChunkManager $level, Random $random); generateChunk($chunkX, $chunkZ); populateChunk($chunkX, $chunkZ); getSpawn()
### NormalBiome (class) — extends Biome | pocketmine/level/generator/normal/biome/NormalBiome.php
public: getColor()
### NoteblockSound (class) — extends GenericSound | pocketmine/level/sound/NoteblockSound.php
consts: INSTRUMENT_PIANO, INSTRUMENT_BASS_DRUM, INSTRUMENT_CLICK, INSTRUMENT_TABOUR, INSTRUMENT_BASS
public: __construct(Vector3 $pos, $instrument = self::INSTRUMENT_PIANO, $pitch = 0); encode()
### OakTree (class) — extends Tree | pocketmine/level/generator/object/OakTree.php
public: __construct(); placeObject(ChunkManager $level, $x, $y, $z, Random $random)
### Object (class) — pocketmine/level/generator/object/Object.php
### OceanBiome (class) — extends WateryBiome | pocketmine/level/generator/normal/biome/OceanBiome.php
public: __construct(); getName()
### Ore (class) — pocketmine/level/generator/object/Ore.php
public: __construct(Random $random, OreType $type); getType(); canPlaceObject(ChunkManager $level, $x, $y, $z); placeObject(ChunkManager $level, $x, $y, $z)
### Ore (class) — extends Populator | pocketmine/level/generator/populator/Ore.php
public: populate(ChunkManager $level, $chunkX, $chunkZ, Random $random); setOreTypes(array $types)
### OreType (class) — pocketmine/level/generator/object/OreType.php
public: __construct(Block $material, $clusterCount, $clusterSize, $minHeight, $maxHeight)
### Particle (class) — extends Vector3 | pocketmine/level/particle/Particle.php
consts: TYPE_BUBBLE, TYPE_CRITICAL, TYPE_SMOKE, TYPE_EXPLODE, TYPE_WHITE_SMOKE, TYPE_FLAME, TYPE_LAVA, TYPE_LARGE_SMOKE, TYPE_REDSTONE, TYPE_ITEM_BREAK, TYPE_SNOWBALL_POOF, TYPE_LARGE_EXPLODE, TYPE_HUGE_EXPLODE, TYPE_MOB_FLAME, TYPE_HEART, TYPE_TERRAIN, TYPE_TOWN_AURA, TYPE_PORTAL, TYPE_WATER_SPLASH, TYPE_WATER_WAKE, TYPE_DRIP_WATER, TYPE_DRIP_LAVA, TYPE_DUST, TYPE_MOB_SPELL, TYPE_MOB_SPELL_AMBIENT, TYPE_MOB_SPELL_INSTANTANEOUS, TYPE_INK, TYPE_SLIME, TYPE_RAIN_SPLASH, TYPE_VILLAGER_ANGRY, TYPE_VILLAGER_HAPPY, TYPE_ENCHANTMENT_TABLE
### Perlin (class) — extends Noise | pocketmine/level/generator/noise/Perlin.php
public: __construct(Random $random, $octaves, $persistence, $expansion = 1); getNoise3D($x, $y, $z); getNoise2D($x, $y)
### PlainBiome (class) — extends GrassyBiome | pocketmine/level/generator/normal/biome/PlainBiome.php
public: __construct(); getName()
### Pond (class) — pocketmine/level/generator/object/Pond.php
public: __construct(Random $random, Block $type); canPlaceObject(ChunkManager $level, Vector3 $pos); placeObject(ChunkManager $level, Vector3 $pos)
### Pond (class) — extends Populator | pocketmine/level/generator/populator/Pond.php
public: populate(ChunkManager $level, $chunkX, $chunkZ, Random $random); setWaterOdd($waterOdd); setLavaOdd($lavaOdd); setLavaSurfaceOdd($lavaSurfaceOdd)
### PopSound (class) — extends GenericSound | pocketmine/level/sound/PopSound.php
public: __construct(Vector3 $pos, $pitch = 0)
### PopulationTask (class) — extends AsyncTask | pocketmine/level/generator/PopulationTask.php
public: __construct(Level $level, FullChunk $chunk); onRun(); onCompletion(Server $server)
### Populator (class) — pocketmine/level/generator/populator/Populator.php
### PortalParticle (class) — extends GenericParticle | pocketmine/level/particle/PortalParticle.php
public: __construct(Vector3 $pos)
### Position (class) — extends Vector3 | pocketmine/level/Position.php
public: __construct($x = 0, $y = 0, $z = 0, Level $level = null); static fromObject(Vector3 $pos, Level $level = null); add($x, $y = 0, $z = 0); getLevel(); setLevel(Level $level); isValid(); getSide($side, $step = 1); __toString(); setComponents($x, $y, $z); fromObjectAdd(Vector3 $pos, $x, $y, $z)
### RainSplashParticle (class) — extends GenericParticle | pocketmine/level/particle/RainSplashParticle.php
public: __construct(Vector3 $pos)
### RedstoneParticle (class) — extends GenericParticle | pocketmine/level/particle/RedstoneParticle.php
public: __construct(Vector3 $pos, $lifetime = 1)
### RegionLoader (class) — extends \pocketmine\level\format\mcregion\RegionLoader | pocketmine/level/format/anvil/RegionLoader.php
public: __construct(LevelProvider $level, $regionX, $regionZ)
protected: unserializeChunk($data)
### RegionLoader (class) — pocketmine/level/format/mcregion/RegionLoader.php
consts: VERSION, COMPRESSION_GZIP, COMPRESSION_ZLIB, MAX_SECTOR_LENGTH
public: __construct(LevelProvider $level, $regionX, $regionZ); __destruct(); readChunk($x, $z); chunkExists($x, $z); removeChunk($x, $z); writeChunk(FullChunk $chunk); close(); doSlowCleanUp(); getX(); getZ()
protected: isChunkGenerated($index); unserializeChunk($data); saveChunk($x, $z, $chunkData); static getChunkOffset($x, $z); loadLocationTable(); writeLocationIndex($index); createBlank()
### RiverBiome (class) — extends WateryBiome | pocketmine/level/generator/normal/biome/RiverBiome.php
public: __construct(); getName()
### SandyBiome (class) — extends GrassyBiome | pocketmine/level/generator/normal/biome/SandyBiome.php
public: __construct(); getName()
### SimpleChunkManager (class) — implements ChunkManager | pocketmine/level/SimpleChunkManager.php
public: __construct($seed, $waterHeight = 0); getWaterHeight(); getBlockIdAt(int $x, int $y, int $z); setBlockIdAt(int $x, int $y, int $z, int $id); getBlockDataAt(int $x, int $y, int $z); setBlockDataAt(int $x, int $y, int $z, int $data); getBlockLightAt(int $x, int $y, int $z); setBlockLightAt(int $x, int $y, int $z, int $level); updateBlockLight(int $x, int $y, int $z); getChunk(int $chunkX, int $chunkZ); setChunk(int $chunkX, int $chunkZ, FullChunk $chunk = null); cleanChunks(); getSeed()
### Simplex (class) — extends Perlin | pocketmine/level/generator/noise/Simplex.php
public: __construct(Random $random, $octaves, $persistence, $expansion = 1); getNoise3D($x, $y, $z); getNoise2D($x, $y)
protected: static dot2D($g, $x, $y); static dot3D($g, $x, $y, $z); static dot4D($g, $x, $y, $z, $w)
### SmallMountainsBiome (class) — extends MountainsBiome | pocketmine/level/generator/normal/biome/SmallMountainsBiome.php
public: __construct(); getName()
### SmokeParticle (class) — extends GenericParticle | pocketmine/level/particle/SmokeParticle.php
public: __construct(Vector3 $pos, $scale = 0)
### SnowyBiome (class) — extends NormalBiome | pocketmine/level/generator/normal/biome/SnowyBiome.php
public: __construct()
### Sound (class) — extends Vector3 | pocketmine/level/sound/Sound.php
### SpellParticle (class) — extends GenericParticle | pocketmine/level/particle/SpellParticle.php
public: __construct(Vector3 $pos, $r = 0, $g = 0, $b = 0, $a = 255); encode()
### SpellSound (class) — extends Sound | pocketmine/level/sound/SpellSound.php
public: __construct(Vector3 $pos, $r = 0, $g = 0, $b = 0); encode()
### SplashParticle (class) — extends GenericParticle | pocketmine/level/particle/SplashParticle.php
public: __construct(Vector3 $pos)
### SplashSound (class) — extends GenericSound | pocketmine/level/sound/SplashSound.php
public: __construct(Vector3 $pos, $pitch = 0)
### SporeParticle (class) — extends GenericParticle | pocketmine/level/particle/SporeParticle.php
public: __construct(Vector3 $pos)
### SpruceTree (class) — extends Tree | pocketmine/level/generator/object/SpruceTree.php
public: __construct(); placeObject(ChunkManager $level, $x, $y, $z, Random $random)
### Sugarcane (class) — extends Populator | pocketmine/level/generator/populator/Sugarcane.php
public: setRandomAmount($amount); setBaseAmount($amount); populate(ChunkManager $level, $chunkX, $chunkZ, Random $random)
### SwampBiome (class) — extends GrassyBiome | pocketmine/level/generator/normal/biome/SwampBiome.php
public: __construct(); getName(); getColor()
### TNTPrimeSound (class) — extends GenericSound | pocketmine/level/sound/TNTPrimeSound.php
public: __construct(Vector3 $pos, $pitch = 0)
### TaigaBiome (class) — extends SnowyBiome | pocketmine/level/generator/normal/biome/TaigaBiome.php
public: __construct(); getName()
### TallGrass (class) — pocketmine/level/generator/object/TallGrass.php
public: static growGrass(ChunkManager $level, Vector3 $pos, Random $random, $count = 15, $radius = 10)
### TallGrass (class) — extends Populator | pocketmine/level/generator/populator/TallGrass.php
public: setRandomAmount($amount); setBaseAmount($amount); populate(ChunkManager $level, $chunkX, $chunkZ, Random $random)
### TerrainParticle (class) — extends GenericParticle | pocketmine/level/particle/TerrainParticle.php
public: __construct(Vector3 $pos, Block $b)
### Tree (class) — pocketmine/level/generator/object/Tree.php
public: static growTree(ChunkManager $level, $x, $y, $z, Random $random, $type = 0, bool $noBigTree = true); canPlaceObject(ChunkManager $level, $x, $y, $z, Random $random); placeObject(ChunkManager $level, $x, $y, $z, Random $random)
protected: placeTrunk(ChunkManager $level, $x, $y, $z, Random $random, $trunkHeight)
### Tree (class) — extends Populator | pocketmine/level/generator/populator/Tree.php
public: __construct($type = Sapling::OAK); setRandomAmount($amount); setBaseAmount($amount); populate(ChunkManager $level, $chunkX, $chunkZ, Random $random)
### Void (class) — extends Generator | pocketmine/level/generator/Void.php
public: getSettings(); getName(); __construct(array $settings = []); init(ChunkManager $level, Random $random); generateChunk($chunkX, $chunkZ); populateChunk($chunkX, $chunkZ); getSpawn()
### WaterDripParticle (class) — extends GenericParticle | pocketmine/level/particle/WaterDripParticle.php
public: __construct(Vector3 $pos)
### WaterParticle (class) — extends GenericParticle | pocketmine/level/particle/WaterParticle.php
public: __construct(Vector3 $pos)
### WaterPit (class) — extends Populator | pocketmine/level/generator/populator/WaterPit.php
public: setRandomAmount($amount); setBaseAmount($amount); populate(ChunkManager $level, $chunkX, $chunkZ, Random $random)
### WateryBiome (class) — extends GrassyBiome | pocketmine/level/generator/normal/biome/WateryBiome.php
### WeakPosition (class) — extends Position | pocketmine/level/WeakPosition.php
public: __construct($x = 0, $y = 0, $z = 0, Level $level = null); static fromObject(Vector3 $pos, Level $level = null); getLevel(); setLevel(Level $level); getSide($side, $step = 1); __toString()
### Weather (class) — pocketmine/level/weather/Weather.php
consts: CLEAR, SUNNY, RAIN, RAINY, RAINY_THUNDER, THUNDER
public: __construct(Level $level, $duration = 1200); canCalculate(); setCanCalculate(bool $canCalc); calcWeather($currentTick); setWeather(int $wea, int $duration = 12000); getRandomWeatherData(); setRandomWeatherData(array $randomWeatherData); getWeather(); static getWeatherFromString($weather); isSunny(); isRainy(); isRainyThunder(); isThunder(); getStrength(); sendWeather(Player $p); sendWeatherToAll()
### WeatherManager (class) — pocketmine/level/weather/WeatherManager.php
public: static registerLevel(Level $level); static unregisterLevel(Level $level); static updateWeather(); static isRegistered(Level $level)
### WhiteSmokeParticle (class) — extends GenericParticle | pocketmine/level/particle/WhiteSmokeParticle.php
public: __construct(Vector3 $pos, $scale = 0)
### ZombieHealSound (class) — extends GenericSound | pocketmine/level/sound/ZombieHealSound.php
public: __construct(Vector3 $pos, $pitch = 0)
### ZombieInfectSound (class) — extends GenericSound | pocketmine/level/sound/ZombieInfectSound.php
public: __construct(Vector3 $pos, $pitch = 0)
