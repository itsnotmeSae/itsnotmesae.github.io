# pocketmine_metadata (7 classes)

### BlockMetadataStore (class) — extends MetadataStore | pocketmine/metadata/BlockMetadataStore.php
public: __construct(Level $owningLevel); disambiguate(Metadatable $block, $metadataKey); getMetadata($block, $metadataKey); hasMetadata($block, $metadataKey); removeMetadata($block, $metadataKey, Plugin $owningPlugin); setMetadata($block, $metadataKey, MetadataValue $newMetadatavalue)
### EntityMetadataStore (class) — extends MetadataStore | pocketmine/metadata/EntityMetadataStore.php
public: disambiguate(Metadatable $entity, $metadataKey)
### LevelMetadataStore (class) — extends MetadataStore | pocketmine/metadata/LevelMetadataStore.php
public: disambiguate(Metadatable $level, $metadataKey)
### MetadataStore (class) — pocketmine/metadata/MetadataStore.php
public: setMetadata($subject, $metadataKey, MetadataValue $newMetadataValue); getMetadata($subject, $metadataKey); hasMetadata($subject, $metadataKey); removeMetadata($subject, $metadataKey, Plugin $owningPlugin); invalidateAll(Plugin $owningPlugin)
### MetadataValue (class) — pocketmine/metadata/MetadataValue.php
public: getOwningPlugin()
protected: __construct(Plugin $owningPlugin)
### Metadatable (interface) — pocketmine/metadata/Metadatable.php
public: setMetadata($metadataKey, MetadataValue $newMetadataValue); getMetadata($metadataKey); hasMetadata($metadataKey); removeMetadata($metadataKey, Plugin $owningPlugin)
### PlayerMetadataStore (class) — extends MetadataStore | pocketmine/metadata/PlayerMetadataStore.php
public: disambiguate(Metadatable $player, $metadataKey)
