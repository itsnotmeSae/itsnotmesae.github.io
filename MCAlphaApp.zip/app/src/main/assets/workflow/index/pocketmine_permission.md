# pocketmine_permission (10 classes)

### BanEntry (class) — pocketmine/permission/BanEntry.php
public: __construct($name); getName(); getCreated(); setCreated(\DateTime $date); getSource(); setSource($source); getExpires(); setExpires($date); hasExpired(); getReason(); setReason($reason); getString(); static fromString($str)
### BanList (class) — pocketmine/permission/BanList.php
public: __construct($file); isEnabled(); setEnabled($flag); getEntries(); isBanned($name); add(BanEntry $entry); addBan($target, $reason = null, $expires = null, $source = null); remove($name); removeExpired(); load(); save($flag = true)
### DefaultPermissions (class) — pocketmine/permission/DefaultPermissions.php
consts: ROOT
public: static registerPermission(Permission $perm, Permission $parent = null); static registerCorePermissions()
### Permissible (interface) — extends ServerOperator | pocketmine/permission/Permissible.php
public: isPermissionSet($name); hasPermission($name); addAttachment(Plugin $plugin, $name = null, $value = null); removeAttachment(PermissionAttachment $attachment); recalculatePermissions(); getEffectivePermissions()
### PermissibleBase (class) — implements Permissible | pocketmine/permission/PermissibleBase.php
public: __construct(ServerOperator $opable); __destruct(); isOp(); setOp($value); isPermissionSet($name); hasPermission($name); addAttachment(Plugin $plugin, $name = null, $value = null); removeAttachment(PermissionAttachment $attachment); recalculatePermissions(); clearPermissions(); getEffectivePermissions()
### Permission (class) — pocketmine/permission/Permission.php
consts: DEFAULT_OP, DEFAULT_NOT_OP, DEFAULT_TRUE, DEFAULT_FALSE
public: static getByName($value); __construct($name, $description = null, $defaultValue = null, array $children = []); getName(); getChildren(); getDefault(); setDefault($value); getDescription(); setDescription($value); getPermissibles(); recalculatePermissibles(); addParent($name, $value); static loadPermissions(array $data, $default = self::DEFAULT_OP); static loadPermission($name, array $data, $default = self::DEFAULT_OP, &$output = [])
### PermissionAttachment (class) — pocketmine/permission/PermissionAttachment.php
public: __construct(Plugin $plugin, Permissible $permissible); getPlugin(); setRemovalCallback(PermissionRemovedExecutor $ex); getRemovalCallback(); getPermissible(); getPermissions(); clearPermissions(); setPermissions(array $permissions); unsetPermissions(array $permissions); setPermission($name, $value); unsetPermission($name); remove()
### PermissionAttachmentInfo (class) — pocketmine/permission/PermissionAttachmentInfo.php
public: __construct(Permissible $permissible, $permission, $attachment, $value); getPermissible(); getPermission(); getAttachment(); getValue()
### PermissionRemovedExecutor (interface) — pocketmine/permission/PermissionRemovedExecutor.php
public: attachmentRemoved(PermissionAttachment $attachment)
### ServerOperator (interface) — pocketmine/permission/ServerOperator.php
public: isOp(); setOp($value)
