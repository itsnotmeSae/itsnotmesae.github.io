# pocketmine_plugin (13 classes)

### EventExecutor (interface) — pocketmine/plugin/EventExecutor.php
public: execute(Listener $listener, Event $event)
### FolderPluginLoader (class) — implements PluginLoader | pocketmine/plugin/FolderPluginLoader.php
public: __construct(Server $server); loadPlugin($file); getPluginDescription($file); getPluginFilters(); enablePlugin(Plugin $plugin); disablePlugin(Plugin $plugin)
### MethodEventExecutor (class) — implements EventExecutor | pocketmine/plugin/MethodEventExecutor.php
public: __construct($method); execute(Listener $listener, Event $event); getMethod()
### PharPluginLoader (class) — implements PluginLoader | pocketmine/plugin/PharPluginLoader.php
public: __construct(Server $server); loadPlugin($file); getPluginDescription($file); getPluginFilters(); enablePlugin(Plugin $plugin); disablePlugin(Plugin $plugin)
### Plugin (interface) — extends CommandExecutor | pocketmine/plugin/Plugin.php
public: onLoad(); onEnable(); isEnabled(); onDisable(); isDisabled(); getDataFolder(); getDescription(); getResource($filename); saveResource($filename, $replace = false); getResources(); getConfig(); saveConfig(); saveDefaultConfig(); reloadConfig(); getServer(); getName(); getLogger(); getPluginLoader()
### PluginBase (class) — implements Plugin | pocketmine/plugin/PluginBase.php
public: onLoad(); onEnable(); onDisable(); getLogger(); getCommand($name); onCommand(CommandSender $sender, Command $command, $label, array $args); getResource($filename); saveResource($filename, $replace = false); getResources(); getConfig(); saveConfig(); saveDefaultConfig(); reloadConfig(); getPluginLoader()
protected: isPhar(); getFile()
### PluginDescription (class) — pocketmine/plugin/PluginDescription.php
public: __construct($yamlString); getFullName(); getCompatibleApis(); getCompatibleGeniApis(); getAuthors(); getPrefix(); getCommands(); getDepend(); getDescription(); getLoadBefore(); getMain(); getName(); getOrder(); getPermissions(); getSoftDepend(); getVersion(); getWebsite()
### PluginLoadOrder (class) — pocketmine/plugin/PluginLoadOrder.php
consts: STARTUP, POSTWORLD
### PluginLoader (interface) — pocketmine/plugin/PluginLoader.php
public: loadPlugin($file); getPluginDescription($file); getPluginFilters(); enablePlugin(Plugin $plugin); disablePlugin(Plugin $plugin)
### PluginLogger (class) — implements \AttachableLogger | pocketmine/plugin/PluginLogger.php
public: addAttachment(\LoggerAttachment $attachment); removeAttachment(\LoggerAttachment $attachment); removeAttachments(); getAttachments(); __construct(Plugin $context); emergency($message); alert($message); critical($message); error($message); warning($message); notice($message); info($message); debug($message); logException(\Throwable $e, $trace = null); log($level, $message)
### PluginManager (class) — pocketmine/plugin/PluginManager.php
public: __construct(Server $server, SimpleCommandMap $commandMap); getPlugin($name); registerInterface($loaderName); getPlugins(); loadPlugin($path, $loaders = null); loadPlugins($directory, $newLoaders = null); getPermission($name); addPermission(Permission $permission); removePermission($permission); getDefaultPermissions($op); recalculatePermissionDefaults(Permission $permission); subscribeToPermission($permission, Permissible $permissible); unsubscribeFromPermission($permission, Permissible $permissible); getPermissionSubscriptions($permission); subscribeToDefaultPerms($op, Permissible $permissible); unsubscribeFromDefaultPerms($op, Permissible $permissible); getDefaultPermSubscriptions($op); getPermissions(); isPluginEnabled(Plugin $plugin); enablePlugin(Plugin $plugin); disablePlugins(); disablePlugin(Plugin $plugin); clearPlugins(); callEvent(Event $event); registerEvents(Listener $listener, Plugin $plugin); registerEvent($event, Listener $listener, $priority, EventExecutor $executor, Plugin $plugin, $ignoreCancelled = false); useTimings(); setUseTimings($use)
protected: parseYamlCommands(Plugin $plugin)
### RegisteredListener (class) — pocketmine/plugin/RegisteredListener.php
public: __construct(Listener $listener, EventExecutor $executor, $priority, Plugin $plugin, $ignoreCancelled, TimingsHandler $timings); getListener(); getPlugin(); getPriority(); callEvent(Event $event); __destruct(); isIgnoringCancelled()
### ScriptPluginLoader (class) — implements PluginLoader | pocketmine/plugin/ScriptPluginLoader.php
public: __construct(Server $server); loadPlugin($file); getPluginDescription($file); getPluginFilters(); enablePlugin(Plugin $plugin); disablePlugin(Plugin $plugin)
