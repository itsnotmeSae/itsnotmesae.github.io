# raklib (50 classes)

### ACK (class) — extends AcknowledgePacket | raklib/protocol/ACK.php
### ADVERTISE_SYSTEM (class) — extends UNCONNECTED_PONG | raklib/protocol/ADVERTISE_SYSTEM.php
### AcknowledgePacket (class) — extends Packet | raklib/protocol/AcknowledgePacket.php
public: encode(); decode(); clean()
### Binary (class) — raklib/Binary.php
consts: BIG_ENDIAN, LITTLE_ENDIAN
public: static readTriad($str); static writeTriad($value); static readLTriad($str); static writeLTriad($value); static readBool($b); static writeBool($b); static readByte($c, $signed = true); static writeByte($c); static readShort($str); static readSignedShort($str); static writeShort($value); static readLShort($str, $signed = true); static writeLShort($value); static readInt($str); static writeInt($value); static readLInt($str); static writeLInt($value); static readFloat($str); static writeFloat($value); static readLFloat($str); static writeLFloat($value); static readDouble($str); static writeDouble($value); static readLDouble($str); static writeLDouble($value); static readLong($x); static writeLong($value); static readLLong($str); static writeLLong($value)
### CLIENT_CONNECT_DataPacket (class) — extends Packet | raklib/protocol/CLIENT_CONNECT_DataPacket.php
public: encode(); decode()
### CLIENT_DISCONNECT_DataPacket (class) — extends Packet | raklib/protocol/CLIENT_DISCONNECT_DataPacket.php
public: encode(); decode()
### CLIENT_HANDSHAKE_DataPacket (class) — extends Packet | raklib/protocol/CLIENT_HANDSHAKE_DataPacket.php
public: encode(); decode()
### DATA_PACKET_0 (class) — extends DataPacket | raklib/protocol/DATA_PACKET_0.php
### DATA_PACKET_1 (class) — extends DataPacket | raklib/protocol/DATA_PACKET_1.php
### DATA_PACKET_2 (class) — extends DataPacket | raklib/protocol/DATA_PACKET_2.php
### DATA_PACKET_3 (class) — extends DataPacket | raklib/protocol/DATA_PACKET_3.php
### DATA_PACKET_4 (class) — extends DataPacket | raklib/protocol/DATA_PACKET_4.php
### DATA_PACKET_5 (class) — extends DataPacket | raklib/protocol/DATA_PACKET_5.php
### DATA_PACKET_6 (class) — extends DataPacket | raklib/protocol/DATA_PACKET_6.php
### DATA_PACKET_7 (class) — extends DataPacket | raklib/protocol/DATA_PACKET_7.php
### DATA_PACKET_8 (class) — extends DataPacket | raklib/protocol/DATA_PACKET_8.php
### DATA_PACKET_9 (class) — extends DataPacket | raklib/protocol/DATA_PACKET_9.php
### DATA_PACKET_A (class) — extends DataPacket | raklib/protocol/DATA_PACKET_A.php
### DATA_PACKET_B (class) — extends DataPacket | raklib/protocol/DATA_PACKET_B.php
### DATA_PACKET_C (class) — extends DataPacket | raklib/protocol/DATA_PACKET_C.php
### DATA_PACKET_D (class) — extends DataPacket | raklib/protocol/DATA_PACKET_D.php
### DATA_PACKET_E (class) — extends DataPacket | raklib/protocol/DATA_PACKET_E.php
### DATA_PACKET_F (class) — extends DataPacket | raklib/protocol/DATA_PACKET_F.php
### DataPacket (class) — extends Packet | raklib/protocol/DataPacket.php
public: encode(); length(); decode(); clean()
### EncapsulatedPacket (class) — raklib/protocol/EncapsulatedPacket.php
consts: RELIABILITY_SHIFT, RELIABILITY_FLAGS, SPLIT_FLAG
public: static fromBinary($binary, $internal = false, &$offset = null); getTotalLength(); toBinary($internal = false); isReliable(); isSequenced(); __toString()
### EncapsulatedPacket (class) — raklib/protocol/p70/EncapsulatedPacket.php
public: static fromBinary($binary, $internal = \false, &$offset = \null); getTotalLength(); toBinary($internal = \false); __toString()
### NACK (class) — extends AcknowledgePacket | raklib/protocol/NACK.php
### OPEN_CONNECTION_REPLY_1 (class) — extends Packet | raklib/protocol/OPEN_CONNECTION_REPLY_1.php
public: encode(); decode()
### OPEN_CONNECTION_REPLY_2 (class) — extends Packet | raklib/protocol/OPEN_CONNECTION_REPLY_2.php
public: encode(); decode()
### OPEN_CONNECTION_REQUEST_1 (class) — extends Packet | raklib/protocol/OPEN_CONNECTION_REQUEST_1.php
public: encode(); decode()
### OPEN_CONNECTION_REQUEST_2 (class) — extends Packet | raklib/protocol/OPEN_CONNECTION_REQUEST_2.php
public: encode(); decode()
### OpenConnectionReply1 (class) — extends Packet | raklib/protocol/OpenConnectionReply1.php
public: encode(); decode()
### OpenConnectionReply2 (class) — extends Packet | raklib/protocol/OpenConnectionReply2.php
public: encode(); decode()
### OpenConnectionRequest1 (class) — extends Packet | raklib/protocol/OpenConnectionRequest1.php
public: encode(); decode()
### OpenConnectionRequest2 (class) — extends Packet | raklib/protocol/OpenConnectionRequest2.php
public: encode(); decode()
### PING_DataPacket (class) — extends Packet | raklib/protocol/PING_DataPacket.php
public: encode(); decode()
### PONG_DataPacket (class) — extends Packet | raklib/protocol/PONG_DataPacket.php
public: encode(); decode()
### Packet (class) — raklib/protocol/Packet.php
public: encode(); decode(); clean()
protected: get($len); getLong($signed = true); getInt(); getShort($signed = true); getTriad(); getLTriad(); getByte(); getString(); getAddress(&$addr, &$port, &$version = null); feof(); put($str); putLong($v); putInt($v); putShort($v); putTriad($v); putLTriad($v); putByte($v); putString($v); putAddress($addr, $port, $version = 4)
### PacketReliability (class) — raklib/protocol/PacketReliability.php
consts: UNRELIABLE, UNRELIABLE_SEQUENCED, RELIABLE, RELIABLE_ORDERED, RELIABLE_SEQUENCED, UNRELIABLE_WITH_ACK_RECEIPT, RELIABLE_WITH_ACK_RECEIPT, RELIABLE_ORDERED_WITH_ACK_RECEIPT
### RakLib (class) — raklib/RakLib.php
consts: VERSION, PROTOCOL, MAGIC, PRIORITY_NORMAL, PRIORITY_IMMEDIATE, FLAG_NEED_ACK, PACKET_PING, PACKET_ENCAPSULATED, PACKET_OPEN_SESSION, PACKET_CLOSE_SESSION, PACKET_INVALID_SESSION, PACKET_SEND_QUEUE, PACKET_ACK_NOTIFICATION, PACKET_SET_OPTION, PACKET_RAW, PACKET_BLOCK_ADDRESS, PACKET_UNBLOCK_ADDRESS, PACKET_SHUTDOWN, PACKET_EMERGENCY_SHUTDOWN
public: static bootstrap(\ClassLoader $loader)
### RakLibServer (class) — extends \Thread | raklib/server/RakLibServer.php
public: __construct(\ThreadedLogger $logger, \ClassLoader $loader, $port, $interface = "0.0.0.0"); isShutdown(); shutdown(); getPort(); getInterface(); getLogger(); getExternalQueue(); getInternalQueue(); pushMainToThreadPacket($str); readMainToThreadPacket(); pushThreadToMainPacket($str); readThreadToMainPacket(); shutdownHandler(); errorHandler($errno, $errstr, $errfile, $errline, $context, $trace = null); getTrace($start = 1, $trace = null); cleanPath($path); run()
protected: addDependency(array &$loadPaths, \ReflectionClass $dep)
### SERVER_HANDSHAKE_DataPacket (class) — extends Packet | raklib/protocol/SERVER_HANDSHAKE_DataPacket.php
public: encode(); decode()
### ServerHandler (class) — raklib/server/ServerHandler.php
public: __construct(RakLibServer $server, ServerInstance $instance); sendEncapsulated($identifier, EncapsulatedPacket $packet, $flags = RakLib::PRIORITY_NORMAL); sendRaw($address, $port, $payload); closeSession($identifier, $reason); sendOption($name, $value); blockAddress($address, $timeout); unblockAddress($address); shutdown(); emergencyShutdown(); handlePacket()
protected: invalidSession($identifier)
### ServerInstance (interface) — raklib/server/ServerInstance.php
public: openSession($identifier, $address, $port, $clientID); closeSession($identifier, $reason); handleEncapsulated($identifier, EncapsulatedPacket $packet, $flags); handleRaw($address, $port, $payload); notifyACK($identifier, $identifierACK); handleOption($option, $value)
### Session (class) — raklib/server/Session.php
consts: STATE_UNCONNECTED, STATE_CONNECTING_1, STATE_CONNECTING_2, STATE_CONNECTED, MAX_SPLIT_SIZE, MAX_SPLIT_COUNT
public: __construct(SessionManager $sessionManager, $address, $port); getAddress(); getPort(); getID(); update($time); disconnect($reason = 'unknown'); sendQueue(); addEncapsulatedToQueue(EncapsulatedPacket $packet, $flags = RakLib::PRIORITY_NORMAL); getState(); isTemporal(); handlePacket(Packet $packet); getPing(); close()
### SessionManager (class) — raklib/server/SessionManager.php
consts: RAKLIB_TPS, RAKLIB_TIME_PER_TICK
public: __construct(RakLibServer $server, UDPServerSocket $socket); getPort(); getLogger(); run(); sendPacket(Packet $packet, $dest, $port); streamEncapsulated(Session $session, EncapsulatedPacket $packet, $flags = RakLib::PRIORITY_NORMAL); streamRaw($address, $port, $payload); receiveStream(); blockAddress($address, $timeout = 500, $reason = null); unblockAddress($address); getSession($ip, $port); removeSession(Session $session, $reason = 'unknown'); openSession(Session $session); notifyACK(Session $session, $identifierACK); getName(); getID(); getPacketFromPool($id)
protected: streamPing(Session $session); streamClose($identifier, $reason); streamInvalid($identifier); streamOpen(Session $session); streamACK($identifier, $identifierACK); streamOption($name, $value)
### UDPServerSocket (class) — raklib/server/UDPServerSocket.php
public: __construct(\ThreadedLogger $logger, $port = 19132, $interface = '0.0.0.0'); getSocket(); close(); readPacket(&$buffer, &$source, &$port); writePacket($buffer, $dest, $port); setSendBuffer($size); setRecvBuffer($size)
### UNCONNECTED_PING (class) — extends Packet | raklib/protocol/UNCONNECTED_PING.php
public: encode(); decode()
### UNCONNECTED_PING_OPEN_CONNECTIONS (class) — extends UNCONNECTED_PING | raklib/protocol/UNCONNECTED_PING_OPEN_CONNECTIONS.php
### UNCONNECTED_PONG (class) — extends Packet | raklib/protocol/UNCONNECTED_PONG.php
public: encode(); decode()
