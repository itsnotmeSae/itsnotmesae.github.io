# pocketmine_item (160 classes)

### AcaciaDoor (class) — extends Door | pocketmine/item/AcaciaDoor.php
public: __construct($meta = 0, $count = 1)
### Apple (class) — extends Food | pocketmine/item/Apple.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### Armor (class) — extends Item | pocketmine/item/Armor.php
consts: TIER_LEATHER, TIER_GOLD, TIER_CHAIN, TIER_IRON, TIER_DIAMOND, TYPE_HELMET, TYPE_CHESTPLATE, TYPE_LEGGINGS, TYPE_BOOTS
public: getMaxStackSize(); isArmor(); useOn($object, int $cost = 1); isUnbreakable(); setCustomColor(Color $color); getCustomColor(); clearCustomColor(); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isHelmet(); isChestplate(); isLeggings(); isBoots()
### Arrow (class) — extends Item | pocketmine/item/Arrow.php
public: __construct($meta = 0, $count = 1)
### BakedPotato (class) — extends Food | pocketmine/item/BakedPotato.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### Bed (class) — extends Item | pocketmine/item/Bed.php
public: __construct($meta = 0, $count = 1); getMaxStackSize()
### Beetroot (class) — extends Food | pocketmine/item/Beetroot.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### BeetrootSeeds (class) — extends Item | pocketmine/item/BeetrootSeeds.php
public: __construct($meta = 0, $count = 1)
### BeetrootSoup (class) — extends Food | pocketmine/item/BeetrootSoup.php
public: __construct($meta = 0, $count = 1); getMaxStackSize(); getFoodRestore(); getSaturationRestore(); getResidue()
### BirchDoor (class) — extends Door | pocketmine/item/BirchDoor.php
public: __construct($meta = 0, $count = 1)
### BlazePowder (class) — extends Item | pocketmine/item/BlazePowder.php
public: __construct($meta = 0, $count =1)
### Boat (class) — extends Item | pocketmine/item/Boat.php
public: __construct($meta = 0, $count = 1); canBeActivated(); onActivate(Level $level, Player $player, Block $block, Block $target, $face, $fx, $fy, $fz)
### Bone (class) — extends Item | pocketmine/item/Bone.php
public: __construct($meta = 0, $count = 1)
### Book (class) — extends Item | pocketmine/item/Book.php
public: __construct($meta = 0, $count = 1)
### Bow (class) — extends Tool | pocketmine/item/Bow.php
public: __construct($meta = 0, $count = 1)
### Bowl (class) — extends Item | pocketmine/item/Bowl.php
public: __construct($meta = 0, $count = 1)
### Bread (class) — extends Food | pocketmine/item/Bread.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### BrewingStand (class) — extends Item | pocketmine/item/BrewingStand.php
public: __construct($meta = 0, $count = 1)
### Brick (class) — extends Item | pocketmine/item/Brick.php
public: __construct($meta = 0, $count = 1)
### Bucket (class) — extends Item | pocketmine/item/Bucket.php
public: __construct($meta = 0, $count = 1); getMaxStackSize(); canBeActivated(); onActivate(Level $level, Player $player, Block $block, Block $target, $face, $fx, $fy, $fz)
### Cake (class) — extends Item | pocketmine/item/Cake.php
public: __construct($meta = 0, $count = 1); getMaxStackSize()
### Camera (class) — extends Item | pocketmine/item/Camera.php
public: __construct($meta = 0, $count = 1); getMaxStackSize()
### Carrot (class) — extends Food | pocketmine/item/Carrot.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### Cauldron (class) — extends Item | pocketmine/item/Cauldron.php
public: __construct($meta = 0, $count = 1); getMaxStackSize()
### ChainBoots (class) — extends Armor | pocketmine/item/ChainBoots.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isBoots()
### ChainChestplate (class) — extends Armor | pocketmine/item/ChainChestplate.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isChestplate()
### ChainHelmet (class) — extends Armor | pocketmine/item/ChainHelmet.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isHelmet()
### ChainLeggings (class) — extends Armor | pocketmine/item/ChainLeggings.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isLeggings()
### Clay (class) — extends Item | pocketmine/item/Clay.php
public: __construct($meta = 0, $count = 1)
### Clock (class) — extends Item | pocketmine/item/Clock.php
public: __construct($meta = 0, $count = 1)
### Coal (class) — extends Item | pocketmine/item/Coal.php
consts: NORMAL, CHARCOAL
public: __construct($meta = 0, $count = 1)
### Compass (class) — extends Item | pocketmine/item/Compass.php
public: __construct($meta = 0, $count = 1)
### CookedChicken (class) — extends Food | pocketmine/item/CookedChicken.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### CookedFish (class) — extends Fish | pocketmine/item/CookedFish.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### CookedMutton (class) — extends Food | pocketmine/item/CookedMutton.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### CookedPorkchop (class) — extends Food | pocketmine/item/CookedPorkchop.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### CookedRabbit (class) — extends Food | pocketmine/item/CookedRabbit.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### Cookie (class) — extends Food | pocketmine/item/Cookie.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### DarkOakDoor (class) — extends Door | pocketmine/item/DarkOakDoor.php
public: __construct($meta = 0, $count = 1)
### Diamond (class) — extends Item | pocketmine/item/Diamond.php
public: __construct($meta = 0, $count = 1)
### DiamondAxe (class) — extends Tool | pocketmine/item/DiamondAxe.php
public: __construct($meta = 0, $count = 1); isAxe(); getAttackDamage()
### DiamondBoots (class) — extends Armor | pocketmine/item/DiamondBoots.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isBoots()
### DiamondChestplate (class) — extends Armor | pocketmine/item/DiamondChestplate.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isChestplate()
### DiamondHelmet (class) — extends Armor | pocketmine/item/DiamondHelmet.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isHelmet()
### DiamondHoe (class) — extends Tool | pocketmine/item/DiamondHoe.php
public: __construct($meta = 0, $count = 1); isHoe()
### DiamondLeggings (class) — extends Armor | pocketmine/item/DiamondLeggings.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isLeggings()
### DiamondPickaxe (class) — extends Tool | pocketmine/item/DiamondPickaxe.php
public: __construct($meta = 0, $count = 1); isPickaxe(); getAttackDamage()
### DiamondShovel (class) — extends Tool | pocketmine/item/DiamondShovel.php
public: __construct($meta = 0, $count = 1); isShovel(); getAttackDamage()
### DiamondSword (class) — extends Tool | pocketmine/item/DiamondSword.php
public: __construct($meta = 0, $count = 1); isSword(); getAttackDamage()
### Door (class) — extends Item | pocketmine/item/Door.php
public: getMaxStackSize()
### Dye (class) — extends Item | pocketmine/item/Dye.php
consts: BLACK, RED, GREEN, BROWN, BLUE, PURPLE, CYAN, SILVER, GRAY, PINK, LIME, YELLOW, LIGHT_BLUE, MAGENTA, ORANGE, WHITE
public: __construct($meta = 0, $count = 1); getNameByMeta(int $meta)
### Egg (class) — extends Item | pocketmine/item/Egg.php
public: __construct($meta = 0, $count = 1)
### Emerald (class) — extends Item | pocketmine/item/Emerald.php
public: __construct($meta = 0, $count = 1)
### EnchantedBook (class) — extends Item | pocketmine/item/EnchantedBook.php
public: __construct($meta = 0, $count = 1)
### EnchantedGoldenApple (class) — extends Food | pocketmine/item/EnchantedGoldenApple.php
public: __construct($meta = 0, $count = 1); canBeConsumedBy(Entity $entity); getFoodRestore(); getSaturationRestore(); getAdditionalEffects()
### EnchantingBottle (class) — extends Item | pocketmine/item/EnchantingBottle.php
public: __construct($meta = 0, $count = 1)
### Enchantment (class) — pocketmine/item/enchantment/Enchantment.php
consts: TYPE_INVALID, TYPE_ARMOR_PROTECTION, TYPE_ARMOR_FIRE_PROTECTION, TYPE_ARMOR_FALL_PROTECTION, TYPE_ARMOR_EXPLOSION_PROTECTION, TYPE_ARMOR_PROJECTILE_PROTECTION, TYPE_ARMOR_THORNS, TYPE_WATER_BREATHING, TYPE_WATER_SPEED, TYPE_WATER_AFFINITY, TYPE_WEAPON_SHARPNESS, TYPE_WEAPON_SMITE, TYPE_WEAPON_ARTHROPODS, TYPE_WEAPON_KNOCKBACK, TYPE_WEAPON_FIRE_ASPECT, TYPE_WEAPON_LOOTING, TYPE_MINING_EFFICIENCY, TYPE_MINING_SILK_TOUCH, TYPE_MINING_DURABILITY, TYPE_MINING_FORTUNE, TYPE_BOW_POWER, TYPE_BOW_KNOCKBACK, TYPE_BOW_FLAME, TYPE_BOW_INFINITY, TYPE_FISHING_FORTUNE, TYPE_FISHING_LURE, RARITY_COMMON, RARITY_UNCOMMON, RARITY_RARE, RARITY_MYTHIC, ACTIVATION_EQUIP, ACTIVATION_HELD, ACTIVATION_SELF, SLOT_NONE, SLOT_ALL, SLOT_ARMOR, SLOT_HEAD, SLOT_TORSO, SLOT_LEGS, SLOT_FEET, SLOT_SWORD, SLOT_BOW, SLOT_TOOL, SLOT_HOE, SLOT_SHEARS, SLOT_FLINT_AND_STEEL, SLOT_DIG, SLOT_AXE, SLOT_PICKAXE, SLOT_SHOVEL, SLOT_FISHING_ROD, SLOT_CARROT_STICK
public: static init(); static getEnchantment($id); static getEnchantmentByName($name); static getEnchantAbility(Item $item); static getEnchantWeight(int $enchantmentId); static getEnchantMaxLevel(int $enchantmentId); getId(); getName(); getRarity(); getActivationType(); getSlot(); hasSlot($slot); getLevel(); setLevel(int $level); equals(Enchantment $ent); static getRandomName()
### EnchantmentEntry (class) — pocketmine/item/enchantment/EnchantmentEntry.php
public: __construct(array $enchantments, $cost, $randomName); getEnchantments(); getCost(); getRandomName()
### EnchantmentLevelTable (class) — pocketmine/item/enchantment/EnchantmentLevelTable.php
public: static init(); static getPossibleEnchantments(Item $item, int $modifiedLevel)
### EnchantmentList (class) — pocketmine/item/enchantment/EnchantmentList.php
public: __construct($size); setSlot($slot, EnchantmentEntry $entry); getSlot($slot); getSize()
### Feather (class) — extends Item | pocketmine/item/Feather.php
public: __construct($meta = 0, $count = 1)
### FermentedSpiderEye (class) — extends Item | pocketmine/item/FermentedSpiderEye.php
public: __construct($meta = 0, $count =1)
### Fish (class) — extends Food | pocketmine/item/Fish.php
consts: FISH_FISH, FISH_SALMON, FISH_CLOWNFISH, FISH_PUFFERFISH
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore(); getAdditionalEffects()
### FishingRod (class) — extends Item | pocketmine/item/FishingRod.php
public: __construct($meta = 0, $count = 1)
### Flint (class) — extends Item | pocketmine/item/Flint.php
public: __construct($meta = 0, $count = 1)
### FlintSteel (class) — extends Tool | pocketmine/item/FlintSteel.php
public: __construct($meta = 0, $count = 1); canBeActivated(); onActivate(Level $level, Player $player, Block $block, Block $target, $face, $fx, $fy, $fz)
### FlowerPot (class) — extends Item | pocketmine/item/FlowerPot.php
public: __construct($meta = 0, $count = 1); getMaxStackSize()
### Food (class) — extends Item | implements FoodSource | pocketmine/item/Food.php
public: canBeConsumed(); canBeConsumedBy(Entity $entity); getResidue(); getAdditionalEffects(); onConsume(Entity $human)
### FoodSource (interface) — pocketmine/item/FoodSource.php
public: getResidue(); getFoodRestore(); getSaturationRestore(); getAdditionalEffects()
### GlassBottle (class) — extends Item | pocketmine/item/GlassBottle.php
public: __construct($meta = 0, $count = 1); canBeActivated(); onActivate(Level $level, Player $player, Block $block, Block $target, $face, $fx, $fy, $fz)
### GlisteringMelon (class) — extends Item | pocketmine/item/GlisteringMelon.php
public: __construct($meta = 0, $count =1)
### GlowstoneDust (class) — extends Item | pocketmine/item/GlowstoneDust.php
public: __construct($meta = 0, $count = 1)
### GoldAxe (class) — extends Tool | pocketmine/item/GoldAxe.php
public: __construct($meta = 0, $count = 1); isAxe(); getAttackDamage()
### GoldBoots (class) — extends Armor | pocketmine/item/GoldBoots.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isBoots()
### GoldChestplate (class) — extends Armor | pocketmine/item/GoldChestplate.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isChestplate()
### GoldHelmet (class) — extends Armor | pocketmine/item/GoldHelmet.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isHelmet()
### GoldHoe (class) — extends Tool | pocketmine/item/GoldHoe.php
public: __construct($meta = 0, $count = 1); isHoe()
### GoldIngot (class) — extends Item | pocketmine/item/GoldIngot.php
public: __construct($meta = 0, $count = 1)
### GoldLeggings (class) — extends Armor | pocketmine/item/GoldLeggings.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isLeggings()
### GoldNugget (class) — extends Item | pocketmine/item/GoldNugget.php
public: __construct($meta = 0, $count = 1)
### GoldPickaxe (class) — extends Tool | pocketmine/item/GoldPickaxe.php
public: __construct($meta = 0, $count = 1); isPickaxe(); getAttackDamage()
### GoldShovel (class) — extends Tool | pocketmine/item/GoldShovel.php
public: __construct($meta = 0, $count = 1); isShovel(); getAttackDamage()
### GoldSword (class) — extends Tool | pocketmine/item/GoldSword.php
public: __construct($meta = 0, $count = 1); isSword(); getAttackDamage()
### GoldenApple (class) — extends Food | pocketmine/item/GoldenApple.php
public: __construct($meta = 0, $count = 1); canBeConsumedBy(Entity $entity); getFoodRestore(); getSaturationRestore(); getAdditionalEffects()
### GoldenCarrot (class) — extends Food | pocketmine/item/GoldenCarrot.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### Gunpowder (class) — extends Item | pocketmine/item/Gunpowder.php
public: __construct($meta = 0, $count = 1)
### Hopper (class) — extends Item | pocketmine/item/Hopper.php
public: __construct($meta = 0, $count = 1)
### IronAxe (class) — extends Tool | pocketmine/item/IronAxe.php
public: __construct($meta = 0, $count = 1); isAxe(); getAttackDamage()
### IronBoots (class) — extends Armor | pocketmine/item/IronBoots.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isBoots()
### IronChestplate (class) — extends Armor | pocketmine/item/IronChestplate.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isChestplate()
### IronDoor (class) — extends Door | pocketmine/item/IronDoor.php
public: __construct($meta = 0, $count = 1)
### IronHelmet (class) — extends Armor | pocketmine/item/IronHelmet.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isHelmet()
### IronHoe (class) — extends Tool | pocketmine/item/IronHoe.php
public: __construct($meta = 0, $count = 1); isHoe()
### IronIngot (class) — extends Item | pocketmine/item/IronIngot.php
public: __construct($meta = 0, $count = 1)
### IronLeggings (class) — extends Armor | pocketmine/item/IronLeggings.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isLeggings()
### IronPickaxe (class) — extends Tool | pocketmine/item/IronPickaxe.php
public: __construct($meta = 0, $count = 1); isPickaxe(); getAttackDamage()
### IronShovel (class) — extends Tool | pocketmine/item/IronShovel.php
public: __construct($meta = 0, $count = 1); isShovel(); getAttackDamage()
### IronSword (class) — extends Tool | pocketmine/item/IronSword.php
public: __construct($meta = 0, $count = 1); isSword(); getAttackDamage()
### Item (class) — implements ItemIds | pocketmine/item/Item.php
public: canBeActivated(); static init($readFromJson = false); static clearCreativeItems(); static getCreativeItems(); static getp70CreativeItems(); static addCreativeItem(Item $item); static addp70CreativeItem(Item $item); static removeCreativeItem(Item $item); static isCreativeItem(Item $item); static getCreativeItem(int $index); static getCreativeItemIndex(Item $item); static get($id, $meta = 0, int $count = 1, $tags = ""); static fromString(string $str, bool $multiple = false); __construct($id, $meta = 0, int $count = 1, string $name = "Unknown"); setCompoundTag($tags); getCompoundTag(); hasCompoundTag(); hasCustomBlockData(); clearCustomBlockData(); setCustomBlockData(CompoundTag $compound); getCustomBlockData(); hasEnchantments(); getEnchantment(int $id); hasEnchantment(int $id, int $level = 1, bool $compareLevel = false); getEnchantmentLevel(int $id); addEnchantment(Enchantment $ench); getEnchantments(); hasRepairCost(); getRepairCost(); setRepairCost(int $cost); clearRepairCost(); hasCustomName(); getCustomName(); setCustomName(string $name); clearCustomName(); getNamedTagEntry($name); getNamedTag(); setNamedTag(CompoundTag $tag); clearNamedTag(); getCount(); setCount(int $count); canBeConsumed(); canBeConsumedBy(Entity $entity); onConsume(Entity $entity); getBlock(); setDamage($meta); getMaxStackSize(); useOn($object); isTool(); getMaxDurability(); isPickaxe(); isAxe(); isSword(); isShovel(); isHoe(); isShears(); isArmor(); getArmorValue(); isBoots(); isHelmet(); isLeggings(); isChestplate(); getAttackDamage(); getModifyAttackDamage(Entity $target); getDestroySpeed(Block $block, Player $player); onActivate(Level $level, Player $player, Block $block, Block $target, $face, $fx, $fy, $fz)
### ItemBlock (class) — extends Item | pocketmine/item/ItemBlock.php
public: __construct(Block $block, $meta = 0, int $count = 1); setDamage($meta); __clone(); getBlock()
### ItemFrame (class) — extends Item | pocketmine/item/ItemFrame.php
public: __construct($meta = 0, $count = 1)
### ItemIds (interface) — extends BlockIds | pocketmine/item/ItemIds.php
consts: IRON_SHOVEL, IRON_PICKAXE, IRON_AXE, FLINT_AND_STEEL, APPLE, BOW, ARROW, COAL, DIAMOND, IRON_INGOT, GOLD_INGOT, IRON_SWORD, WOODEN_SWORD, WOODEN_SHOVEL, WOODEN_PICKAXE, WOODEN_AXE, STONE_SWORD, STONE_SHOVEL, STONE_PICKAXE, STONE_AXE, DIAMOND_SWORD, DIAMOND_SHOVEL, DIAMOND_PICKAXE, DIAMOND_AXE, STICK, BOWL, MUSHROOM_STEW, GOLD_SWORD, GOLD_SHOVEL, GOLD_PICKAXE, GOLD_AXE, STRING, FEATHER, GUNPOWDER, WOODEN_HOE, STONE_HOE, IRON_HOE, DIAMOND_HOE, GOLD_HOE, SEEDS, WHEAT, BREAD, LEATHER_CAP, LEATHER_TUNIC, LEATHER_PANTS, LEATHER_BOOTS, CHAIN_HELMET, CHAIN_CHESTPLATE, CHAIN_LEGGINGS, CHAIN_BOOTS, IRON_HELMET, IRON_CHESTPLATE, IRON_LEGGINGS, IRON_BOOTS, DIAMOND_HELMET, DIAMOND_CHESTPLATE, DIAMOND_LEGGINGS, DIAMOND_BOOTS, GOLD_HELMET, GOLD_CHESTPLATE
### ItemString (class) — extends Item | pocketmine/item/ItemString.php
public: __construct($meta = 0, $count = 1)
### JungleDoor (class) — extends Door | pocketmine/item/JungleDoor.php
public: __construct($meta = 0, $count = 1)
### Leather (class) — extends Item | pocketmine/item/Leather.php
public: __construct($meta = 0, $count = 1)
### LeatherBoots (class) — extends Armor | pocketmine/item/LeatherBoots.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isBoots()
### LeatherCap (class) — extends Armor | pocketmine/item/LeatherCap.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isHelmet()
### LeatherPants (class) — extends Armor | pocketmine/item/LeatherPants.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isLeggings()
### LeatherTunic (class) — extends Armor | pocketmine/item/LeatherTunic.php
public: __construct($meta = 0, $count = 1); getArmorTier(); getArmorType(); getMaxDurability(); getArmorValue(); isChestplate()
### MagmaCream (class) — extends Item | pocketmine/item/MagmaCream.php
public: __construct($meta = 0, $count =1)
### Melon (class) — extends Food | pocketmine/item/Melon.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### MelonSeeds (class) — extends Item | pocketmine/item/MelonSeeds.php
public: __construct($meta = 0, $count = 1)
### Minecart (class) — extends Item | pocketmine/item/Minecart.php
public: __construct($meta = 0, $count = 1); canBeActivated(); onActivate(Level $level, Player $player, Block $block, Block $target, $face, $fx, $fy, $fz)
### MushroomStew (class) — extends Food | pocketmine/item/MushroomStew.php
public: __construct($meta = 0, $count = 1); getMaxStackSize(); getFoodRestore(); getSaturationRestore(); getResidue()
### NetherBrick (class) — extends Item | pocketmine/item/NetherBrick.php
public: __construct($meta = 0, $count = 1)
### NetherQuartz (class) — extends Item | pocketmine/item/NetherQuartz.php
public: __construct($meta = 0, $count = 1)
### NetherWart (class) — extends Item | pocketmine/item/NetherWart.php
public: __construct($meta = 0, $count =1)
### Painting (class) — extends Item | pocketmine/item/Painting.php
public: __construct($meta = 0, $count = 1); canBeActivated(); onActivate(Level $level, Player $player, Block $block, Block $target, $face, $fx, $fy, $fz)
### Paper (class) — extends Item | pocketmine/item/Paper.php
public: __construct($meta = 0, $count = 1)
### Potato (class) — extends Food | pocketmine/item/Potato.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### Potion (class) — extends Item | pocketmine/item/Potion.php
consts: WATER_BOTTLE, MUNDANE, MUNDANE_EXTENDED, THICK, AWKWARD, NIGHT_VISION, NIGHT_VISION_T, INVISIBILITY, INVISIBILITY_T, LEAPING, LEAPING_T, LEAPING_TWO, FIRE_RESISTANCE, FIRE_RESISTANCE_T, SWIFTNESS, SWIFTNESS_T, SWIFTNESS_TWO, SLOWNESS, SLOWNESS_T, WATER_BREATHING, WATER_BREATHING_T, HEALING, HEALING_TWO, HARMING, HARMING_TWO, POISON, POISON_T, POISON_TWO, REGENERATION, REGENERATION_T, REGENERATION_TWO, STRENGTH, STRENGTH_T, STRENGTH_TWO, WEAKNESS, WEAKNESS_T
public: __construct($meta = 0, $count = 1); static getColor(int $meta); getMaxStackSize(); canBeConsumed(); canBeConsumedBy(Entity $entity); getEffects(); static getEffectsById(int $id); onConsume(Entity $human); static getEffectId(int $meta); static getNameByMeta(int $meta)
### PumpkinPie (class) — extends Food | pocketmine/item/PumpkinPie.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### PumpkinSeeds (class) — extends Item | pocketmine/item/PumpkinSeeds.php
public: __construct($meta = 0, $count = 1)
### Quartz (class) — extends Item | pocketmine/item/Quartz.php
public: __construct($meta = 0, $count = 1)
### RabbitStew (class) — extends Food | pocketmine/item/RabbitStew.php
public: __construct($meta = 0, $count = 1); getMaxStackSize(); getFoodRestore(); getSaturationRestore(); getResidue()
### RawBeef (class) — extends Food | pocketmine/item/RawBeef.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### RawChicken (class) — extends Food | pocketmine/item/RawChicken.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore(); getAdditionalEffects()
### RawMutton (class) — extends Food | pocketmine/item/RawMutton.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### RawPorkchop (class) — extends Food | pocketmine/item/RawPorkchop.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### RawRabbit (class) — extends Food | pocketmine/item/RawRabbit.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### Redstone (class) — extends Item | pocketmine/item/Redstone.php
public: __construct($meta = 0, $count = 1)
### Repeater (class) — extends Item | pocketmine/item/Repeater.php
public: __construct($meta = 0, $count = 1)
### RottenFlesh (class) — extends Food | pocketmine/item/RottenFlesh.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore(); getAdditionalEffects()
### Shears (class) — extends Tool | pocketmine/item/Shears.php
public: __construct($meta = 0, $count = 1)
### Sign (class) — extends Item | pocketmine/item/Sign.php
public: __construct($meta = 0, $count = 1); getMaxStackSize()
### Skull (class) — extends Item | pocketmine/item/Skull.php
consts: SKELETON, WITHER_SKELETON, ZOMBIE, STEVE, CREEPER
public: __construct($meta = 0, $count = 1); getMaxStackSize()
### Slimeball (class) — extends Item | pocketmine/item/Slimeball.php
public: __construct($meta = 0, $count = 1)
### Snowball (class) — extends Item | pocketmine/item/Snowball.php
public: __construct($meta = 0, $count = 1); getMaxStackSize()
### SpawnEgg (class) — extends Item | pocketmine/item/SpawnEgg.php
public: __construct($meta = 0, $count = 1); canBeActivated(); onActivate(Level $level, Player $player, Block $block, Block $target, $face, $fx, $fy, $fz)
### SpiderEye (class) — extends Food | pocketmine/item/SpiderEye.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore(); getAdditionalEffects()
### SplashPotion (class) — extends Item | pocketmine/item/SplashPotion.php
public: __construct($meta = 0, $count = 1); getMaxStackSize(); getNameByMeta(int $meta)
### SpruceDoor (class) — extends Door | pocketmine/item/SpruceDoor.php
public: __construct($meta = 0, $count = 1)
### Steak (class) — extends Food | pocketmine/item/Steak.php
public: __construct($meta = 0, $count = 1); getFoodRestore(); getSaturationRestore()
### Stick (class) — extends Item | pocketmine/item/Stick.php
public: __construct($meta = 0, $count = 1)
### StoneAxe (class) — extends Tool | pocketmine/item/StoneAxe.php
public: __construct($meta = 0, $count = 1); isAxe(); getAttackDamage()
### StoneHoe (class) — extends Tool | pocketmine/item/StoneHoe.php
public: __construct($meta = 0, $count = 1); isHoe()
### StonePickaxe (class) — extends Tool | pocketmine/item/StonePickaxe.php
public: __construct($meta = 0, $count = 1); isPickaxe(); getAttackDamage()
### StoneShovel (class) — extends Tool | pocketmine/item/StoneShovel.php
public: __construct($meta = 0, $count = 1); isShovel(); getAttackDamage()
### StoneSword (class) — extends Tool | pocketmine/item/StoneSword.php
public: __construct($meta = 0, $count = 1); isSword(); getAttackDamage()
### Sugar (class) — extends Item | pocketmine/item/Sugar.php
public: __construct($meta = 0, $count = 1)
### Sugarcane (class) — extends Item | pocketmine/item/Sugarcane.php
public: __construct($meta = 0, $count = 1)
### Tool (class) — extends Item | pocketmine/item/Tool.php
consts: TIER_WOODEN, TIER_GOLD, TIER_STONE, TIER_IRON, TIER_DIAMOND, TYPE_NONE, TYPE_SWORD, TYPE_SHOVEL, TYPE_PICKAXE, TYPE_AXE, TYPE_SHEARS
public: __construct($id, $meta = 0, $count = 1, $name = "Unknown"); getMaxStackSize(); useOn($object, $type = 1); getMaxDurability(); isUnbreakable(); isPickaxe(); isAxe(); isSword(); isShovel(); isHoe(); isShears(); isTool()
### Wheat (class) — extends Item | pocketmine/item/Wheat.php
public: __construct($meta = 0, $count = 1)
### WheatSeeds (class) — extends Item | pocketmine/item/WheatSeeds.php
public: __construct($meta = 0, $count = 1)
### WoodenAxe (class) — extends Tool | pocketmine/item/WoodenAxe.php
public: __construct($meta = 0, $count = 1); isAxe(); getAttackDamage()
### WoodenDoor (class) — extends Door | pocketmine/item/WoodenDoor.php
public: __construct($meta = 0, $count = 1)
### WoodenHoe (class) — extends Tool | pocketmine/item/WoodenHoe.php
public: __construct($meta = 0, $count = 1); isHoe()
### WoodenPickaxe (class) — extends Tool | pocketmine/item/WoodenPickaxe.php
public: __construct($meta = 0, $count = 1); isPickaxe(); getAttackDamage()
### WoodenShovel (class) — extends Tool | pocketmine/item/WoodenShovel.php
public: __construct($meta = 0, $count = 1); isShovel(); getAttackDamage()
### WoodenSword (class) — extends Tool | pocketmine/item/WoodenSword.php
public: __construct($meta = 0, $count = 1); isSword(); getAttackDamage()
