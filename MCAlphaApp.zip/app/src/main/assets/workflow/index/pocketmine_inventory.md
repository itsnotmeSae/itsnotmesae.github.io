# pocketmine_inventory (37 classes)

### AnvilInventory (class) — extends TemporaryInventory | pocketmine/inventory/AnvilInventory.php
consts: TARGET, SACRIFICE, RESULT
public: __construct(Position $pos); getHolder(); getResultSlotIndex(); onRename(Player $player, Item $resultItem); processSlotChange(Transaction $transaction); onSlotChange($index, $before, $send); onClose(Player $who)
### BaseInventory (class) — implements Inventory | pocketmine/inventory/BaseInventory.php
public: __construct(InventoryHolder $holder, InventoryType $type, array $items = [], $overrideSize = null, $overrideTitle = null); __destruct(); getSize(); getHotbarSize(); setSize($size); getMaxStackSize(); getName(); getTitle(); getItem($index); getContents(); setContents(array $items, $send = true); setItem($index, Item $item, $send = true); contains(Item $item); slotContains($slot, Item $item, $matchCount = false); all(Item $item); remove(Item $item, $send = true); first(Item $item); firstEmpty(); firstOccupied(); canAddItem(Item $item); addItem(...$slots); removeItem(...$slots); clear($index, $send = true); clearAll($send = true); getViewers(); getHolder(); setMaxStackSize($size); open(Player $who); close(Player $who); onOpen(Player $who); onClose(Player $who); onSlotChange($index, $before, $send); processSlotChange(Transaction $transaction); sendContents($target); sendSlot($index, $target); getType()
### BaseTransaction (class) — implements Transaction | pocketmine/inventory/BaseTransaction.php
public: __construct($inventory, $slot, Item $targetItem, $achievements = [], $transactionType = Transaction::TYPE_NORMAL); getCreationTime(); getInventory(); getSlot(); getTargetItem(); setTargetItem(Item $item); getFailures(); addFailure(); succeeded(); setSuccess($value = true); getTransactionType(); getAchievements(); hasAchievements(); addAchievement(string $achievementName); sendSlotUpdate(Player $source); getChange(); execute(Player $source)
### BigShapedRecipe (class) — extends ShapedRecipe | pocketmine/inventory/BigShapedRecipe.php
### BigShapelessRecipe (class) — extends ShapelessRecipe | pocketmine/inventory/BigShapelessRecipe.php
### BrewingInventory (class) — extends ContainerInventory | pocketmine/inventory/BrewingInventory.php
public: __construct(BrewingStand $tile); getHolder(); setIngredient(Item $item); getIngredient(); onSlotChange($index, $before, $send)
### BrewingRecipe (class) — implements Recipe | pocketmine/inventory/BrewingRecipe.php
public: __construct(Item $result, Item $ingredient, Item $potion); getPotion(); getId(); setId(UUID $id); setInput(Item $item); getInput(); getResult(); registerToCraftingManager()
### ChestInventory (class) — extends ContainerInventory | pocketmine/inventory/ChestInventory.php
public: __construct(Chest $tile); getHolder(); getContents($withAir = false); onOpen(Player $who); onClose(Player $who)
### ContainerInventory (class) — extends BaseInventory | pocketmine/inventory/ContainerInventory.php
public: onOpen(Player $who); onClose(Player $who)
### CraftingInventory (class) — extends BaseInventory | pocketmine/inventory/CraftingInventory.php
public: __construct(InventoryHolder $holder, Inventory $resultInventory, InventoryType $inventoryType); getResultInventory(); getSize()
### CraftingManager (class) — pocketmine/inventory/CraftingManager.php
public: __construct(bool $useJson = false); sort(Item $i1, Item $i2); getRecipe(/*UUID*/ $id); getRecipes(); getRecipesByResult(Item $item); getFurnaceRecipes(); matchFurnaceRecipe(Item $input); matchBrewingRecipe(Item $input, Item $potion); registerShapedRecipe(ShapedRecipe $recipe); registerShapelessRecipe(ShapelessRecipe $recipe); registerFurnaceRecipe(FurnaceRecipe $recipe); registerBrewingRecipe(BrewingRecipe $recipe); matchRecipe(ShapelessRecipe $recipe); registerRecipe(Recipe $recipe)
protected: registerBrewingStand(); registerFurnace(); registerFood(); registerArmor(); registerWeapons(); registerTools(); registerDyes(); registerIngots(); registerPotions()
### CraftingManager (class) — pocketmine/inventory/p70/CraftingManager.php
public: __construct(); registerPlank(); registerShapelessRecipeMap(); registerShapedRecipeMap(); registerBigShapedRecipeMap(); sort(Item $i1, Item $i2); getRecipe(UUID $id); getRecipes(); getFurnaceRecipes(); getBrewingRecipes(); matchFurnaceRecipe(Item $input); matchBrewingRecipe(Item $input); registerShapedRecipe(ShapedRecipe $recipe); registerShapelessRecipe(ShapelessRecipe $recipe); registerFurnaceRecipe(FurnaceRecipe $recipe); registerBrewingRecipe(BrewingRecipe $recipe); matchRecipe(ShapelessRecipe $recipe); registerRecipe(Recipe $recipe)
protected: registerFurnace(); registerBrewingStand(); registerFood(); registerArmor(); registerWeapons(); registerTools(); registerDyes(); registerIngots()
### CreativeItems (class) — pocketmine/inventory/CreativeItems.php
consts: CATEGORY_BUILDING, CATEGORY_DECORATION, CATEGORY_TOOLS, CATEGORY_MISCELLANEOUS
### CustomInventory (class) — extends ContainerInventory | pocketmine/inventory/CustomInventory.php
### DispenserInventory (class) — extends ContainerInventory | pocketmine/inventory/DispenserInventory.php
public: __construct(Dispenser $tile); getHolder()
### DoubleChestInventory (class) — extends ChestInventory | implements InventoryHolder | pocketmine/inventory/DoubleChestInventory.php
public: __construct(Chest $left, Chest $right); getInventory(); getHolder(); getItem($index); setItem($index, Item $item); clear($index); getContents(); setContents(array $items); onOpen(Player $who); onClose(Player $who); getLeftSide(); getRightSide()
### DropItemTransaction (class) — extends BaseTransaction | pocketmine/inventory/DropItemTransaction.php
consts: TRANSACTION_TYPE
public: __construct(Item $droppedItem); setSourceItem(Item $item); getInventory(); getSlot(); sendSlotUpdate(Player $source); getChange(); execute(Player $source)
### DropperInventory (class) — extends ContainerInventory | pocketmine/inventory/DropperInventory.php
public: __construct(Dropper $tile); getHolder()
### EnchantInventory (class) — extends TemporaryInventory | pocketmine/inventory/EnchantInventory.php
public: __construct(Position $pos); getHolder(); getResultSlotIndex(); onOpen(Player $who); onSlotChange($index, $before, $send); onClose(Player $who); checkEnts(array $ent1, array $ent2); onEnchant(Player $who, Item $before, Item $after); countBookshelf(); sendEnchantmentList(); removeConflictEnchantment(Enchantment $enchantment, array $enchantments)
### FakeBlockMenu (class) — extends Position | implements InventoryHolder | pocketmine/inventory/FakeBlockMenu.php
public: __construct(Inventory $inventory, Position $pos); getInventory()
### FloatingInventory (class) — extends BaseInventory | pocketmine/inventory/FloatingInventory.php
public: __construct(InventoryHolder $holder)
### Fuel (class) — pocketmine/inventory/Fuel.php
### FurnaceInventory (class) — extends ContainerInventory | pocketmine/inventory/FurnaceInventory.php
consts: SMELTING, FUEL, RESULT
public: __construct(Furnace $tile); getHolder(); getResult(); getFuel(); getSmelting(); setResult(Item $item); setFuel(Item $item); setSmelting(Item $item); onSlotChange($index, $before, $send)
### FurnaceRecipe (class) — implements Recipe | pocketmine/inventory/FurnaceRecipe.php
public: __construct(Item $result, Item $ingredient); getId(); setId(UUID $id); setInput(Item $item); getInput(); getResult(); registerToCraftingManager()
### HopperInventory (class) — extends ContainerInventory | pocketmine/inventory/HopperInventory.php
public: __construct(Hopper $tile); getHolder()
### Inventory (interface) — pocketmine/inventory/Inventory.php
consts: MAX_STACK
public: getSize(); getMaxStackSize(); setMaxStackSize($size); getName(); getTitle(); getItem($index); setItem($index, Item $item); addItem(...$slots); canAddItem(Item $item); removeItem(...$slots); getContents(); setContents(array $items); sendContents($target); sendSlot($index, $target); contains(Item $item); all(Item $item); first(Item $item); firstEmpty(); remove(Item $item); clear($index); clearAll(); getViewers(); getType(); getHolder(); onOpen(Player $who); open(Player $who); close(Player $who); onClose(Player $who); onSlotChange($index, $before, $send)
### InventoryHolder (interface) — pocketmine/inventory/InventoryHolder.php
public: getInventory()
### InventoryType (class) — pocketmine/inventory/InventoryType.php
consts: CHEST, DOUBLE_CHEST, PLAYER, FURNACE, CRAFTING, WORKBENCH, BREWING_STAND, ANVIL, ENCHANT_TABLE, DISPENSER, DROPPER, HOPPER, PLAYER_FLOATING
public: static get($index); static init(); getDefaultSize(); getDefaultTitle(); getNetworkType()
### PlayerInventory (class) — extends BaseInventory | pocketmine/inventory/PlayerInventory.php
public: __construct(Human $player, $contents = null); getSize(); setSize($size); getHotbarSlotIndex($index); setHotbarSlotIndex($index, $slot); getHeldItemIndex(); setHeldItemIndex($hotbarSlotIndex, $sendToHolder = true, $slotMapping = null); getItemInHand(); setItemInHand(Item $item); getHotbar(); getHeldItemSlot(); setHeldItemSlot($slot); sendHeldItem($target); onSlotChange($index, $before, $send); getHotbarSize(); getArmorItem($index); setArmorItem($index, Item $item); getHelmet(); getChestplate(); getLeggings(); getBoots(); setHelmet(Item $helmet); setChestplate(Item $chestplate); setLeggings(Item $leggings); setBoots(Item $boots); setItem($index, Item $item, $send = true); clear($index, $send = true); getArmorContents(); clearAll(); sendArmorContents($target); setArmorContents(array $items); sendArmorSlot($index, $target); sendContents($target); sendSlot($index, $target); getHolder()
### Recipe (interface) — pocketmine/inventory/Recipe.php
public: getResult(); registerToCraftingManager(); getId()
### ShapedRecipe (class) — implements Recipe | pocketmine/inventory/ShapedRecipe.php
public: __construct(Item $result, ...$shape); getWidth(); getHeight(); getResult(); getId(); setId(UUID $id); setIngredient($key, Item $item); getIngredientMap(); getIngredientList(); getIngredient($x, $y); getShape(); registerToCraftingManager()
protected: fixRecipe($key, $item)
### ShapedRecipeFromJson (class) — extends ShapedRecipe | pocketmine/inventory/ShapedRecipeFromJson.php
public: __construct(Item $result, $height, $width); getWidth(); getHeight(); getResult(); getId(); setId(UUID $id); addIngredient($x, $y, Item $item); setIngredient($key, Item $item); getIngredientMap(); getIngredient($x, $y); getShape(); registerToCraftingManager()
protected: fixRecipe($key, $item)
### ShapelessRecipe (class) — implements Recipe | pocketmine/inventory/ShapelessRecipe.php
public: __construct(Item $result); getId(); setId(UUID $id); getResult(); addIngredient(Item $item); removeIngredient(Item $item); getIngredientList(); getIngredientCount(); registerToCraftingManager()
### SimpleTransactionQueue (class) — implements TransactionQueue | pocketmine/inventory/SimpleTransactionQueue.php
public: __construct(Player $player = null); getPlayer(); getInventories(); getTransactions(); getTransactionCount(); addTransaction(Transaction $transaction); execute()
### TemporaryInventory (class) — extends ContainerInventory | pocketmine/inventory/TemporaryInventory.php
public: onClose(Player $who)
### Transaction (interface) — pocketmine/inventory/Transaction.php
consts: TYPE_NORMAL, TYPE_DROP_ITEM
public: getInventory(); getSlot(); getTargetItem(); getCreationTime(); execute(Player $source)
### TransactionQueue (interface) — pocketmine/inventory/TransactionQueue.php
consts: DEFAULT_ALLOWED_RETRIES
