# pocketmine_tile (18 classes)

### BrewingStand (class) — extends Spawnable | implements InventoryHolder, Container, Nameable | pocketmine/tile/BrewingStand.php
consts: MAX_BREW_TIME
public: __construct(FullChunk $chunk, CompoundTag $nbt); getName(); hasName(); setName($str); close(); saveNBT(); getSize(); getItem($index); setItem($index, Item $item); getInventory(); checkIngredient(Item $item); updateSurface(); onUpdate(); getSpawnCompound()
protected: getSlotIndex($index)
### Cauldron (class) — extends Spawnable | pocketmine/tile/Cauldron.php
public: __construct(FullChunk $chunk, CompoundTag $nbt); getPotionId(); setPotionId($potionId); hasPotion(); getSplashPotion(); setSplashPotion($bool); getCustomColor(); getCustomColorRed(); getCustomColorGreen(); getCustomColorBlue(); isCustomColor(); setCustomColor($r, $g = 0xff, $b = 0xff); clearCustomColor(); getSpawnCompound()
### Chest (class) — extends Spawnable | implements InventoryHolder, Container, Nameable | pocketmine/tile/Chest.php
public: __construct(FullChunk $chunk, CompoundTag $nbt); close(); saveNBT(); getSize(); getItem($index); setItem($index, Item $item); getInventory(); getRealInventory(); getDoubleInventory(); getName(); hasName(); setName($str); isPaired(); getPair(); pairWith(Chest $tile); unpair(); getSpawnCompound()
protected: getSlotIndex($index); checkPairing()
### Container (interface) — pocketmine/tile/Container.php
public: getItem($index); setItem($index, Item $item); getSize()
### DLDetector (class) — extends Spawnable | pocketmine/tile/DLDetector.php
public: __construct(FullChunk $chunk, CompoundTag $nbt); getLightByTime(); isActivated(); onUpdate(); getSpawnCompound()
### Dispenser (class) — extends Spawnable | implements InventoryHolder, Container, Nameable | pocketmine/tile/Dispenser.php
public: __construct(FullChunk $chunk, CompoundTag $nbt); close(); saveNBT(); getSize(); getItem($index); setItem($index, Item $item); getInventory(); getName(); hasName(); setName($str); getMotion(); activate(); getSpawnCompound()
protected: getSlotIndex($index)
### Dropper (class) — extends Spawnable | implements InventoryHolder, Container, Nameable | pocketmine/tile/Dropper.php
public: __construct(FullChunk $chunk, CompoundTag $nbt); close(); saveNBT(); getSize(); getItem($index); setItem($index, Item $item); getInventory(); getName(); hasName(); setName($str); getMotion(); activate(); getSpawnCompound()
protected: getSlotIndex($index)
### EnchantTable (class) — extends Spawnable | implements Nameable | pocketmine/tile/EnchantTable.php
public: __construct(FullChunk $chunk, CompoundTag $nbt); getName(); hasName(); setName($str); getSpawnCompound()
### FlowerPot (class) — extends Spawnable | pocketmine/tile/FlowerPot.php
public: __construct(FullChunk $chunk, CompoundTag $nbt); getFlowerPotItem(); getFlowerPotData(); setFlowerPotData($item, $data); getSpawnCompound()
### Furnace (class) — extends Spawnable | implements InventoryHolder, Container, Nameable | pocketmine/tile/Furnace.php
public: __construct(FullChunk $chunk, CompoundTag $nbt); getName(); hasName(); setName($str); close(); saveNBT(); getSize(); getItem($index); setItem($index, Item $item); getInventory(); onUpdate(); getSpawnCompound()
protected: getSlotIndex($index); checkFuel(Item $fuel)
### Hopper (class) — extends Spawnable | implements InventoryHolder, Container, Nameable | pocketmine/tile/Hopper.php
public: __construct(FullChunk $chunk, CompoundTag $nbt); close(); activate(); deactivate(); canUpdate(); resetCooldownTicks(); onUpdate(); getInventory(); getSize(); getItem($index); setItem($index, Item $item); saveNBT(); getName(); hasName(); setName($str); hasLock(); setLock(string $itemName = ""); checkLock(string $key); getSpawnCompound()
protected: getSlotIndex($index)
### ItemFrame (class) — extends Spawnable | pocketmine/tile/ItemFrame.php
public: __construct(FullChunk $chunk, CompoundTag $nbt); getName(); getItemRotation(); setItemRotation(int $itemRotation); getItem(); setItem(Item $item, bool $setChanged = true); getItemDropChance(); setItemDropChance(float $chance = 1.0); getSpawnCompound()
### MobSpawner (class) — extends Spawnable | pocketmine/tile/MobSpawner.php
public: __construct(FullChunk $chunk, CompoundTag $nbt); getEntityId(); setEntityId(int $id); getSpawnCount(); setSpawnCount(int $value); getSpawnRange(); setSpawnRange(int $value); getMinSpawnDelay(); setMinSpawnDelay(int $value); getMaxSpawnDelay(); setMaxSpawnDelay(int $value); getDelay(); setDelay(int $value); getName(); canUpdate(); onUpdate(); getSpawnCompound()
### Nameable (interface) — pocketmine/tile/Nameable.php
public: getName(); setName($str); hasName()
### Sign (class) — extends Spawnable | pocketmine/tile/Sign.php
public: __construct(FullChunk $chunk, CompoundTag $nbt); saveNBT(); setText($line1 = "", $line2 = "", $line3 = "", $line4 = ""); getText(); getSpawnCompound()
### Skull (class) — extends Spawnable | pocketmine/tile/Skull.php
public: __construct(FullChunk $chunk, CompoundTag $nbt); saveNBT(); getSpawnCompound(); getSkullType()
### Spawnable (class) — extends Tile | pocketmine/tile/Spawnable.php
public: spawnTo(Player $player); __construct(FullChunk $chunk, CompoundTag $nbt); spawnToAll()
### Tile (class) — extends Position | pocketmine/tile/Tile.php
consts: SIGN, CHEST, FURNACE, FLOWER_POT, MOB_SPAWNER, SKULL, BREWING_STAND, ENCHANT_TABLE, ITEM_FRAME, DISPENSER, DROPPER, DAY_LIGHT_DETECTOR, CAULDRON, HOPPER
public: static createTile($type, FullChunk $chunk, CompoundTag $nbt, ...$args); static registerTile($className); getSaveId(); __construct(FullChunk $chunk, CompoundTag $nbt); getId(); saveNBT(); getBlock(); onUpdate(); __destruct(); close(); getName()
