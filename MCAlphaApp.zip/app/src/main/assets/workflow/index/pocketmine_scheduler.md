# pocketmine_scheduler (12 classes)

### AsyncPool (class) — pocketmine/scheduler/AsyncPool.php
public: __construct(Server $server, $size); getSize(); increaseSize($newSize); submitTaskToWorker(AsyncTask $task, $worker); submitTask(AsyncTask $task); removeTasks(); collectTasks()
### AsyncTask (class) — extends \Threaded | implements \Collectable | pocketmine/scheduler/AsyncTask.php
public: isGarbage(); setGarbage(); isFinished(); run(); isCrashed(); getResult(); cancelRun(); hasCancelledRun(); hasResult(); setResult($result, $serialize = true); setTaskId($taskId); getTaskId(); getFromThreadStore($identifier); saveToThreadStore($identifier, $value); onCompletion(Server $server); cleanObject()
### AsyncWorker (class) — extends Worker | pocketmine/scheduler/AsyncWorker.php
public: __construct(\ThreadedLogger $logger, $id); run(); handleException(\Throwable $e); getThreadName()
### CallbackTask (class) — extends Task | pocketmine/scheduler/CallbackTask.php
public: __construct(callable $callable, array $args = []); getCallable(); onRun($currentTicks)
### DServerTask (class) — extends AsyncTask | pocketmine/scheduler/DServerTask.php
public: __construct($data, $autotimes = 5); onRun(); getInfo($ds, $time = 1); onCompletion(Server $server); decode($buffer)
### FileWriteTask (class) — extends AsyncTask | pocketmine/scheduler/FileWriteTask.php
public: __construct($path, $contents, $flags = 0); onRun()
### GarbageCollectionTask (class) — extends AsyncTask | pocketmine/scheduler/GarbageCollectionTask.php
public: onRun()
### PluginTask (class) — extends Task | pocketmine/scheduler/PluginTask.php
public: __construct(Plugin $owner)
### SendUsageTask (class) — extends AsyncTask | pocketmine/scheduler/SendUsageTask.php
consts: TYPE_OPEN, TYPE_STATUS, TYPE_CLOSE
public: __construct(Server $server, $type, $playerList = []); onRun()
### ServerScheduler (class) — pocketmine/scheduler/ServerScheduler.php
public: __construct(); scheduleTask(Task $task); scheduleAsyncTask(AsyncTask $task); scheduleAsyncTaskToWorker(AsyncTask $task, $worker); getAsyncTaskPoolSize(); increaseAsyncTaskPoolSize($newSize); scheduleDelayedTask(Task $task, $delay); scheduleRepeatingTask(Task $task, $period); scheduleDelayedRepeatingTask(Task $task, $delay, $period); cancelTask($taskId); cancelTasks(Plugin $plugin); cancelAllTasks(); isQueued($taskId); mainThreadHeartbeat($currentTick)
### Task (class) — pocketmine/scheduler/Task.php
public: onCancel()
### TaskHandler (class) — pocketmine/scheduler/TaskHandler.php
public: __construct($timingName, Task $task, $taskId, $delay = -1, $period = -1); isCancelled(); getNextRun(); setNextRun($ticks); getTaskId(); getTask(); getDelay(); isDelayed(); isRepeating(); getPeriod(); cancel(); remove(); run($currentTick); getTaskName()
