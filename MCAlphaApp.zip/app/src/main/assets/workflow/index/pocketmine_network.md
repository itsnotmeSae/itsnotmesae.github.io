# pocketmine_network (132 classes)

### AddEntityPacket (class) — extends DataPacket | pocketmine/network/protocol/AddEntityPacket.php
consts: NETWORK_ID
public: decode(); encode()
### AddEntityPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/AddEntityPacket.php
consts: NETWORK_ID
public: decode(); encode()
### AddItemEntityPacket (class) — extends DataPacket | pocketmine/network/protocol/AddItemEntityPacket.php
consts: NETWORK_ID
public: decode(); encode()
### AddItemEntityPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/AddItemEntityPacket.php
consts: NETWORK_ID
public: decode(); encode()
### AddPaintingPacket (class) — extends DataPacket | pocketmine/network/protocol/AddPaintingPacket.php
consts: NETWORK_ID
public: decode(); encode()
### AddPaintingPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/AddPaintingPacket.php
consts: NETWORK_ID
public: decode(); encode()
### AddPlayerPacket (class) — extends DataPacket | pocketmine/network/protocol/AddPlayerPacket.php
consts: NETWORK_ID
public: decode(); encode()
### AddPlayerPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/AddPlayerPacket.php
consts: NETWORK_ID
public: decode(); encode()
### AdvancedSourceInterface (interface) — extends SourceInterface | pocketmine/network/AdvancedSourceInterface.php
public: blockAddress($address, $timeout = 300); setNetwork(Network $network); sendRawPacket($address, $port, $payload)
### AdventureSettingsPacket (class) — extends DataPacket | pocketmine/network/protocol/AdventureSettingsPacket.php
consts: NETWORK_ID
public: decode(); encode()
### AdventureSettingsPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/AdventureSettingsPacket.php
consts: NETWORK_ID
public: decode(); encode()
### AnimatePacket (class) — extends DataPacket | pocketmine/network/protocol/AnimatePacket.php
consts: NETWORK_ID
public: decode(); encode()
### AnimatePacket (class) — extends DataPacket | pocketmine/network/protocol/p70/AnimatePacket.php
consts: NETWORK_ID
public: decode(); encode()
### AnyVersionManager (class) — pocketmine/network/AnyVersionManager.php
public: static parsePacket(Player $player, $packet); static isProtocol(Player $player, string $version); static getAcceptedProtocols(); static getGameVersion(int $protocol)
### BatchPacket (class) — extends DataPacket | pocketmine/network/protocol/BatchPacket.php
consts: NETWORK_ID
public: decode(); encode()
### BatchPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/BatchPacket.php
consts: NETWORK_ID
public: decode(); encode()
### BlockEntityDataPacket (class) — extends DataPacket | pocketmine/network/protocol/BlockEntityDataPacket.php
consts: NETWORK_ID
public: decode(); encode()
### BlockEntityDataPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/BlockEntityDataPacket.php
consts: NETWORK_ID
public: decode(); encode()
### BlockEventPacket (class) — extends DataPacket | pocketmine/network/protocol/BlockEventPacket.php
consts: NETWORK_ID
public: decode(); encode()
### BlockEventPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/BlockEventPacket.php
consts: NETWORK_ID
public: decode(); encode()
### CachedEncapsulatedPacket (class) — extends EncapsulatedPacket | pocketmine/network/CachedEncapsulatedPacket.php
public: toBinary($internal = false)
### ChangeDimensionPacket (class) — extends DataPacket | pocketmine/network/protocol/ChangeDimensionPacket.php
consts: NETWORK_ID, DIMENSION_NORMAL, DIMENSION_NETHER
public: decode(); encode()
### ChangeDimensionPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/ChangeDimensionPacket.php
consts: NETWORK_ID, NORMAL, NETHER
public: decode(); encode()
### ChunkRadiusUpdatePacket (class) — extends DataPacket | pocketmine/network/protocol/p70/ChunkRadiusUpdatePacket.php
consts: NETWORK_ID
public: decode(); encode()
### ChunkRadiusUpdatedPacket (class) — extends DataPacket | pocketmine/network/protocol/ChunkRadiusUpdatedPacket.php
consts: NETWORK_ID
public: decode(); encode()
### ClientboundMapItemDataPacket (class) — extends DataPacket | pocketmine/network/protocol/ClientboundMapItemDataPacket.php
consts: NETWORK_ID, BITFLAG_TEXTURE_UPDATE, BITFLAG_DECORATION_UPDATE
public: decode(); encode()
### ClientboundMapItemDataPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/ClientboundMapItemDataPacket.php
consts: NETWORK_ID, BITFLAG_TEXTURE_UPDATE, BITFLAG_DECORATION_UPDATE
public: decode(); encode()
### CompressBatchedTask (class) — extends AsyncTask | pocketmine/network/CompressBatchedTask.php
public: __construct($data, array $targets, $level = 7); onRun(); onCompletion(Server $server)
### ContainerClosePacket (class) — extends DataPacket | pocketmine/network/protocol/ContainerClosePacket.php
consts: NETWORK_ID
public: decode(); encode()
### ContainerClosePacket (class) — extends DataPacket | pocketmine/network/protocol/p70/ContainerClosePacket.php
consts: NETWORK_ID
public: decode(); encode()
### ContainerOpenPacket (class) — extends DataPacket | pocketmine/network/protocol/ContainerOpenPacket.php
consts: NETWORK_ID
public: decode(); encode()
### ContainerOpenPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/ContainerOpenPacket.php
consts: NETWORK_ID
public: decode(); encode()
### ContainerSetContentPacket (class) — extends DataPacket | pocketmine/network/protocol/ContainerSetContentPacket.php
consts: NETWORK_ID, SPECIAL_INVENTORY, SPECIAL_ARMOR, SPECIAL_CREATIVE, SPECIAL_HOTBAR
public: clean(); decode(); encode()
### ContainerSetContentPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/ContainerSetContentPacket.php
consts: NETWORK_ID, SPECIAL_INVENTORY, SPECIAL_ARMOR, SPECIAL_CREATIVE
public: clean(); decode(); encode()
### ContainerSetDataPacket (class) — extends DataPacket | pocketmine/network/protocol/ContainerSetDataPacket.php
consts: NETWORK_ID
public: decode(); encode()
### ContainerSetDataPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/ContainerSetDataPacket.php
consts: NETWORK_ID
public: decode(); encode()
### ContainerSetSlotPacket (class) — extends DataPacket | pocketmine/network/protocol/ContainerSetSlotPacket.php
consts: NETWORK_ID
public: decode(); encode()
### ContainerSetSlotPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/ContainerSetSlotPacket.php
consts: NETWORK_ID
public: decode(); encode()
### CraftingDataPacket (class) — extends DataPacket | pocketmine/network/protocol/CraftingDataPacket.php
consts: NETWORK_ID, ENTRY_SHAPELESS, ENTRY_SHAPED, ENTRY_FURNACE, ENTRY_FURNACE_DATA, ENTRY_ENCHANT_LIST
public: addShapelessRecipe(ShapelessRecipe $recipe); addShapedRecipe(ShapedRecipe $recipe); addFurnaceRecipe(FurnaceRecipe $recipe); addEnchantList(EnchantmentList $list); clean(); decode(); encode()
### CraftingDataPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/CraftingDataPacket.php
consts: NETWORK_ID, ENTRY_SHAPELESS, ENTRY_SHAPED, ENTRY_FURNACE, ENTRY_FURNACE_DATA, ENTRY_ENCHANT_LIST
public: addShapelessRecipe(ShapelessRecipe $recipe); addShapedRecipe(ShapedRecipe $recipe); addFurnaceRecipe(FurnaceRecipe $recipe); addEnchantList(EnchantmentList $list); clean(); decode(); encode()
### CraftingEventPacket (class) — extends DataPacket | pocketmine/network/protocol/CraftingEventPacket.php
consts: NETWORK_ID
public: clean(); decode(); encode()
### CraftingEventPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/CraftingEventPacket.php
consts: NETWORK_ID
public: clean(); decode(); encode()
### DataPacket (class) — extends BinaryStream | pocketmine/network/protocol/DataPacket.php
consts: NETWORK_ID
public: pid(); reset(); clean(); __debugInfo()
### DataPacket (class) — extends BinaryStream | pocketmine/network/protocol/p70/DataPacket.php
consts: NETWORK_ID
public: pid(); reset(); setChannel($channel); getChannel(); clean(); __debugInfo()
### DisconnectPacket (class) — extends DataPacket | pocketmine/network/protocol/DisconnectPacket.php
consts: NETWORK_ID
public: decode(); encode()
### DisconnectPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/DisconnectPacket.php
consts: NETWORK_ID
public: decode(); encode()
### DropItemPacket (class) — extends DataPacket | pocketmine/network/protocol/DropItemPacket.php
consts: NETWORK_ID
public: decode(); encode()
### DropItemPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/DropItemPacket.php
consts: NETWORK_ID
public: decode(); encode()
### EntityEventPacket (class) — extends DataPacket | pocketmine/network/protocol/EntityEventPacket.php
consts: NETWORK_ID, HURT_ANIMATION, DEATH_ANIMATION, TAME_FAIL, TAME_SUCCESS, SHAKE_WET, USE_ITEM, EAT_GRASS_ANIMATION, FISH_HOOK_BUBBLE, FISH_HOOK_POSITION, FISH_HOOK_HOOK, FISH_HOOK_TEASE, SQUID_INK_CLOUD, AMBIENT_SOUND, RESPAWN
public: decode(); encode()
### EntityEventPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/EntityEventPacket.php
consts: NETWORK_ID, HURT_ANIMATION, DEATH_ANIMATION, TAME_FAIL, TAME_SUCCESS, SHAKE_WET, USE_ITEM, EAT_GRASS_ANIMATION, FISH_HOOK_BUBBLE, FISH_HOOK_POSITION, FISH_HOOK_HOOK, FISH_HOOK_TEASE, SQUID_INK_CLOUD, AMBIENT_SOUND, RESPAWN
public: decode(); encode()
### ExplodePacket (class) — extends DataPacket | pocketmine/network/protocol/ExplodePacket.php
consts: NETWORK_ID
public: clean(); decode(); encode()
### ExplodePacket (class) — extends DataPacket | pocketmine/network/protocol/p70/ExplodePacket.php
consts: NETWORK_ID
public: clean(); decode(); encode()
### FullChunkDataPacket (class) — extends DataPacket | pocketmine/network/protocol/FullChunkDataPacket.php
consts: NETWORK_ID, ORDER_COLUMNS, ORDER_LAYERED
public: decode(); encode()
### FullChunkDataPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/FullChunkDataPacket.php
consts: NETWORK_ID, ORDER_COLUMNS, ORDER_LAYERED
public: decode(); encode()
### HurtArmorPacket (class) — extends DataPacket | pocketmine/network/protocol/HurtArmorPacket.php
consts: NETWORK_ID
public: decode(); encode()
### HurtArmorPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/HurtArmorPacket.php
consts: NETWORK_ID
public: decode(); encode()
### Info (interface) — pocketmine/network/protocol/Info.php
consts: CURRENT_PROTOCOL, LOGIN_PACKET, PLAY_STATUS_PACKET, SERVER_TO_CLIENT_HANDSHAKE_PACKET, CLIENT_TO_SERVER_HANDSHAKE_PACKET, DISCONNECT_PACKET, BATCH_PACKET, TEXT_PACKET, SET_TIME_PACKET, START_GAME_PACKET, ADD_PLAYER_PACKET, ADD_ENTITY_PACKET, REMOVE_ENTITY_PACKET, ADD_ITEM_ENTITY_PACKET, TAKE_ITEM_ENTITY_PACKET, MOVE_ENTITY_PACKET, MOVE_PLAYER_PACKET, RIDER_JUMP_PACKET, REMOVE_BLOCK_PACKET, UPDATE_BLOCK_PACKET, ADD_PAINTING_PACKET, EXPLODE_PACKET, LEVEL_EVENT_PACKET, BLOCK_EVENT_PACKET, ENTITY_EVENT_PACKET, MOB_EFFECT_PACKET, UPDATE_ATTRIBUTES_PACKET, MOB_EQUIPMENT_PACKET, MOB_ARMOR_EQUIPMENT_PACKET, INTERACT_PACKET, USE_ITEM_PACKET, PLAYER_ACTION_PACKET, HURT_ARMOR_PACKET, SET_ENTITY_DATA_PACKET, SET_ENTITY_MOTION_PACKET, SET_ENTITY_LINK_PACKET, SET_HEALTH_PACKET, SET_SPAWN_POSITION_PACKET, ANIMATE_PACKET, RESPAWN_PACKET, DROP_ITEM_PACKET, CONTAINER_OPEN_PACKET, CONTAINER_CLOSE_PACKET, CONTAINER_SET_SLOT_PACKET, CONTAINER_SET_DATA_PACKET, CONTAINER_SET_CONTENT_PACKET, CRAFTING_DATA_PACKET, CRAFTING_EVENT_PACKET, ADVENTURE_SETTINGS_PACKET, BLOCK_ENTITY_DATA_PACKET, PLAYER_INPUT_PACKET, FULL_CHUNK_DATA_PACKET, SET_DIFFICULTY_PACKET, CHANGE_DIMENSION_PACKET, SET_PLAYER_GAMETYPE_PACKET, PLAYER_LIST_PACKET, TELEMETRY_EVENT_PACKET, SPAWN_EXPERIENCE_ORB_PACKET, CLIENTBOUND_MAP_ITEM_DATA_PACKET, MAP_INFO_REQUEST_PACKET
### Info (interface) — pocketmine/network/protocol/p70/Info.php
consts: LOGIN_PACKET, PLAY_STATUS_PACKET, DISCONNECT_PACKET, BATCH_PACKET, TEXT_PACKET, SET_TIME_PACKET, START_GAME_PACKET, ADD_PLAYER_PACKET, REMOVE_PLAYER_PACKET, ADD_ENTITY_PACKET, REMOVE_ENTITY_PACKET, ADD_ITEM_ENTITY_PACKET, TAKE_ITEM_ENTITY_PACKET, MOVE_ENTITY_PACKET, MOVE_PLAYER_PACKET, REMOVE_BLOCK_PACKET, UPDATE_BLOCK_PACKET, ADD_PAINTING_PACKET, EXPLODE_PACKET, LEVEL_EVENT_PACKET, BLOCK_EVENT_PACKET, ENTITY_EVENT_PACKET, MOB_EFFECT_PACKET, UPDATE_ATTRIBUTES_PACKET, MOB_EQUIPMENT_PACKET, MOB_ARMOR_EQUIPMENT_PACKET, INTERACT_PACKET, USE_ITEM_PACKET, PLAYER_ACTION_PACKET, HURT_ARMOR_PACKET, SET_ENTITY_DATA_PACKET, SET_ENTITY_MOTION_PACKET, SET_ENTITY_LINK_PACKET, SET_HEALTH_PACKET, SET_SPAWN_POSITION_PACKET, ANIMATE_PACKET, RESPAWN_PACKET, DROP_ITEM_PACKET, CONTAINER_OPEN_PACKET, CONTAINER_CLOSE_PACKET, CONTAINER_SET_SLOT_PACKET, CONTAINER_SET_DATA_PACKET, CONTAINER_SET_CONTENT_PACKET, CRAFTING_DATA_PACKET, CRAFTING_EVENT_PACKET, ADVENTURE_SETTINGS_PACKET, BLOCK_ENTITY_DATA_PACKET, PLAYER_INPUT_PACKET, FULL_CHUNK_DATA_PACKET, SET_DIFFICULTY_PACKET, CHANGE_DIMENSION_PACKET, SET_PLAYER_GAMETYPE_PACKET, PLAYER_LIST_PACKET, TELEMETRY_EVENT_PACKET, SPAWN_EXPERIENCE_ORB_PACKET, CLIENTBOUND_MAP_ITEM_DATA_PACKET, MAP_INFO_REQUEST_PACKET, REQUEST_CHUNK_RADIUS_PACKET, CHUNK_RADIUS_UPDATE_PACKET, ITEM_FRAME_DROP_ITEM_PACKET
### InteractPacket (class) — extends DataPacket | pocketmine/network/protocol/InteractPacket.php
consts: NETWORK_ID, ACTION_RIGHT_CLICK, ACTION_LEFT_CLICK, ACTION_LEAVE_VEHICLE
public: decode(); encode()
### InteractPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/InteractPacket.php
consts: NETWORK_ID, ACTION_RIGHT_CLICK, ACTION_LEFT_CLICK, ACTION_LEAVE_VEHICLE
public: decode(); encode()
### ItemFrameDropItemPacket (class) — extends DataPacket | pocketmine/network/protocol/ItemFrameDropItemPacket.php
consts: NETWORK_ID
public: decode(); encode()
### ItemFrameDropPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/ItemFrameDropPacket.php
consts: NETWORK_ID
public: decode(); encode()
### LevelEventPacket (class) — extends DataPacket | pocketmine/network/protocol/LevelEventPacket.php
consts: NETWORK_ID, EVENT_SOUND_CLICK, EVENT_SOUND_CLICK_FAIL, EVENT_SOUND_SHOOT, EVENT_SOUND_DOOR, EVENT_SOUND_FIZZ, EVENT_SOUND_TNT, EVENT_SOUND_GHAST, EVENT_SOUND_GHAST_SHOOT, EVENT_SOUND_BLAZE_SHOOT, EVENT_SOUND_DOOR_BUMP, EVENT_SOUND_DOOR_CRASH, EVENT_SOUND_BAT_FLY, EVENT_SOUND_ZOMBIE_INFECT, EVENT_SOUND_ZOMBIE_HEAL, EVENT_SOUND_ENDERMAN_TELEPORT, EVENT_SOUND_ANVIL_BREAK, EVENT_SOUND_ANVIL_USE, EVENT_SOUND_ANVIL_FALL, EVENT_SOUND_DROP_ITEM, EVENT_SOUND_THROW_PROJECTILE, EVENT_SOUND_ITEMFRAME_ADD_ITEM, EVENT_SOUND_ITEMFRAME_PLACE, EVENT_SOUND_ITEMFRAME_DROP_ITEM, EVENT_SOUND_ITEMFRAME_ROTATE_ITEM, EVENT_SOUND_EXP_PICKUP, EVENT_SOUND_BLOCK_PLACE, EVENT_SOUND_BUTTON_CLICK, EVENT_PARTICLE_SHOOT, EVENT_PARTICLE_DESTROY, EVENT_PARTICLE_SPLASH, EVENT_PARTICLE_EYE_DESPAWN, EVENT_PARTICLE_SPAWN, EVENT_START_RAIN, EVENT_START_THUNDER, EVENT_STOP_RAIN, EVENT_STOP_THUNDER, EVENT_SOUND_EXPLODE, EVENT_SOUND_SPELL, EVENT_SOUND_SPLASH, EVENT_SOUND_GRAY_SPLASH, EVENT_SET_DATA, EVENT_PLAYERS_SLEEPING, EVENT_ADD_PARTICLE_MASK
public: decode(); encode()
### LevelEventPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/LevelEventPacket.php
consts: NETWORK_ID, EVENT_SOUND_CLICK, EVENT_SOUND_CLICK_FAIL, EVENT_SOUND_SHOOT, EVENT_SOUND_DOOR, EVENT_SOUND_FIZZ, EVENT_SOUND_GHAST, EVENT_SOUND_GHAST_SHOOT, EVENT_SOUND_BLAZE_SHOOT, EVENT_SOUND_DOOR_BUMP, EVENT_SOUND_DOOR_CRASH, EVENT_SOUND_BAT_FLY, EVENT_SOUND_ZOMBIE_INFECT, EVENT_SOUND_ZOMBIE_HEAL, EVENT_SOUND_ENDERMAN_TELEPORT, EVENT_SOUND_ANVIL_BREAK, EVENT_SOUND_ANVIL_USE, EVENT_SOUND_ANVIL_FALL, EVENT_PARTICLE_SHOOT, EVENT_PARTICLE_DESTROY, EVENT_PARTICLE_SPLASH, EVENT_PARTICLE_EYE_DESPAWN, EVENT_PARTICLE_SPAWN, EVENT_START_RAIN, EVENT_START_THUNDER, EVENT_STOP_RAIN, EVENT_STOP_THUNDER, EVENT_SOUND_BUTTON_CLICK, EVENT_SOUND_BUTTON_RETURN, EVENT_SOUND_EXPLODE, EVENT_SOUND_SPELL, EVENT_SOUND_SPLASH, EVENT_SOUND_GRAY_SPLASH, EVENT_SET_DATA, EVENT_PLAYERS_SLEEPING, EVENT_ADD_PARTICLE_MASK
public: decode(); encode()
### LoginPacket (class) — extends DataPacket | pocketmine/network/protocol/LoginPacket.php
consts: NETWORK_ID, MOJANG_PUBKEY
public: decode(); encode(); decodeToken($token, $key)
### LoginPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/LoginPacket.php
consts: NETWORK_ID
public: decode(); encode()
### MapInfoRequestPacket (class) — extends DataPacket | pocketmine/network/protocol/MapInfoRequestPacket.php
consts: NETWORK_ID
public: decode(); encode()
### MapInfoRequestPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/MapInfoRequestPacket.php
consts: NETWORK_ID
public: decode(); encode()
### MobArmorEquipmentPacket (class) — extends DataPacket | pocketmine/network/protocol/MobArmorEquipmentPacket.php
consts: NETWORK_ID
public: decode(); encode()
### MobArmorEquipmentPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/MobArmorEquipmentPacket.php
consts: NETWORK_ID
public: decode(); encode()
### MobEffectPacket (class) — extends DataPacket | pocketmine/network/protocol/MobEffectPacket.php
consts: NETWORK_ID, EVENT_ADD, EVENT_MODIFY, EVENT_REMOVE
public: decode(); encode()
### MobEffectPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/MobEffectPacket.php
consts: NETWORK_ID, EVENT_ADD, EVENT_MODIFY, EVENT_REMOVE
public: decode(); encode()
### MobEquipmentPacket (class) — extends DataPacket | pocketmine/network/protocol/MobEquipmentPacket.php
consts: NETWORK_ID
public: decode(); encode()
### MobEquipmentPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/MobEquipmentPacket.php
consts: NETWORK_ID
public: decode(); encode()
### MoveEntityPacket (class) — extends DataPacket | pocketmine/network/protocol/MoveEntityPacket.php
consts: NETWORK_ID
public: decode(); encode()
### MoveEntityPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/MoveEntityPacket.php
consts: NETWORK_ID
public: clean(); decode(); encode()
### MovePlayerPacket (class) — extends DataPacket | pocketmine/network/protocol/MovePlayerPacket.php
consts: NETWORK_ID, MODE_NORMAL, MODE_RESET, MODE_ROTATION
public: clean(); decode(); encode()
### MovePlayerPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/MovePlayerPacket.php
consts: NETWORK_ID, MODE_NORMAL, MODE_RESET, MODE_ROTATION
public: clean(); decode(); encode()
### Network (class) — pocketmine/network/Network.php
public: __construct(Server$server); addStatistics($upload,$download); getUpload(); getDownload(); resetStatistics(); getInterfaces(); processInterfaces(); registerInterface(SourceInterface$interface); unregisterInterface(SourceInterface$interface); setName($name); getName(); updateName(); registerPacket($id,$class); getServer(); processBatch($packet,Player$p); getPacket($id); sendPacket($address,$port,$payload); blockAddress($address,$timeout=300); unblockAddress($address)
### PlayStatusPacket (class) — extends DataPacket | pocketmine/network/protocol/PlayStatusPacket.php
consts: NETWORK_ID, LOGIN_SUCCESS, LOGIN_FAILED_CLIENT, LOGIN_FAILED_SERVER, PLAYER_SPAWN
public: decode(); encode()
### PlayStatusPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/PlayStatusPacket.php
consts: NETWORK_ID, LOGIN_SUCCESS, LOGIN_FAILED_CLIENT, LOGIN_FAILED_SERVER, PLAYER_SPAWN
public: decode(); encode()
### PlayerActionPacket (class) — extends DataPacket | pocketmine/network/protocol/PlayerActionPacket.php
consts: NETWORK_ID, ACTION_START_BREAK, ACTION_ABORT_BREAK, ACTION_STOP_BREAK, ACTION_RELEASE_ITEM, ACTION_STOP_SLEEPING, ACTION_SPAWN_SAME_DIMENSION, ACTION_JUMP, ACTION_START_SPRINT, ACTION_STOP_SPRINT, ACTION_START_SNEAK, ACTION_STOP_SNEAK, ACTION_SPAWN_OVERWORLD, ACTION_SPAWN_NETHER
public: decode(); encode()
### PlayerActionPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/PlayerActionPacket.php
consts: NETWORK_ID, ACTION_START_BREAK, ACTION_ABORT_BREAK, ACTION_STOP_BREAK, ACTION_RELEASE_ITEM, ACTION_STOP_SLEEPING, ACTION_RESPAWN, ACTION_JUMP, ACTION_START_SPRINT, ACTION_STOP_SPRINT, ACTION_START_SNEAK, ACTION_STOP_SNEAK, ACTION_DIMENSION_CHANGE
public: decode(); encode()
### PlayerInputPacket (class) — extends DataPacket | pocketmine/network/protocol/PlayerInputPacket.php
consts: NETWORK_ID
public: decode(); encode()
### PlayerInputPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/PlayerInputPacket.php
consts: NETWORK_ID
public: decode(); encode()
### PlayerListPacket (class) — extends DataPacket | pocketmine/network/protocol/PlayerListPacket.php
consts: NETWORK_ID, TYPE_ADD, TYPE_REMOVE
public: clean(); decode(); encode()
### PlayerListPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/PlayerListPacket.php
consts: NETWORK_ID, TYPE_ADD, TYPE_REMOVE
public: clean(); decode(); encode()
### QueryHandler (class) — pocketmine/network/query/QueryHandler.php
consts: HANDSHAKE, STATISTICS
public: __construct(); regenerateInfo(); regenerateToken(); static getTokenString($token, $salt); handle($address, $port, $packet)
### RCON (class) — pocketmine/network/rcon/RCON.php
consts: PROTOCOL_VERSION
public: __construct(Server $server, $password, $port = 19132, $interface = "0.0.0.0", $threads = 1, $clientsPerThread = 50); stop(); check()
### RCONInstance (class) — extends Thread | pocketmine/network/rcon/RCONInstance.php
public: isWaiting(); __construct($logger, $socket, $password, $maxClients = 50); close(); run(); getThreadName()
### RakLibInterface (class) — implements ServerInstance, AdvancedSourceInterface | pocketmine/network/RakLibInterface.php
public: __construct(Server $server); setNetwork(Network $network); process(); closeSession($identifier, $reason); close(Player $player, $reason = "unknown reason"); shutdown(); emergencyShutdown(); openSession($identifier, $address, $port, $clientID); handleEncapsulated($identifier, EncapsulatedPacket $packet, $flags); blockAddress($address, $timeout = 300); unblockAddress($address); handleRaw($address, $port, $payload); sendRawPacket($address, $port, $payload); notifyACK($identifier, $identifierACK); setName($name); setPortCheck($name); handleOption($name, $value); putPacket(Player $player, /*DataPacket*/ $packet, $needACK = false, $immediate = false); handlePing($identifier, $ping)
### RemoveBlockPacket (class) — extends DataPacket | pocketmine/network/protocol/RemoveBlockPacket.php
consts: NETWORK_ID
public: decode(); encode()
### RemoveBlockPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/RemoveBlockPacket.php
consts: NETWORK_ID
public: decode(); encode()
### RemoveEntityPacket (class) — extends DataPacket | pocketmine/network/protocol/RemoveEntityPacket.php
consts: NETWORK_ID
public: decode(); encode()
### RemoveEntityPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/RemoveEntityPacket.php
consts: NETWORK_ID
public: decode(); encode()
### RemovePlayerPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/RemovePlayerPacket.php
consts: NETWORK_ID
public: decode(); encode()
### RequestChunkRadiusPacket (class) — extends DataPacket | pocketmine/network/protocol/RequestChunkRadiusPacket.php
consts: NETWORK_ID
public: decode(); encode()
### RequestChunkRadiusPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/RequestChunkRadiusPacket.php
consts: NETWORK_ID
public: decode(); encode()
### RespawnPacket (class) — extends DataPacket | pocketmine/network/protocol/RespawnPacket.php
consts: NETWORK_ID
public: decode(); encode()
### RespawnPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/RespawnPacket.php
consts: NETWORK_ID
public: decode(); encode()
### SetDifficultyPacket (class) — extends DataPacket | pocketmine/network/protocol/SetDifficultyPacket.php
consts: NETWORK_ID
public: decode(); encode()
### SetDifficultyPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/SetDifficultyPacket.php
consts: NETWORK_ID
public: decode(); encode()
### SetEntityDataPacket (class) — extends DataPacket | pocketmine/network/protocol/SetEntityDataPacket.php
consts: NETWORK_ID
public: decode(); encode()
### SetEntityDataPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/SetEntityDataPacket.php
consts: NETWORK_ID
public: decode(); encode()
### SetEntityLinkPacket (class) — extends DataPacket | pocketmine/network/protocol/SetEntityLinkPacket.php
consts: NETWORK_ID, TYPE_REMOVE, TYPE_RIDE, TYPE_PASSENGER
public: decode(); encode()
### SetEntityLinkPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/SetEntityLinkPacket.php
consts: NETWORK_ID, TYPE_REMOVE, TYPE_RIDE, TYPE_PASSENGER
public: decode(); encode()
### SetEntityMotionPacket (class) — extends DataPacket | pocketmine/network/protocol/SetEntityMotionPacket.php
consts: NETWORK_ID
public: clean(); decode(); encode()
### SetEntityMotionPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/SetEntityMotionPacket.php
consts: NETWORK_ID
public: clean(); decode(); encode()
### SetHealthPacket (class) — extends DataPacket | pocketmine/network/protocol/SetHealthPacket.php
consts: NETWORK_ID
public: decode(); encode()
### SetHealthPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/SetHealthPacket.php
consts: NETWORK_ID
public: decode(); encode()
### SetPlayerGameTypePacket (class) — extends DataPacket | pocketmine/network/protocol/SetPlayerGameTypePacket.php
consts: NETWORK_ID
public: decode(); encode()
### SetPlayerGameTypePacket (class) — extends DataPacket | pocketmine/network/protocol/p70/SetPlayerGameTypePacket.php
consts: NETWORK_ID
public: decode(); encode()
### SetSpawnPositionPacket (class) — extends DataPacket | pocketmine/network/protocol/SetSpawnPositionPacket.php
consts: NETWORK_ID
public: decode(); encode()
### SetSpawnPositionPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/SetSpawnPositionPacket.php
consts: NETWORK_ID
public: decode(); encode()
### SetTimePacket (class) — extends DataPacket | pocketmine/network/protocol/SetTimePacket.php
consts: NETWORK_ID
public: decode(); encode()
### SetTimePacket (class) — extends DataPacket | pocketmine/network/protocol/p70/SetTimePacket.php
consts: NETWORK_ID
public: decode(); encode()
### SourceInterface (interface) — pocketmine/network/SourceInterface.php
public: putPacket(Player $player, /*DataPacket*/ $packet, $needACK = false, $immediate = true); close(Player $player, $reason = "unknown reason"); setName($name); process(); shutdown(); emergencyShutdown()
### StartGamePacket (class) — extends DataPacket | pocketmine/network/protocol/StartGamePacket.php
consts: NETWORK_ID
public: decode(); encode()
### StartGamePacket (class) — extends DataPacket | pocketmine/network/protocol/p70/StartGamePacket.php
consts: NETWORK_ID
public: decode(); encode()
### StrangePacket (class) — extends DataPacket | pocketmine/network/protocol/StrangePacket.php
consts: NETWORK_ID
public: pid(); decode(); encode()
protected: putAddress($addr, $port, $version = 4)
### TakeItemEntityPacket (class) — extends DataPacket | pocketmine/network/protocol/TakeItemEntityPacket.php
consts: NETWORK_ID
public: decode(); encode()
### TakeItemEntityPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/TakeItemEntityPacket.php
consts: NETWORK_ID
public: decode(); encode()
### TextPacket (class) — extends DataPacket | pocketmine/network/protocol/TextPacket.php
consts: NETWORK_ID, TYPE_RAW, TYPE_CHAT, TYPE_TRANSLATION, TYPE_POPUP, TYPE_TIP, TYPE_SYSTEM
public: decode(); encode()
### TextPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/TextPacket.php
consts: NETWORK_ID, TYPE_RAW, TYPE_CHAT, TYPE_TRANSLATION, TYPE_POPUP, TYPE_TIP, TYPE_SYSTEM
public: decode(); encode()
### UPnP (class) — pocketmine/network/upnp/UPnP.php
public: static PortForward($port); static RemovePortForward($port)
### UpdateAttributePacket (class) — extends DataPacket | pocketmine/network/protocol/p70/UpdateAttributePacket.php
consts: NETWORK_ID
public: decode(); encode()
### UpdateAttributesPacket (class) — extends DataPacket | pocketmine/network/protocol/UpdateAttributesPacket.php
consts: NETWORK_ID
public: decode(); encode()
### UpdateAttributesPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/UpdateAttributesPacket.php
consts: NETWORK_ID
public: decode(); encode()
### UpdateBlockPacket (class) — extends DataPacket | pocketmine/network/protocol/UpdateBlockPacket.php
consts: NETWORK_ID, FLAG_NONE, FLAG_NEIGHBORS, FLAG_NETWORK, FLAG_NOGRAPHIC, FLAG_PRIORITY, FLAG_ALL, FLAG_ALL_PRIORITY
public: decode(); encode()
### UpdateBlockPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/UpdateBlockPacket.php
consts: NETWORK_ID, FLAG_NONE, FLAG_NEIGHBORS, FLAG_NETWORK, FLAG_NOGRAPHIC, FLAG_PRIORITY, FLAG_ALL, FLAG_ALL_PRIORITY
public: decode(); encode()
### UseItemPacket (class) — extends DataPacket | pocketmine/network/protocol/UseItemPacket.php
consts: NETWORK_ID
public: decode(); encode()
### UseItemPacket (class) — extends DataPacket | pocketmine/network/protocol/p70/UseItemPacket.php
consts: NETWORK_ID
public: decode(); encode()
