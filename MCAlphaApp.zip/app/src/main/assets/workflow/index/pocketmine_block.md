# pocketmine_block (196 classes)

### AcaciaDoor (class) — extends Door | pocketmine/block/AcaciaDoor.php
public: __construct($meta = 0); getName(); canBeActivated(); getHardness(); getToolType(); getDrops(Item $item)
### AcaciaWoodStairs (class) — extends WoodStairs | pocketmine/block/AcaciaWoodStairs.php
public: getName()
### ActivatorRail (class) — extends PoweredRail | pocketmine/block/ActivatorRail.php
public: __construct($meta = 0); getName()
### ActiveRedstoneLamp (class) — extends Solid | implements ElectricalAppliance, SolidLight | pocketmine/block/ActiveRedstoneLamp.php
public: __construct($meta = 0); getName(); getHardness(); getToolType(); getLightLevel(); getDrops(Item $item); isLightedByAround(); lightAround(); turnOn(); turnOff()
protected: checkPower(array $ignore = []); turnAroundOff(array $ignore = [])
### Air (class) — extends Transparent | pocketmine/block/Air.php
public: __construct(); getName(); canPassThrough(); isBreakable(Item $item); canBeFlowedInto(); canBeReplaced(); canBePlaced(); isSolid(); getBoundingBox(); getHardness(); getResistance()
### Anvil (class) — extends Fallable | pocketmine/block/Anvil.php
consts: NORMAL, SLIGHTLY_DAMAGED, VERY_DAMAGED
public: isSolid(); __construct($meta = 0); canBeActivated(); getHardness(); getResistance(); getName(); getToolType(); onActivate(Item $item, Player $player = null); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); getDrops(Item $item)
### Bed (class) — extends Transparent | pocketmine/block/Bed.php
public: __construct($meta = 0); canBeActivated(); getHardness(); getName(); onActivate(Item $item, Player $player = null); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onBreak(Item $item); getDrops(Item $item)
protected: recalculateBoundingBox()
### Bedrock (class) — extends Solid | pocketmine/block/Bedrock.php
public: __construct(); getName(); getHardness(); getResistance(); isBreakable(Item $item)
### Beetroot (class) — extends Crops | pocketmine/block/Beetroot.php
public: __construct($meta = 0); getName(); getDrops(Item $item)
### BirchDoor (class) — extends Door | pocketmine/block/BirchDoor.php
public: __construct($meta = 0); getName(); canBeActivated(); getHardness(); getToolType(); getDrops(Item $item)
### BirchWoodStairs (class) — extends WoodStairs | pocketmine/block/BirchWoodStairs.php
public: getName()
### Block (class) — extends Position | implements BlockIds, Metadatable | pocketmine/block/Block.php
public: static init(); static get($id, $meta = 0, Position $pos = null); __construct($id, $meta = 0); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); isBreakable(Item $item); tickRate(); onBreak(Item $item); onUpdate($type); onActivate(Item $item, Player $player = null); getHardness(); getResistance(); getBurnChance(); getBurnAbility(); isTopFacingSurfaceSolid(); canNeighborBurn(); getToolType(); getFrictionFactor(); getLightLevel(); canBePlaced(); isPlaceable(); canBeReplaced(); isTransparent(); isSolid(); canBeFlowedInto(); canBeActivated(); activate(); deactivate(); isActivated(Block $from = null); hasEntityCollision(); canPassThrough(); getName(); addVelocityToEntity(Entity $entity, Vector3 $vector); getDrops(Item $item); getBreakTime(Item $item); canBeBrokenWith(Item $item); getSide($side, $step = 1); __toString(); collidesWithBB(AxisAlignedBB $bb); onEntityCollide(Entity $entity); getBoundingBox(); calculateIntercept(Vector3 $pos1, Vector3 $pos2); setMetadata($metadataKey, MetadataValue $metadataValue); getMetadata($metadataKey); hasMetadata($metadataKey); removeMetadata($metadataKey, Plugin $plugin)
protected: recalculateBoundingBox()
### BlockIds (interface) — pocketmine/block/BlockIds.php
consts: AIR, STONE, GRASS, DIRT, COBBLESTONE, PLANK, SAPLING, BEDROCK, WATER, STILL_WATER, LAVA, STILL_LAVA, SAND, GRAVEL, GOLD_ORE, IRON_ORE, COAL_ORE, LOG, LEAVES, SPONGE, GLASS, LAPIS_ORE, LAPIS_BLOCK, DISPENSER, SANDSTONE, NOTEBLOCK, BED_BLOCK, POWERED_RAIL, DETECTOR_RAIL, STICKY_PISTON, COBWEB, TALL_GRASS, BUSH, DEAD_BUSH, PISTON, PISTON_HEAD, WOOL, DANDELION, POPPY, BROWN_MUSHROOM, RED_MUSHROOM, GOLD_BLOCK, IRON_BLOCK, DOUBLE_SLAB, SLAB, BRICKS, TNT, BOOKSHELF, MOSS_STONE, OBSIDIAN, TORCH, FIRE, MONSTER_SPAWNER, WOOD_STAIRS, CHEST, REDSTONE_WIRE, DIAMOND_ORE, DIAMOND_BLOCK, CRAFTING_TABLE, WHEAT_BLOCK
### Bookshelf (class) — extends Solid | pocketmine/block/Bookshelf.php
public: __construct(); getName(); getHardness(); getToolType(); getBurnChance(); getBurnAbility(); getDrops(Item $item)
### BrewingStand (class) — extends Transparent | pocketmine/block/BrewingStand.php
public: __construct($meta = 0); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); canBeActivated(); getHardness(); getResistance(); getLightLevel(); getName(); onActivate(Item $item, Player $player = null); getDrops(Item $item)
### BrickStairs (class) — extends Stair | pocketmine/block/BrickStairs.php
public: __construct($meta = 0); getHardness(); getResistance(); getToolType(); getName()
### Bricks (class) — extends Solid | pocketmine/block/Bricks.php
public: __construct(); getHardness(); getResistance(); getToolType(); getName(); getDrops(Item $item)
### BrownMushroom (class) — extends Flowable | pocketmine/block/BrownMushroom.php
public: __construct($meta = 0); getName(); getLightLevel(); onUpdate($type); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); getBoundingBox()
### BrownMushroomBlock (class) — extends Solid | pocketmine/block/BrownMushroomBlock.php
consts: BROWN
public: __construct($meta = 14); canBeActivated(); getName(); getHardness(); getResistance(); getDrops(Item $item)
### BurningFurnace (class) — extends Furnace | implements SolidLight | pocketmine/block/BurningFurnace.php
public: getName(); getLightLevel()
### Cactus (class) — extends Transparent | pocketmine/block/Cactus.php
public: __construct($meta = 0); getHardness(); hasEntityCollision(); getName(); onEntityCollide(Entity $entity); onUpdate($type); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); getDrops(Item $item)
protected: recalculateBoundingBox()
### Cake (class) — extends Transparent | implements FoodSource | pocketmine/block/Cake.php
public: __construct($meta = 0); canBeActivated(); getHardness(); getName(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onUpdate($type); getDrops(Item $item); onActivate(Item $item, Player $player = null); getFoodRestore(); getSaturationRestore(); getResidue(); getAdditionalEffects()
protected: recalculateBoundingBox()
### Carpet (class) — extends Flowable | pocketmine/block/Carpet.php
public: __construct($meta = 0); getHardness(); isSolid(); getName(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onUpdate($type)
protected: recalculateBoundingBox()
### Carrot (class) — extends Crops | pocketmine/block/Carrot.php
public: __construct($meta = 0); getName(); getDrops(Item $item)
### Cauldron (class) — extends Solid | pocketmine/block/Cauldron.php
public: __construct($meta = 0); getHardness(); getName(); canBeActivated(); getToolType(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onBreak(Item $item); getDrops(Item $item); update(); isEmpty(); isFull(); onActivate(Item $item, Player $player = null); addItem(Item $item, Player $player, Item $result)
### Chest (class) — extends Transparent | pocketmine/block/Chest.php
public: __construct($meta = 0); canBeActivated(); getHardness(); getName(); getToolType(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onBreak(Item $item); onActivate(Item $item, Player $player = null); getDrops(Item $item)
protected: recalculateBoundingBox()
### Clay (class) — extends Solid | pocketmine/block/Clay.php
public: __construct(); getHardness(); getToolType(); getName(); getDrops(Item $item)
### Coal (class) — extends Solid | pocketmine/block/Coal.php
public: __construct(); getHardness(); getToolType(); getBurnChance(); getBurnAbility(); getName(); getDrops(Item $item)
### CoalOre (class) — extends Solid | pocketmine/block/CoalOre.php
public: __construct(); getHardness(); getToolType(); getName(); getDrops(Item $item)
### Cobblestone (class) — extends Solid | pocketmine/block/Cobblestone.php
public: __construct(); getToolType(); getName(); getHardness(); getDrops(Item $item)
### CobblestoneStairs (class) — extends Stair | pocketmine/block/CobblestoneStairs.php
public: __construct($meta = 0); getHardness(); getToolType(); getName()
### Cobweb (class) — extends Flowable | pocketmine/block/Cobweb.php
public: __construct(); hasEntityCollision(); getName(); getHardness(); getToolType(); onEntityCollide(Entity $entity); getDrops(Item $item)
### CocoaBlock (class) — extends Solid | pocketmine/block/CocoaBlock.php
public: __construct($meta = 0); getName(); getHardness(); getResistance(); canBeActivated(); onActivate(Item $item, Player $player = null); onUpdate($type); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); getDrops(Item $item)
### Crops (class) — extends Flowable | pocketmine/block/Crops.php
public: canBeActivated(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onActivate(Item $item, Player $player = null); onUpdate($type)
### Dandelion (class) — extends Flowable | pocketmine/block/Dandelion.php
public: __construct(); getName(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onUpdate($type)
### DarkOakDoor (class) — extends Door | pocketmine/block/DarkOakDoor.php
public: __construct($meta = 0); getName(); canBeActivated(); getHardness(); getToolType(); getDrops(Item $item)
### DarkOakWoodStairs (class) — extends WoodStairs | pocketmine/block/DarkOakWoodStairs.php
public: getName()
### DaylightDetector (class) — extends RedstoneSource | pocketmine/block/DaylightDetector.php
public: getName(); getBoundingBox(); canBeFlowedInto(); canBeActivated(); onActivate(Item $item, Player $player = null); isActivated(Block $from = null); onBreak(Item $item); getHardness(); getResistance(); getDrops(Item $item)
protected: getTile()
### DaylightDetectorInverted (class) — extends DaylightDetector | pocketmine/block/DaylightDetectorInverted.php
public: onActivate(Item $item, Player $player = null)
### DeadBush (class) — extends Flowable | pocketmine/block/DeadBush.php
public: __construct($meta = 0); getName(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onUpdate($type); getDrops(Item $item)
### DetectorRail (class) — extends PoweredRail | pocketmine/block/DetectorRail.php
public: __construct($meta = 0); getName()
### Diamond (class) — extends Solid | pocketmine/block/Diamond.php
public: __construct(); getHardness(); getName(); getToolType(); getDrops(Item $item)
### DiamondOre (class) — extends Solid | pocketmine/block/DiamondOre.php
public: __construct(); getHardness(); getName(); getToolType(); getDrops(Item $item)
### Dirt (class) — extends Solid | pocketmine/block/Dirt.php
public: __construct(); canBeActivated(); getHardness(); getToolType(); getName(); onActivate(Item $item, Player $player = null)
### Dispenser (class) — extends Solid | pocketmine/block/Dispenser.php
public: __construct($meta = 0); canBeActivated(); getHardness(); getName(); getToolType(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); activate(); onActivate(Item $item, Player $player = null); getDrops(Item $item)
### Door (class) — extends Transparent | implements ElectricalAppliance | pocketmine/block/Door.php
public: canBeActivated(); isSolid(); canPassThrough(); onUpdate($type); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onBreak(Item $item); isOpened(); onActivate(Item $item, Player $player = null)
protected: recalculateBoundingBox()
### DoublePlant (class) — extends Flowable | pocketmine/block/DoublePlant.php
consts: SUNFLOWER, LILAC, DOUBLE_TALLGRASS, LARGE_FERN, ROSE_BUSH, PEONY
public: __construct($meta = 0); canBeReplaced(); getName(); onUpdate($type); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onBreak(Item $item); getDrops(Item $item)
### DoubleRedSandstoneSlab (class) — extends DoubleSlab | pocketmine/block/DoubleRedSandstoneSlab.php
public: getName(); getDrops(Item $item)
### DoubleSlab (class) — extends Solid | pocketmine/block/DoubleSlab.php
public: __construct($meta = 0); getHardness(); getToolType(); getName(); getDrops(Item $item)
### DoubleWoodSlab (class) — extends Solid | pocketmine/block/DoubleWoodSlab.php
public: __construct($meta = 0); getHardness(); getToolType(); getName(); getDrops(Item $item)
### Dropper (class) — extends Solid | implements ElectricalAppliance | pocketmine/block/Dropper.php
public: __construct($meta = 0); canBeActivated(); getHardness(); getName(); getToolType(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); activate(); onActivate(Item $item, Player $player = null); getDrops(Item $item)
### ElectricalAppliance (interface) — pocketmine/block/ElectricalAppliance.php
### Emerald (class) — extends Solid | pocketmine/block/Emerald.php
public: __construct(); getHardness(); getToolType(); getName(); getDrops(Item $item)
### EmeraldOre (class) — extends Solid | pocketmine/block/EmeraldOre.php
public: __construct(); getName(); getToolType(); getHardness(); getDrops(Item $item)
### EnchantingTable (class) — extends Transparent | pocketmine/block/EnchantingTable.php
public: __construct(); getLightLevel(); getBoundingBox(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); canBeActivated(); getHardness(); getResistance(); getName(); getToolType(); onActivate(Item $item, Player $player = null); getDrops(Item $item)
### EndPortalFrame (class) — extends Solid | implements SolidLight | pocketmine/block/EndPortalFrame.php
public: __construct($meta = 0); getLightLevel(); getName(); getHardness(); getResistance(); isBreakable(Item $item)
protected: recalculateBoundingBox()
### EndStone (class) — extends Solid | pocketmine/block/EndStone.php
public: __construct(); getName(); getToolType(); getHardness()
### Fallable (class) — extends Solid | pocketmine/block/Fallable.php
public: place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onUpdate($type)
### Farmland (class) — extends Solid | pocketmine/block/Farmland.php
public: __construct($meta = 0); getName(); getHardness(); getToolType(); getDrops(Item $item)
protected: recalculateBoundingBox()
### Fence (class) — extends Transparent | pocketmine/block/Fence.php
consts: FENCE_OAK, FENCE_SPRUCE, FENCE_BIRCH, FENCE_JUNGLE, FENCE_ACACIA, FENCE_DARKOAK
public: __construct($meta = 0); getHardness(); getToolType(); getBurnChance(); getBurnAbility(); getName(); canConnect(Block $block)
protected: recalculateBoundingBox()
### FenceGate (class) — extends Transparent | implements ElectricalAppliance | pocketmine/block/FenceGate.php
public: __construct($meta = 0); getName(); getHardness(); canBeActivated(); getToolType(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); isOpened(); getDrops(Item $item); onActivate(Item $item, Player $player = null)
protected: recalculateBoundingBox()
### FenceGateAcacia (class) — extends FenceGate | pocketmine/block/FenceGateAcacia.php
public: getName()
### FenceGateBirch (class) — extends FenceGate | pocketmine/block/FenceGateBirch.php
public: getName()
### FenceGateDarkOak (class) — extends FenceGate | pocketmine/block/FenceGateDarkOak.php
public: getName()
### FenceGateJungle (class) — extends FenceGate | pocketmine/block/FenceGateJungle.php
public: getName()
### FenceGateSpruce (class) — extends FenceGate | pocketmine/block/FenceGateSpruce.php
public: getName()
### Fire (class) — extends Flowable | pocketmine/block/Fire.php
public: __construct($meta = 0); hasEntityCollision(); getName(); getLightLevel(); isBreakable(Item $item); canBeReplaced(); onEntityCollide(Entity $entity); getDrops(Item $item); onUpdate($type); getTickRate()
### Flowable (class) — extends Transparent | pocketmine/block/Flowable.php
public: canBeFlowedInto(); getHardness(); getResistance(); isSolid(); getBoundingBox()
### Flower (class) — extends Flowable | pocketmine/block/Flower.php
consts: TYPE_POPPY, TYPE_BLUE_ORCHID, TYPE_ALLIUM, TYPE_AZURE_BLUET, TYPE_RED_TULIP, TYPE_ORANGE_TULIP, TYPE_WHITE_TULIP, TYPE_PINK_TULIP, TYPE_OXEYE_DAISY
public: __construct($meta = 0); getName(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onUpdate($type)
### FlowerPot (class) — extends Flowable | pocketmine/block/FlowerPot.php
public: __construct($meta = 0); canBeActivated(); getName(); getBoundingBox(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onActivate(Item $item, Player $player = null); onUpdate($type); getDrops(Item $item)
### Furnace (class) — extends Solid | pocketmine/block/Furnace.php
public: __construct($meta = 0); getName(); canBeActivated(); getHardness(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onBreak(Item $item); onActivate(Item $item, Player $player = null); getDrops(Item $item)
### Glass (class) — extends Transparent | pocketmine/block/Glass.php
public: __construct(); getName(); getHardness(); getDrops(Item $item)
### GlassPane (class) — extends Thin | pocketmine/block/GlassPane.php
public: __construct(); getName(); getHardness(); getDrops(Item $item)
### GlowingObsidian (class) — extends Solid | implements SolidLight | pocketmine/block/GlowingObsidian.php
public: __construct($meta = 0); getName(); getLightLevel()
### GlowingRedstoneOre (class) — extends RedstoneOre | implements SolidLight | pocketmine/block/GlowingRedstoneOre.php
public: getName(); getLightLevel(); onUpdate($type)
### Glowstone (class) — extends Transparent | implements SolidLight | pocketmine/block/Glowstone.php
public: __construct(); getName(); getHardness(); getToolType(); getLightLevel(); getDrops(Item $item)
### Gold (class) — extends Solid | pocketmine/block/Gold.php
public: __construct(); getName(); getHardness(); getToolType(); getDrops(Item $item)
### GoldOre (class) — extends Solid | pocketmine/block/GoldOre.php
public: __construct(); getName(); getHardness(); getToolType(); getDrops(Item $item)
### Grass (class) — extends Solid | pocketmine/block/Grass.php
public: __construct(); canBeActivated(); getName(); getHardness(); getToolType(); getDrops(Item $item); onUpdate($type); onActivate(Item $item, Player $player = null)
### GrassPath (class) — extends Transparent | pocketmine/block/GrassPath.php
public: __construct(); getName(); getToolType(); onUpdate($type); getHardness(); getDrops(Item $item)
protected: recalculateBoundingBox()
### Gravel (class) — extends Fallable | pocketmine/block/Gravel.php
public: __construct(); getName(); getHardness(); getToolType(); getDrops(Item $item)
### HardenedClay (class) — extends Solid | pocketmine/block/HardenedClay.php
public: __construct(); getName(); getToolType(); getHardness()
### HayBale (class) — extends Solid | pocketmine/block/HayBale.php
public: __construct($meta = 0); getName(); getHardness(); getBurnChance(); getBurnAbility(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); getDrops(Item $item)
### HeavyWeightedPressurePlate (class) — extends PressurePlate | pocketmine/block/HeavyWeightedPressurePlate.php
public: getName()
### Hopper (class) — extends Transparent | pocketmine/block/Hopper.php
public: __construct($meta = 0); canBeActivated(); getToolType(); getName(); getHardness(); onActivate(Item $item, Player $player = null); activate(); getTarget(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); getDrops(Item $item)
### Ice (class) — extends Transparent | pocketmine/block/Ice.php
public: __construct(); getName(); getHardness(); getToolType(); onBreak(Item $item); getDrops(Item $item)
### InactiveRedstoneLamp (class) — extends ActiveRedstoneLamp | pocketmine/block/InactiveRedstoneLamp.php
public: getLightLevel(); getName(); isLightedByAround(); turnOn(); turnOff()
### InvisibleBedrock (class) — extends Transparent | pocketmine/block/InvisibleBedrock.php
public: __construct(); getName(); getHardness(); getResistance(); isBreakable(Item $item)
### Iron (class) — extends Solid | pocketmine/block/Iron.php
public: __construct(); getName(); getToolType(); getHardness(); getDrops(Item $item)
### IronBars (class) — extends Thin | pocketmine/block/IronBars.php
public: __construct(); getName(); getHardness(); getToolType(); getDrops(Item $item)
### IronDoor (class) — extends Door | pocketmine/block/IronDoor.php
public: __construct($meta = 0); getName(); getToolType(); getHardness(); getDrops(Item $item); onActivate(Item $item, Player $player = null)
### IronOre (class) — extends Solid | pocketmine/block/IronOre.php
public: __construct(); getName(); getToolType(); getHardness(); getDrops(Item $item)
### IronTrapdoor (class) — extends Trapdoor | pocketmine/block/IronTrapdoor.php
public: getName(); getHardness(); getResistance()
### ItemFrame (class) — extends Transparent | pocketmine/block/ItemFrame.php
public: __construct($meta = 0); getName(); canBeActivated(); onActivate(Item $item, Player $player = null); onBreak(Item $item); getDrops(Item $item); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null)
### JungleDoor (class) — extends Door | pocketmine/block/JungleDoor.php
public: __construct($meta = 0); getName(); canBeActivated(); getHardness(); getToolType(); getDrops(Item $item)
### JungleWoodStairs (class) — extends WoodStairs | pocketmine/block/JungleWoodStairs.php
public: getName()
### Ladder (class) — extends Transparent | pocketmine/block/Ladder.php
public: __construct($meta = 0); getName(); hasEntityCollision(); isSolid(); getHardness(); onEntityCollide(Entity $entity); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onUpdate($type); getToolType(); getDrops(Item $item)
protected: recalculateBoundingBox()
### Lapis (class) — extends Solid | pocketmine/block/Lapis.php
public: __construct(); getName(); getToolType(); getHardness(); getDrops(Item $item)
### LapisOre (class) — extends Solid | pocketmine/block/LapisOre.php
public: __construct(); getHardness(); getToolType(); getName(); getDrops(Item $item)
### Lava (class) — extends Liquid | pocketmine/block/Lava.php
public: __construct($meta = 0); getLightLevel(); getName(); onEntityCollide(Entity $entity); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null)
### Leaves (class) — extends Transparent | pocketmine/block/Leaves.php
consts: OAK, SPRUCE, BIRCH, JUNGLE, ACACIA, DARK_OAK, WOOD_TYPE
public: __construct($meta = 0); getHardness(); getToolType(); getBurnChance(); getBurnAbility(); getName(); onUpdate($type); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); getDrops(Item $item)
### Leaves2 (class) — extends Leaves | pocketmine/block/Leaves2.php
consts: WOOD_TYPE
public: __construct($meta = 0); getName(); getDrops(Item $item)
### Lever (class) — extends RedstoneSource | pocketmine/block/Lever.php
public: __construct($meta = 0); canBeActivated(); getName(); onUpdate($type); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); activate(array $ignore = []); deactivate(array $ignore = []); onActivate(Item $item, Player $player = null); onBreak(Item $item); isActivated(Block $from = null); getHardness(); getResistance(); getDrops(Item $item)
### LightWeightedPressurePlate (class) — extends PressurePlate | pocketmine/block/LightWeightedPressurePlate.php
public: getName()
### Liquid (class) — extends Transparent | pocketmine/block/Liquid.php
public: hasEntityCollision(); isBreakable(Item $item); canBeReplaced(); isSolid(); getFluidHeightPercent(); getFlowVector(); addVelocityToEntity(Entity $entity, Vector3 $vector); tickRate(); onUpdate($type); getHardness(); getBoundingBox(); getDrops(Item $item)
protected: getFlowDecay(Vector3 $pos); getEffectiveFlowDecay(Vector3 $pos); triggerLavaMixEffects(Vector3 $pos)
### LitPumpkin (class) — extends Solid | implements SolidLight | pocketmine/block/LitPumpkin.php
public: getLightLevel(); getHardness(); getToolType(); getName(); __construct($meta = 0); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null)
### Melon (class) — extends Transparent | pocketmine/block/Melon.php
public: __construct(); getName(); getHardness(); getToolType(); getDrops(Item $item)
### MelonStem (class) — extends Crops | pocketmine/block/MelonStem.php
public: getName(); __construct($meta = 0); onUpdate($type); getDrops(Item $item)
### MonsterSpawner (class) — extends Solid | pocketmine/block/MonsterSpawner.php
public: __construct($meta = 0); getHardness(); getToolType(); getName(); canBeActivated(); onActivate(Item $item, Player $player = null); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); getDrops(Item $item)
### MossStone (class) — extends Solid | pocketmine/block/MossStone.php
public: __construct($meta = 0); getName(); getHardness(); getToolType(); getDrops(Item $item)
### Mycelium (class) — extends Solid | pocketmine/block/Mycelium.php
public: __construct(); getName(); getToolType(); getHardness(); getDrops(Item $item); onUpdate($type)
### NetherBrick (class) — extends Solid | pocketmine/block/NetherBrick.php
public: __construct(); getToolType(); getName(); getHardness(); getDrops(Item $item)
### NetherBrickFence (class) — extends Transparent | pocketmine/block/NetherBrickFence.php
public: __construct($meta = 0); getBreakTime(Item $item); getHardness(); getToolType(); getName(); canConnect(Block $block); getDrops(Item $item)
### NetherBrickStairs (class) — extends Stair | pocketmine/block/NetherBrickStairs.php
public: getName(); getHardness(); getToolType(); __construct($meta = 0)
### NetherQuartzOre (class) — extends Solid | pocketmine/block/NetherQuartzOre.php
public: __construct(); getName(); getToolType(); getHardness(); getResistance(); getDrops(Item $item)
### NetherReactor (class) — extends Solid | pocketmine/block/NetherReactor.php
public: __construct($meta = 0); getName(); canBeActivated()
### NetherWart (class) — extends Flowable | pocketmine/block/NetherWart.php
public: __construct($meta = 0); getName(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onUpdate($type); getDrops(Item $item)
### Netherrack (class) — extends Solid | pocketmine/block/Netherrack.php
public: __construct(); getName(); getHardness(); getResistance(); getToolType(); getDrops(Item $item)
### Noteblock (class) — extends Solid | implements ElectricalAppliance | pocketmine/block/Noteblock.php
public: __construct($meta = 0); getHardness(); getResistance(); getToolType(); canBeActivated(); getStrength(); getInstrument(); onActivate(Item $item, Player $player = null); getName()
### Obsidian (class) — extends Solid | pocketmine/block/Obsidian.php
public: __construct(); getName(); getToolType(); getHardness(); getDrops(Item $item); onBreak(Item $item)
### PackedIce (class) — extends Solid | pocketmine/block/PackedIce.php
public: __construct(); getName(); getHardness(); getToolType(); getDrops(Item $item)
### Planks (class) — extends Solid | pocketmine/block/Planks.php
consts: OAK, SPRUCE, BIRCH, JUNGLE, ACACIA, DARK_OAK
public: __construct($meta = 0); getHardness(); getToolType(); getBurnChance(); getBurnAbility(); getName()
### Podzol (class) — extends Solid | pocketmine/block/Podzol.php
public: __construct(); getToolType(); getName(); getHardness(); getResistance(); getDrops(Item $item)
### Portal (class) — extends Transparent | pocketmine/block/Portal.php
public: __construct(); getName(); getHardness(); getResistance(); getToolType(); canPassThrough(); hasEntityCollision(); onBreak(Item $item); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); getDrops(Item $item)
### Potato (class) — extends Crops | pocketmine/block/Potato.php
public: __construct($meta = 0); getName(); getDrops(Item $item)
### PoweredRail (class) — extends Rail | pocketmine/block/PoweredRail.php
public: __construct($meta = 0); getName(); canConnect(Rail $block); isBlock(Block $block); connect(Rail $rail, $force = false); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); getHardness(); canPassThrough()
protected: update()
### PoweredRepeater (class) — extends RedstoneSource | pocketmine/block/PoweredRepeater.php
consts: ACTION_ACTIVATE, ACTION_DEACTIVATE
public: __construct($meta = 0); getName(); canBeActivated(); getStrength(); getDirection(); getOppositeDirection(); getDelayLevel(); isActivated(Block $from = null); activate(array $ignore = []); deactivate(array $ignore = []); deactivateImmediately(); onUpdate($type); onActivate(Item $item, Player $player = null); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onBreak(Item $item); getDrops(Item $item)
### PressurePlate (class) — extends RedstoneSource | pocketmine/block/PressurePlate.php
public: __construct($meta = 0); hasEntityCollision(); onEntityCollide(Entity $entity); isActivated(Block $from = null); onUpdate($type); checkActivation(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onBreak(Item $item); getHardness(); getResistance()
### Pumpkin (class) — extends Solid | pocketmine/block/Pumpkin.php
public: __construct(); getHardness(); isHelmet(); getToolType(); getName(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null)
### PumpkinStem (class) — extends Crops | pocketmine/block/PumpkinStem.php
public: __construct($meta = 0); getName(); onUpdate($type); getDrops(Item $item)
### Quartz (class) — extends Solid | pocketmine/block/Quartz.php
consts: QUARTZ_NORMAL, QUARTZ_CHISELED, QUARTZ_PILLAR, QUARTZ_PILLAR2
public: __construct($meta = 0); getHardness(); getName(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); getToolType(); getDrops(Item $item)
### QuartzStairs (class) — extends Stair | pocketmine/block/QuartzStairs.php
public: __construct($meta = 0); getHardness(); getToolType(); getName()
### Rail (class) — extends Flowable | pocketmine/block/Rail.php
consts: STRAIGHT_EAST_WEST, STRAIGHT_NORTH_SOUTH, SLOPED_ASCENDING_NORTH, SLOPED_ASCENDING_SOUTH, SLOPED_ASCENDING_EAST, SLOPED_ASCENDING_WEST, CURVED_NORTH_WEST, CURVED_SOUTH_WEST, CURVED_SOUTH_EAST, CURVED_NORTH_EAST
public: __construct($meta = 0); getName(); canConnect(Rail $block); isBlock(Block $block); connect(Rail $rail, $force = false); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); static check(Rail $rail); getHardness(); getResistance(); canPassThrough()
protected: update()
### RedMushroom (class) — extends Flowable | pocketmine/block/RedMushroom.php
public: __construct(); getName(); onUpdate($type); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null)
### RedMushroomBlock (class) — extends Solid | pocketmine/block/RedMushroomBlock.php
consts: RED, STEM
public: __construct($meta = 14); canBeActivated(); getName(); getHardness(); getResistance(); getDrops(Item $item)
### RedSandstone (class) — extends Sandstone | pocketmine/block/RedSandstone.php
public: getName()
### RedSandstoneSlab (class) — extends Slab | pocketmine/block/RedSandstoneSlab.php
public: getName(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null)
### RedSandstoneStairs (class) — extends SandstoneStairs | pocketmine/block/RedSandstoneStairs.php
public: getName()
### Redstone (class) — extends RedstoneSource | pocketmine/block/Redstone.php
public: __construct(); getBoundingBox(); canBeFlowedInto(); isSolid(); isActivated(Block $from = null); getHardness(); getToolType(); getName(); getDrops(Item $item)
### RedstoneOre (class) — extends Solid | pocketmine/block/RedstoneOre.php
public: __construct(); getName(); getHardness(); onUpdate($type); getToolType(); getDrops(Item $item)
### RedstoneSource (class) — extends Flowable | pocketmine/block/RedstoneSource.php
public: __construct(); getMaxStrength(); isActivated(Block $from = null); canCalc(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onBreak(Item $item); activateBlockWithoutWire(Block $block); activateBlock(Block $block); deactivateBlock(Block $block); deactivateBlockWithoutWire(Block $block); activate(array $ignore = []); deactivate(array $ignore = []); checkPower(Block $block, array $ignore = [], $ignoreWire = false); checkTorchOn(Block $pos, array $ignore = []); checkTorchOff(Block $pos, array $ignore = []); getStrength()
### RedstoneTorch (class) — extends RedstoneSource | pocketmine/block/RedstoneTorch.php
public: __construct($meta = 0); getLightLevel(); getLastUpdateTime(); setLastUpdateTimeNow(); canCalcTurn(); canScheduleUpdate(); getFrequency(); getName(); turnOn($ignore = ""); turnOff($ignore = ""); activateTorch(array $ignore = [], $notCheck = []); activate(array $ignore = []); deactivate(array $ignore = []); deactivateTorch(array $ignore = [], array $notCheck = []); onUpdate($type); onBreak(Item $item); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); getDrops(Item $item); isActivated(Block $from = null)
### RedstoneWire (class) — extends RedstoneSource | pocketmine/block/RedstoneWire.php
consts: ON, OFF, PLACE, DESTROY
public: __construct($meta = 0); getName(); getStrength(); isActivated(Block $from = null); getHighestStrengthAround(); getConnectedWires(); getUnconnectedSide(); activate(array $ignore = []); deactivate(array $ignore = []); getPowerSources(RedstoneWire $wire, array $powers = [], array $hasUpdated = [], $isStart = false); calcSignal($strength = 15, $type = self::ON, array $hasUpdated = []); updateNormalWire(Block $block, $strength, $type, array $hasUpdated); onUpdate($type); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onBreak(Item $item); getDrops(Item $item)
### Sand (class) — extends Fallable | pocketmine/block/Sand.php
consts: NORMAL, RED
public: __construct($meta = 0); getHardness(); getToolType(); getName()
### Sandstone (class) — extends Solid | pocketmine/block/Sandstone.php
consts: NORMAL, CHISELED, SMOOTH
public: __construct($meta = 0); getHardness(); getName(); getToolType(); getDrops(Item $item)
### SandstoneStairs (class) — extends Stair | pocketmine/block/SandstoneStairs.php
public: __construct($meta = 0); getHardness(); getToolType(); getName()
### Sapling (class) — extends Flowable | pocketmine/block/Sapling.php
consts: OAK, SPRUCE, BIRCH, JUNGLE, ACACIA, DARK_OAK
public: __construct($meta = 0); canBeActivated(); getName(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onActivate(Item $item, Player $player = null); onUpdate($type); getDrops(Item $item)
### SignPost (class) — extends Transparent | pocketmine/block/SignPost.php
public: __construct($meta = 0); getHardness(); isSolid(); getName(); getBoundingBox(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onUpdate($type); getDrops(Item $item); getToolType()
### SkullBlock (class) — extends Transparent | pocketmine/block/SkullBlock.php
consts: SKELETON, WITHER_SKELETON, ZOMBIE_HEAD, STEVE_HEAD, CREEPER_HEAD
public: __construct($meta = 0); getHardness(); isHelmet(); isSolid(); getBoundingBox(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); getResistance(); getName(); getToolType(); onBreak(Item $item); getDrops(Item $item)
### Slab (class) — extends Transparent | pocketmine/block/Slab.php
consts: STONE, SANDSTONE, WOODEN, COBBLESTONE, BRICK, STONE_BRICK, QUARTZ, NETHER_BRICK
public: __construct($meta = 0); getHardness(); getName(); getBurnChance(); getBurnAbility(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); getDrops(Item $item); getToolType()
protected: recalculateBoundingBox()
### SlimeBlock (class) — extends Solid | pocketmine/block/SlimeBlock.php
public: __construct($meta = 15); hasEntityCollision(); getHardness(); getName()
### Snow (class) — extends Solid | pocketmine/block/Snow.php
public: __construct($meta = 0); getHardness(); getName(); getDrops(Item $item)
### SnowLayer (class) — extends Flowable | pocketmine/block/SnowLayer.php
public: __construct($meta = 0); getName(); canBeReplaced(); getHardness(); getToolType(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onUpdate($type); getDrops(Item $item)
### Solid (class) — extends Block | pocketmine/block/Solid.php
public: isSolid()
### SolidLight (interface) — pocketmine/block/SolidLight.php
### SoulSand (class) — extends Solid | pocketmine/block/SoulSand.php
public: __construct(); getName(); getHardness(); getToolType()
protected: recalculateBoundingBox()
### Sponge (class) — extends Solid | pocketmine/block/Sponge.php
public: __construct(); getHardness(); getName()
### SpruceDoor (class) — extends Door | pocketmine/block/SpruceDoor.php
public: __construct($meta = 0); getName(); canBeActivated(); getHardness(); getToolType(); getDrops(Item $item)
### SpruceWoodStairs (class) — extends WoodStairs | pocketmine/block/SpruceWoodStairs.php
public: getName()
### StainedClay (class) — extends Solid | pocketmine/block/StainedClay.php
public: __construct($meta = 0); getHardness(); getToolType(); getName()
### Stair (class) — extends Transparent | pocketmine/block/Stair.php
public: collidesWithBB(AxisAlignedBB $bb, &$list = []); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); getHardness(); getResistance(); getDrops(Item $item)
protected: recalculateBoundingBox()
### StillLava (class) — extends Lava | pocketmine/block/StillLava.php
public: onUpdate($type); getName()
### StillWater (class) — extends Water | pocketmine/block/StillWater.php
public: onUpdate($type); getName()
### Stone (class) — extends Solid | pocketmine/block/Stone.php
consts: NORMAL, GRANITE, POLISHED_GRANITE, DIORITE, POLISHED_DIORITE, ANDESITE, POLISHED_ANDESITE
public: __construct($meta = 0); getHardness(); getToolType(); getName(); getDrops(Item $item)
### StoneBrickStairs (class) — extends Stair | pocketmine/block/StoneBrickStairs.php
public: __construct($meta = 0); getToolType(); getHardness(); getName()
### StoneBricks (class) — extends Solid | pocketmine/block/StoneBricks.php
consts: NORMAL, MOSSY, CRACKED, CHISELED
public: __construct($meta = 0); getHardness(); getToolType(); getName(); getDrops(Item $item)
### StoneButton (class) — extends WoodenButton | pocketmine/block/StoneButton.php
public: getName(); onActivate(Item $item, Player $player = null)
### StonePressurePlate (class) — extends PressurePlate | pocketmine/block/StonePressurePlate.php
public: getName()
### StoneWall (class) — extends Transparent | pocketmine/block/StoneWall.php
consts: NONE_MOSSY_WALL, MOSSY_WALL
public: __construct($meta = 0); isSolid(); getToolType(); getHardness(); getName(); canConnect(Block $block)
protected: recalculateBoundingBox()
### Stonecutter (class) — extends Solid | pocketmine/block/Stonecutter.php
public: __construct($meta = 0); getName(); getToolType(); getDrops(Item $item)
### Sugarcane (class) — extends Flowable | pocketmine/block/Sugarcane.php
public: __construct($meta = 0); getName(); getDrops(Item $item); onActivate(Item $item, Player $player = null); onUpdate($type); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null)
### TNT (class) — extends Solid | implements ElectricalAppliance | pocketmine/block/TNT.php
public: __construct(); getName(); getHardness(); canBeActivated(); getBurnChance(); getBurnAbility(); prime(Player $player = null); onUpdate($type); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onActivate(Item $item, Player $player = null)
### TallGrass (class) — extends Flowable | pocketmine/block/TallGrass.php
consts: NORMAL, FERN
public: __construct($meta = 1); canBeReplaced(); getName(); getBurnChance(); getBurnAbility(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onUpdate($type); getToolType(); getDrops(Item $item)
### Thin (class) — extends Transparent | pocketmine/block/Thin.php
public: isSolid(); canConnect(Block $block)
protected: recalculateBoundingBox()
### Torch (class) — extends Flowable | pocketmine/block/Torch.php
public: __construct($meta = 0); getLightLevel(); getName(); onUpdate($type); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); getDrops(Item $item)
### Transparent (class) — extends Block | pocketmine/block/Transparent.php
public: isTransparent()
### Trapdoor (class) — extends Transparent | pocketmine/block/Trapdoor.php
public: __construct($meta = 0); getName(); getHardness(); getResistance(); canBeActivated(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); getDrops(Item $item); isOpened(); onActivate(Item $item, Player $player = \null); getToolType()
protected: recalculateBoundingBox()
### TrappedChest (class) — extends RedstoneSource | pocketmine/block/TrappedChest.php
public: __construct($meta = 0); getBoundingBox(); isSolid(); canBeFlowedInto(); canBeActivated(); getHardness(); getResistance(); getName(); getToolType(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onBreak(Item $item); onActivate(Item $item, Player $player = null); getDrops(Item $item)
protected: recalculateBoundingBox()
### Tripwire (class) — extends Transparent | pocketmine/block/Tripwire.php
public: __construct($meta = 0); getName(); getToolType(); getHardness(); getResistance()
### TripwireHook (class) — extends Solid | pocketmine/block/TripwireHook.php
public: __construct($meta = 0); getName(); getHardness(); getResistance()
### UnlitRedstoneTorch (class) — extends RedstoneTorch | pocketmine/block/UnlitRedstoneTorch.php
public: getLightLevel(); isActivated(Block $from = null)
### UnpoweredRepeater (class) — extends PoweredRepeater | pocketmine/block/UnpoweredRepeater.php
public: getName(); getStrength(); isActivated(Block $from = null); onBreak(Item $item)
### Vine (class) — extends Transparent | pocketmine/block/Vine.php
public: __construct($meta = 0); isSolid(); getName(); getHardness(); canPassThrough(); hasEntityCollision(); onEntityCollide(Entity $entity); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onUpdate($type); getDrops(Item $item); getToolType()
protected: recalculateBoundingBox()
### WallSign (class) — extends SignPost | pocketmine/block/WallSign.php
public: getName(); onUpdate($type)
### Water (class) — extends Liquid | pocketmine/block/Water.php
public: __construct($meta = 0); getName(); onEntityCollide(Entity $entity); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null)
### WaterLily (class) — extends Flowable | pocketmine/block/WaterLily.php
public: __construct($meta = 0); isSolid(); getName(); getHardness(); getResistance(); canPassThrough(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); onUpdate($type); getDrops(Item $item)
protected: recalculateBoundingBox()
### Wheat (class) — extends Crops | pocketmine/block/Wheat.php
public: __construct($meta = 0); getName(); getDrops(Item $item)
### Wood (class) — extends Solid | pocketmine/block/Wood.php
consts: OAK, SPRUCE, BIRCH, JUNGLE
public: __construct($meta = 0); getHardness(); getName(); getBurnChance(); getBurnAbility(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); getDrops(Item $item); getToolType()
### Wood2 (class) — extends Wood | pocketmine/block/Wood2.php
consts: ACACIA, DARK_OAK
public: getName()
### WoodDoor (class) — extends Door | pocketmine/block/WoodDoor.php
public: __construct($meta = 0); getName(); canBeActivated(); getHardness(); getToolType(); getDrops(Item $item)
### WoodSlab (class) — extends Transparent | pocketmine/block/WoodSlab.php
public: __construct($meta = 0); getHardness(); getName(); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); getToolType(); getDrops(Item $item)
protected: recalculateBoundingBox()
### WoodStairs (class) — extends Stair | pocketmine/block/WoodStairs.php
public: __construct($meta = 0); getName(); getToolType(); getDrops(Item $item); getBurnChance(); getBurnAbility(); getHardness()
### WoodenButton (class) — extends RedstoneSource | pocketmine/block/WoodenButton.php
public: __construct($meta = 0); onUpdate($type); deactivate(array $ignore = []); activate(array $ignore = []); getName(); getHardness(); onBreak(Item $item); place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null); canBeActivated(); isActivated(Block $from = null); onActivate(Item $item, Player $player = null)
### WoodenPressurePlate (class) — extends PressurePlate | pocketmine/block/WoodenPressurePlate.php
public: getName()
### Wool (class) — extends Solid | pocketmine/block/Wool.php
consts: WHITE, ORANGE, MAGENTA, LIGHT_BLUE, YELLOW, LIME, PINK, GRAY, LIGHT_GRAY, CYAN, PURPLE, BLUE, BROWN, GREEN, RED, BLACK
public: __construct($meta = 0); getHardness(); getToolType(); getName(); getBurnChance(); getBurnAbility()
### Workbench (class) — extends Solid | pocketmine/block/Workbench.php
public: __construct($meta = 0); canBeActivated(); getHardness(); getName(); getToolType(); onActivate(Item $item, Player $player = null); getDrops(Item $item)
