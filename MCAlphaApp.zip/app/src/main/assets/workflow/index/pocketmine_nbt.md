# pocketmine_nbt (15 classes)

### ByteArrayTag (class) — extends NamedTag | pocketmine/nbt/tag/ByteArrayTag.php
public: getType(); read(NBT $nbt); write(NBT $nbt)
### ByteTag (class) — extends NamedTag | pocketmine/nbt/tag/ByteTag.php
public: getType(); read(NBT $nbt); write(NBT $nbt)
### CompoundTag (class) — extends NamedTag | implements \ArrayAccess | pocketmine/nbt/tag/CompoundTag.php
public: __construct($name = "", $value = []); getCount(); offsetExists($offset); offsetGet($offset); offsetSet($offset, $value); offsetUnset($offset); getType(); read(NBT $nbt); write(NBT $nbt); __toString()
### DoubleTag (class) — extends NamedTag | pocketmine/nbt/tag/DoubleTag.php
public: getType(); read(NBT $nbt); write(NBT $nbt)
### EndTag (class) — extends Tag | pocketmine/nbt/tag/EndTag.php
public: getType(); read(NBT $nbt); write(NBT $nbt)
### FloatTag (class) — extends NamedTag | pocketmine/nbt/tag/FloatTag.php
public: getType(); read(NBT $nbt); write(NBT $nbt)
### IntArrayTag (class) — extends NamedTag | pocketmine/nbt/tag/IntArrayTag.php
public: getType(); read(NBT $nbt); write(NBT $nbt); __toString()
### IntTag (class) — extends NamedTag | pocketmine/nbt/tag/IntTag.php
public: getType(); read(NBT $nbt); write(NBT $nbt)
### ListTag (class) — extends NamedTag | implements \ArrayAccess, \Countable | pocketmine/nbt/tag/ListTag.php
public: __construct($name = "", $value = []); getValue(); getCount(); offsetExists($offset); offsetGet($offset); offsetSet($offset, $value); offsetUnset($offset); count($mode = COUNT_NORMAL); getType(); setTagType($type); getTagType(); read(NBT $nbt); write(NBT $nbt); __toString()
### LongTag (class) — extends NamedTag | pocketmine/nbt/tag/LongTag.php
public: getType(); read(NBT $nbt); write(NBT $nbt)
### NBT (class) — pocketmine/nbt/NBT.php
consts: LITTLE_ENDIAN, BIG_ENDIAN, TAG_End, TAG_Byte, TAG_Short, TAG_Int, TAG_Long, TAG_Float, TAG_Double, TAG_ByteArray, TAG_String, TAG_List, TAG_Compound, TAG_IntArray
public: static putItemHelper(Item $item, $slot = null); static getItemHelper(CompoundTag $tag); static matchList(ListTag $tag1, ListTag $tag2); static matchTree(CompoundTag $tag1, CompoundTag $tag2); static combineCompoundTags(CompoundTag $tag1, CompoundTag $tag2, bool $override = false); static parseJSON($data, &$offset = 0); get($len); put($v); feof(); __construct($endianness = self::LITTLE_ENDIAN); read($buffer, $doMultiple = false); readCompressed($buffer, $compression = ZLIB_ENCODING_GZIP); write(); writeCompressed($compression = ZLIB_ENCODING_GZIP, $level = 7); readTag(); writeTag(Tag $tag); getByte(); putByte($v); getShort(); putShort($v); getInt(); putInt($v); getLong(); putLong($v); getFloat(); putFloat($v); getDouble(); putDouble($v); getString(); putString($v); getArray(); static fromArrayGuesser($key, $value); setArray(array $data, callable $guesser = null); getData(); setData($data)
### NamedTag (class) — extends Tag | pocketmine/nbt/tag/NamedTag.php
public: __construct($name = "", $value = null); getName(); setName($name)
### ShortTag (class) — extends NamedTag | pocketmine/nbt/tag/ShortTag.php
public: getType(); read(NBT $nbt); write(NBT $nbt)
### StringTag (class) — extends NamedTag | pocketmine/nbt/tag/StringTag.php
public: getType(); read(NBT $nbt); write(NBT $nbt)
### Tag (class) — extends \stdClass | pocketmine/nbt/tag/Tag.php
public: getValue(); setValue($value); __toString()
