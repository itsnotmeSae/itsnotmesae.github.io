# pocketmine_utils (26 classes)

### Binary (class) — pocketmine/utils/Binary.php
consts: BIG_ENDIAN, LITTLE_ENDIAN
public: static readTriad($str); static writeTriad($value); static readLTriad($str); static writeLTriad($value); static writeMetadata(array $data); static readMetadata($value, $types = false); static readBool($b); static writeBool($b); static readByte($c, $signed = true); static writeByte($c); static readShort($str); static readSignedShort($str); static writeShort($value); static readLShort($str); static readSignedLShort($str); static writeLShort($value); static readInt($str); static writeInt($value); static readLInt($str); static writeLInt($value); static readFloat($str); static writeFloat($value); static readLFloat($str); static writeLFloat($value); static printFloat($value); static readDouble($str); static writeDouble($value); static readLDouble($str); static writeLDouble($value); static readLong($x); static writeLong($value); static readLLong($str); static writeLLong($value)
### Binary (class) — pocketmine/utils/p70/Binary.php
consts: BIG_ENDIAN, LITTLE_ENDIAN
public: static readTriad($str); static writeTriad($value); static readLTriad($str); static writeLTriad($value); static writeMetadata(array $data); static readMetadata($value, $types = false); static readBool($b); static writeBool($b); static readByte($c, $signed = true); static writeByte($c); static readShort($str); static readSignedShort($str); static writeShort($value); static readLShort($str); static readSignedLShort($str); static writeLShort($value); static readInt($str); static writeInt($value); static readLInt($str); static writeLInt($value); static readFloat($str); static writeFloat($value); static readLFloat($str); static writeLFloat($value); static printFloat($value); static readDouble($str); static writeDouble($value); static readLDouble($str); static writeLDouble($value); static readLong($x); static writeLong($value); static readLLong($str); static writeLLong($value)
### BinaryStream (class) — extends \stdClass | pocketmine/utils/BinaryStream.php
public: __construct($buffer = "", $offset = 0); reset(); setBuffer($buffer = null, $offset = 0); getOffset(); getBuffer(); get($len); put($str); getLong(); putLong($v); getInt(); putInt($v); getLLong(); putLLong($v); getLInt(); putLInt($v); getSignedShort(); putShort($v); getShort(); putSignedShort($v); getFloat(); putFloat($v); getLShort($signed = true); putLShort($v); getLFloat(); putLFloat($v); getTriad(); putTriad($v); getLTriad(); putLTriad($v); getByte(); putByte($v); getDataArray($len = 10); putDataArray(array $data = []); getUUID(); putUUID(/*UUID*/ $uuid); getSlot(); putSlot(Item $item); getString(); putString($v); feof()
### BinaryStream (class) — extends \stdClass | pocketmine/utils/p70/BinaryStream.php
public: __construct($buffer = "", $offset = 0); reset(); setBuffer($buffer = null, $offset = 0); getOffset(); getBuffer(); get($len); put($str); getLong(); putLong($v); getInt(); putInt($v); getLLong(); putLLong($v); getLInt(); putLInt($v); getSignedShort(); putShort($v); getShort(); putSignedShort($v); getFloat(); putFloat($v); getLShort($signed = true); putLShort($v); getLFloat(); putLFloat($v); getTriad(); putTriad($v); getLTriad(); putLTriad($v); getByte(); putByte($v); getDataArray($len = 10); putDataArray(array $data = []); getUUID(); putUUID(/*\pocketmine\utils\UUID*/ $uuid); getSlot(); putSlot(Item $item); getString(); putString($v); feof()
### BlockIterator (class) — implements \Iterator | pocketmine/utils/BlockIterator.php
public: __construct(Level $level, Vector3 $start, Vector3 $direction, $yOffset = 0, $maxDistance = 0); next(); current(); rewind(); key(); valid()
### ChunkException (class) — extends \RuntimeException | pocketmine/utils/ChunkException.php
### Color (class) — pocketmine/utils/Color.php
consts: COLOR_DYE_BLACK, COLOR_DYE_RED, COLOR_DYE_GREEN, COLOR_DYE_BROWN, COLOR_DYE_BLUE, COLOR_DYE_PURPLE, COLOR_DYE_CYAN, COLOR_DYE_LIGHT_GRAY, COLOR_DYE_GRAY, COLOR_DYE_PINK, COLOR_DYE_LIME, COLOR_DYE_YELLOW, COLOR_DYE_LIGHT_BLUE, COLOR_DYE_MAGENTA, COLOR_DYE_ORANGE, COLOR_DYE_WHITE
public: static init(); static getRGB($r, $g, $b); static averageColor(Color ...$colors); static getDyeColor($id); __construct($r, $g, $b); getRed(); getBlue(); getGreen(); getColorCode(); __toString()
### Config (class) — pocketmine/utils/Config.php
consts: DETECT, PROPERTIES, CNF, JSON, YAML, SERIALIZED, ENUM, ENUMERATION
public: __construct($file, $type = Config::DETECT, $default = [], &$correct = null); reload(); static fixYAMLIndexes($str); load($file, $type = Config::DETECT, $default = []); check(); save($async = false); __get($k); __set($k, $v); __isset($k); __unset($k); setNested($key, $value); getNested($key, $default = null); get($k, $default = false); set($k, $v = true); setAll($v); exists($k, $lowercase = false); remove($k); getAll($keys = false); setDefaults(array $defaults)
### LevelException (class) — extends ServerException | pocketmine/utils/LevelException.php
### MainLogger (class) — extends \AttachableThreadedLogger | pocketmine/utils/MainLogger.php
public: setSendMsg($b); getMessages(); __construct($logFile, $logDebug = false); static getLogger(); emergency($message, $name = "EMERGENCY"); alert($message, $name = "ALERT"); critical($message, $name = "CRITICAL"); error($message, $name = "ERROR"); warning($message, $name = "WARNING"); notice($message, $name = "NOTICE"); info($message, $name = "INFO"); debug($message, $name = "DEBUG"); setLogDebug($logDebug); logException(\Throwable $e, $trace = null); log($level, $message); shutdown(); run(); setWrite($write); setConsoleCallback($callback)
protected: send($message, $level, $prefix, $color)
### MonkeyPatch (class) — pocketmine/utils/MonkeyPatch.php
public: __construct()
### Patchable (interface) — pocketmine/utils/Patchable.php
### PluginException (class) — extends ServerException | pocketmine/utils/PluginException.php
### Random (class) — pocketmine/utils/Random.php
consts: X, Y, Z, W
public: __construct($seed = -1); setSeed($seed); getSeed(); nextInt(); nextSignedInt(); nextFloat(); nextSignedFloat(); nextBoolean(); nextRange($start = 0, $end = 0x7fffffff); nextBoundedInt($bound)
### Range (class) — pocketmine/utils/Range.php
public: __construct(int $min, int $max); isInRange(int $v)
### ReversePriorityQueue (class) — extends \SplPriorityQueue | pocketmine/utils/ReversePriorityQueue.php
public: compare($priority1, $priority2)
### ServerException (class) — extends \RuntimeException | pocketmine/utils/ServerException.php
### ServerKiller (class) — extends Thread | pocketmine/utils/ServerKiller.php
public: __construct($time = 15); run(); getThreadName()
### Terminal (class) — pocketmine/utils/Terminal.php
public: static hasFormattingCodes(); static init()
protected: static getFallbackEscapeCodes(); static getEscapeCodes()
### TextFormat (class) — pocketmine/utils/TextFormat.php
consts: ESCAPE, BLACK, DARK_BLUE, DARK_GREEN, DARK_AQUA, DARK_RED, DARK_PURPLE, GOLD, GRAY, DARK_GRAY, BLUE, GREEN, AQUA, RED, LIGHT_PURPLE, YELLOW, WHITE, OBFUSCATED, BOLD, STRIKETHROUGH, UNDERLINE, ITALIC, RESET
public: static tokenize($string); static clean($string, $removeFormat = true); static toJSON($string); static toHTML($string); static toANSI($string)
### UUID (class) — pocketmine/utils/UUID.php
public: __construct($part1 = 0, $part2 = 0, $part3 = 0, $part4 = 0, $version = null); getVersion(); equals(/*UUID*/ $uuid); static fromString($uuid, $version = null); static fromBinary($uuid, $version = null); static fromData(...$data); static fromRandom(); toBinary(); toString(); __toString()
### UUID (class) — pocketmine/utils/p70/UUID.php
public: __construct($part1 = 0, $part2 = 0, $part3 = 0, $part4 = 0, $version = null); getVersion(); equals(/*UUID*/ $uuid); static fromString($uuid, $version = null); static fromBinary($uuid, $version = null); static fromData(...$data); static fromRandom(); toBinary(); toString(); __toString()
### Utils (class) — pocketmine/utils/Utils.php
public: static getCallableIdentifier(callable $variable); static getMachineUniqueId($extra = ""); static getIP($force = false); static getOS($recalculate = false); static getRealMemoryUsage(); static getMemoryUsage($advanced = false); static getThreadCount(); static getCoreCount($recalculate = false); static hexdump($bin); static printable($str); static getRandomBytes($length = 16, $secure = true, $raw = true, $startEntropy = "", &$rounds = 0, &$drop = 0); static angle3D($pos1, $pos2); static getURL($page, $timeout = 10, array $extraHeaders = []); static postURL($page, $args, $timeout = 10, array $extraHeaders = []); static javaStringHash($string)
### Utils (class) — pocketmine/utils/p70/Utils.php
consts: CIPHER, MODE
public: static aes_encode(string $str, string $key); static aes_decode(string $str, string $key); static getCallableIdentifier(callable $variable); static randomUUID(); static dataToUUID(...$params); static toUUID($data, $version = 2, $fixed = "8"); static getMachineUniqueId($extra = ""); static getIP($force = false); static getOS($recalculate = false); static getRealMemoryUsage(); static getMemoryUsage($advanced = false); static getThreadCount(); static getCoreCount($recalculate = false); static hexdump($bin); static printable($str); static getRandomBytes($length = 16, $secure = true, $raw = true, $startEntropy = "", &$rounds = 0, &$drop = 0); static angle3D($pos1, $pos2); static getURL($page, $timeout = 10, array $extraHeaders = []); static postURL($page, $args, $timeout = 10, array $extraHeaders = []); static javaStringHash($string)
### VectorIterator (class) — implements \Iterator | pocketmine/utils/VectorIterator.php
public: __construct(ChunkManager $level, Vector3 $from, Vector3 $to); next(); current(); rewind(); key(); valid()
### VersionString (class) — pocketmine/utils/VersionString.php
public: __construct($version = \pocketmine\VERSION); getNumber(); getStage(); getGeneration(); getMajor(); getMinor(); getRelease(); getBuild(); isDev(); get($build = false); __toString(); compare($target, $diff = false)
